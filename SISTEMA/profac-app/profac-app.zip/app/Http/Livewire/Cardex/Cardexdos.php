<?php

namespace App\Http\Livewire\Cardex;

use Livewire\Component;

class Cardexdos extends Component
{
    public function render()
    {
        return view('livewire.cardex.cardexdos');
    }
}

<?php

namespace App\Http\Livewire\Vale;

use Livewire\Component;

class FacturarVale extends Component
{
    public function render()
    {
        return view('livewire.vale.facturar-vale');
    }
}

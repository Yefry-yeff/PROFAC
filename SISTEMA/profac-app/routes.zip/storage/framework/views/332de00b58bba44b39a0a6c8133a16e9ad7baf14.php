<div>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Gestionar Widgets del Dashboard</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/usuarios/dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active"><strong>Gestionar Widgets</strong></li>
            </ol>
        </div>
        <div class="col-lg-2" style="padding-top:20px; text-align:right;">
            <a href="<?php echo e(url('/usuarios/dashboard')); ?>" class="btn btn-default btn-sm">
                <i class="fa fa-arrow-left"></i> Volver al Dashboard
            </a>
        </div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight">

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox">
                    <div class="ibox-title" style="border-top: 3px solid #1ab394;">
                        <h5><i class="fa fa-th-large" style="color:#1ab394; margin-right:6px;"></i> Widgets Configurados</h5>
                    </div>
                    <div class="ibox-content" style="padding:0;">
                        <div class="table-responsive">
                            <table class="table table-hover" style="margin:0; font-size:13px;">
                                <thead style="background:#f5f5f5;">
                                    <tr>
                                        <th style="width:40px;">Ord.</th>
                                        <th style="width:40px;"></th>
                                        <th>Nombre</th>
                                        <th>Tipo</th>
                                        <th>Roles con acceso</th>
                                        <th style="width:90px; text-align:center;">Estado</th>
                                        <th style="width:110px; text-align:center;">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr style="<?php echo e($w->enabled ? '' : 'opacity:.5;'); ?>">
                                        <td class="text-muted" style="font-size:11px;"><?php echo e($w->sort_order); ?></td>
                                        <td>
                                            <div class="rounded-circle d-flex align-items-center justify-content-center"
                                                 style="width:32px;height:32px;background:<?php echo e($w->color); ?>1a;border:1.5px solid <?php echo e($w->color); ?>;">
                                                <i class="fa <?php echo e($w->icon); ?>" style="color:<?php echo e($w->color); ?>;font-size:13px;"></i>
                                            </div>
                                        </td>
                                        <td style="font-weight:600; color:#333;"><?php echo e($w->title); ?></td>
                                        <td>
                                            <span class="label label-default" style="font-size:11px;">
                                                <?php echo e($widgetTypes[$w->widget_type] ?? $w->widget_type); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if(empty($w->roles)): ?>
                                                <span class="label label-success" style="font-size:11px;">Todos los roles</span>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $w->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="label" style="background:#1c84c6; color:#fff; font-size:11px; margin:1px;"><?php echo e($r); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:center;">
                                            <button wire:click="toggleEnabled(<?php echo e($w->id); ?>)"
                                                    class="btn btn-xs <?php echo e($w->enabled ? 'btn-success' : 'btn-default'); ?>">
                                                <i class="fa <?php echo e($w->enabled ? 'fa-toggle-on' : 'fa-toggle-off'); ?>"></i>
                                                <?php echo e($w->enabled ? 'Activo' : 'Inactivo'); ?>

                                            </button>
                                        </td>
                                        <td style="text-align:center; white-space:nowrap;">
                                            <button wire:click="abrirEditar(<?php echo e($w->id); ?>)"
                                                    class="btn btn-xs btn-warning"
                                                    title="Editar">
                                                <i class="fa fa-pencil"></i>
                                            </button>
                                            <button onclick="confirmarEliminar(<?php echo e($w->id); ?>, '<?php echo e(addslashes($w->title)); ?>')"
                                                    class="btn btn-xs btn-danger"
                                                    title="Eliminar">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted" style="padding:24px;">
                                            No hay widgets configurados. <a wire:click="abrirNuevo" href="#" style="color:#1ab394;">Crear el primero</a>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    
    <?php if($modalAbierto): ?>
    <div class="modal fade show" style="display:block; background:rgba(0,0,0,.5); z-index:9000; overflow-x:hidden; overflow-y:auto;" tabindex="-1">
        <div class="modal-dialog" style="max-width:640px; margin:30px auto;">
            <div class="modal-content">

                <div class="modal-header" style="background:#1ab394;">
                    <h4 class="modal-title" style="color:#fff;">
                        <i class="fa <?php echo e($esNuevo ? 'fa-plus' : 'fa-pencil'); ?>"></i>
                        <?php echo e($esNuevo ? 'Nuevo Widget' : 'Editar Widget'); ?>

                    </h4>
                    <button type="button" class="close" wire:click="cerrarModal" style="color:#fff; opacity:1;">
                        <span>&times;</span>
                    </button>
                </div>

                <div class="modal-body" style="padding:20px 24px; max-height:calc(100vh - 180px); overflow-y:auto;">

                    
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600;">Nombre del widget <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm <?php $__errorArgs = ['fTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               wire:model.lazy="fTitle"
                               placeholder="Ej: Ventas del Mes">
                        <?php $__errorArgs = ['fTitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback" style="display:block; font-size:12px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600;">Tipo de widget <span class="text-danger">*</span></label>
                        <select class="form-control form-control-sm <?php $__errorArgs = ['fWidgetType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                wire:model="fWidgetType">
                            <?php $__currentLoopData = $widgetTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeKey => $typeLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($typeKey); ?>"><?php echo e($typeLabel); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['fWidgetType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback" style="display:block; font-size:12px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="text-muted" style="font-size:11px;">El tipo determina qué datos se muestran.</small>
                    </div>

                    
                    <?php if($fWidgetType === 'tabla_stock_bajo'): ?>
                    <div class="alert alert-warning" style="padding:10px 14px; font-size:12px;">
                        <strong><i class="fa fa-exclamation-triangle"></i> Configuración de Stock Bajo</strong>
                        <div class="row" style="margin-top:8px;">
                            <div class="col-6">
                                <label style="font-size:12px;">Stock mínimo (umbral)</label>
                                <input type="number" class="form-control form-control-sm" wire:model.lazy="fStockMinimo" min="0">
                                <small class="text-muted">Mostrar productos con stock ≤ este valor</small>
                            </div>
                            <div class="col-6">
                                <label style="font-size:12px;">Límite de filas</label>
                                <input type="number" class="form-control form-control-sm" wire:model.lazy="fStockLimite" min="1" max="100">
                                <small class="text-muted">Máximo de productos a mostrar</small>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    
                    <div class="row">
                        <div class="col-5">
                            <div class="form-group">
                                <label style="font-size:13px; font-weight:600;">Ícono (Font Awesome)</label>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-addon"><i class="fa <?php echo e($fIcon ?: 'fa-question'); ?>"></i></span>
                                    <input type="text" class="form-control <?php $__errorArgs = ['fIcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           wire:model.lazy="fIcon"
                                           placeholder="fa-bar-chart">
                                </div>
                                <?php $__errorArgs = ['fIcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger" style="font-size:12px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted" style="font-size:11px;">Ej: fa-users, fa-chart-bar, fa-shopping-cart</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label style="font-size:13px; font-weight:600;">Color</label>
                                <div class="d-flex align-items-center" style="gap:6px;">
                                    <input type="color" class="form-control form-control-sm" wire:model="fColor"
                                           style="height:34px; width:50px; padding:2px; cursor:pointer;">
                                    <input type="text" class="form-control form-control-sm" wire:model.lazy="fColor"
                                           placeholder="#1ab394" style="width:90px;">
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label style="font-size:13px; font-weight:600;">Orden</label>
                                <input type="number" class="form-control form-control-sm" wire:model.lazy="fSortOrder" min="0">
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-group">
                        <label class="d-flex align-items-center" style="font-size:13px; gap:8px; cursor:pointer;">
                            <input type="checkbox" wire:model="fEnabled" style="width:16px; height:16px;">
                            <span style="font-weight:600;">Widget activo (visible en el dashboard)</span>
                        </label>
                    </div>

                    
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600;">
                            Roles que pueden ver este widget
                            <small class="text-muted" style="font-weight:400; margin-left:4px;">(sin selección = todos los roles)</small>
                        </label>
                        <div class="p-2" style="border:1px solid #e7eaec; border-radius:4px; max-height:200px; overflow-y:auto;">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="d-flex align-items-center mb-1" style="font-size:13px; cursor:pointer; gap:8px; padding:3px 6px; border-radius:3px;"
                                   onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='transparent'">
                                <input type="checkbox"
                                       wire:model="fRolesCheck.<?php echo e($rol->id); ?>"
                                       style="width:15px; height:15px;">
                                <?php echo e($rol->nombre); ?>

                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" wire:click="cerrarModal" class="btn btn-default">
                        <i class="fa fa-times"></i> Cancelar
                    </button>
                    <button type="button" wire:click="guardar" class="btn btn-primary">
                        <i class="fa fa-save"></i> <?php echo e($esNuevo ? 'Crear Widget' : 'Guardar Cambios'); ?>

                    </button>
                </div>

            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
    <script>
    function confirmarEliminar(id, nombre) {
        if (typeof Swal === 'undefined') {
            if (confirm('¿Eliminar el widget "' + nombre + '"? Esta acción no se puede deshacer.')) {
                window.livewire.find(document.querySelector('[wire\\:id]').getAttribute('wire:id')).call('eliminar', id);
            }
            return;
        }
        Swal.fire({
            title: '¿Eliminar widget?',
            html: 'Se eliminará <strong>' + nombre + '</strong>.<br>Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e74c3c',
            cancelButtonColor: '#aaa',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
        }).then(function(result) {
            if (result.isConfirmed) {
                var lw = document.querySelector('[wire\\:id]');
                if (lw) {
                    window.livewire.find(lw.getAttribute('wire:id')).call('eliminar', id);
                }
            }
        });
    }
    </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\laragon\www\Valencia\PROFAC\SISTEMA\profac-app\resources\views/livewire/usuarios/gestionar-widgets.blade.php ENDPATH**/ ?>
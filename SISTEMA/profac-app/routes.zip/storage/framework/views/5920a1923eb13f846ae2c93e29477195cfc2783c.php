<!DOCTYPE html>
<html lang="es" >

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'D. VALENCIA')); ?></title>
    <link rel="icon" type="image/x-icon" href="/img/valencia-fondo-transparente.png">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->yieldPushContent('styles'); ?><!--Por esta ranura se cargan los estilos de las paginas individuales-->
    <!-- Styles -->

    <!-- ApexChart -->

    


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  

    <!--font awesome-->
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <!-- Toastr style -->
    <link href="<?php echo e(asset('css/plugins/toastr/toastr.min.css')); ?>" rel="stylesheet">

    <!-- Gritter -->
    <link href="<?php echo e(asset('js/plugins/gritter/jquery.gritter.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">


    <!-- Fonts -->
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap"> -->

    <!--Data-parsley-validate-->
    <link href="<?php echo e(asset('css/plugins/parsley/parsley.css')); ?>" rel="stylesheet">
    
    <!--Datatable-->
    <link href="<?php echo e(asset('css/plugins/dataTables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    <!--select2-->
    <link href="<?php echo e(asset('css/plugins/select2/select2.min.css')); ?>" rel="stylesheet">



</head>

<body>
    



    <!--Menu lateral-->
    
   
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('A32ozVj')) {
    $componentId = $_instance->getRenderedChildComponentId('A32ozVj');
    $componentTag = $_instance->getRenderedChildComponentTagName('A32ozVj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('A32ozVj');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('A32ozVj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  
  

    



        <div id="wrapper" class="" >

            <!-- Page Content -->
            <div id="page-wrapper" class="gray-bg" style="margin-top:65px; padding-top:0;">

                <div class="wrapper wrapper-content animated fadeInRight">

                    <main  >
                        <?php echo e($slot); ?>


                    </main>

                </div>

            </div>


        </div>




    <!-- Mainly scripts -->
    <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>


    <!-- Flot -->
    <script src="<?php echo e(asset('js/plugins/flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/flot/jquery.flot.tooltip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/flot/jquery.flot.spline.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/flot/jquery.flot.resize.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/flot/jquery.flot.pie.js')); ?>"></script>

    <!-- Peity -->
    <script src="<?php echo e(asset('js/plugins/peity/jquery.peity.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/demo/peity-demo.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(asset('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/pace/pace.min.js')); ?>"></script>

    <!-- jQuery UI -->
    <script src="<?php echo e(asset('js/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>

    <!-- GITTER -->
    <script src="<?php echo e(asset('js/plugins/gritter/jquery.gritter.min.js')); ?>"></script>

    <!-- Sparkline -->
    <script src="<?php echo e(asset('js/plugins/sparkline/jquery.sparkline.min.js')); ?>"></script>

    <!-- Sparkline demo data  -->
    <script src="<?php echo e(asset('js/demo/sparkline-demo.js')); ?>"></script>

    <!-- ChartJS-->
    <script src="<?php echo e(asset('js/plugins/chartJs/Chart.min.js')); ?>"></script>

    <!-- Toastr -->
    <script src="<?php echo e(asset('js/plugins/toastr/toastr.min.js')); ?>"></script>


    <!--Data-parsley-validate-->

    <script src="<?php echo e(asset('js/data_parsley/parsley.js')); ?>"></script>
    <script src="<?php echo e(asset('js/data_parsley/i18n/es.js')); ?>"></script>

    <!-- Datatable JS -->

    <script src="<?php echo e(asset('js/plugins/dataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/dataTables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/dataTables/sum.js')); ?>"></script>

    <!--select2-->
    <script src="<?php echo e(asset('js/plugins/select2/select2.full.min.js')); ?>"></script>


    <!--ApexChart-->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <!-- Menu Search -->
    <script src="<?php echo e(asset('js/js_proyecto/menu/menu-search.js')); ?>"></script>
    
    <!-- Menu Responsive -->
    <script src="<?php echo e(asset('js/js_proyecto/menu/menu-responsive.js')); ?>"></script>

    <script>

    </script>




    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo $__env->yieldPushContent('modals'); ?>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>









</body>

</html>

<?php /**PATH C:\laragon\www\Valencia\PROFAC\SISTEMA\profac-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>
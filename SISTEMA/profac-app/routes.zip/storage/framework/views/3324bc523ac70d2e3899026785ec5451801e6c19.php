
<?php
    use App\Http\Controllers\MenuHelper;
    $menusUsuario = MenuHelper::getMenusUsuario();
?>

<?php $__currentLoopData = $menusUsuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="#">
            <i class="<?php echo e($menu->icon); ?>" style="color:#ffffff;"></i>
            <span class="nav-label" style="color:#ffffff;"><?php echo e($menu->nombre_menu); ?></span>
            <span class="fa arrow"></span>
        </a>
        <ul class="nav nav-second-level">
            <?php $__currentLoopData = $menu->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="/<?php echo e($submenu->url); ?>" style="color:#ffffff;">
                        <?php if($submenu->icono): ?>
                            <i class="<?php echo e($submenu->icono); ?>"></i>
                        <?php endif; ?>
                        <?php echo e($submenu->nombre); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\Valencia\PROFAC\SISTEMA\profac-app\resources\views/partials/menu-dinamico.blade.php ENDPATH**/ ?>

var numeroInputs = 0;
var arregloIdInputs = [];
var retencionEstado = false; // true  aplica retencion, false no aplica retencion;

window.onload = obtenerTipoPago;
var diasCredito = 0;





$('#seleccionarCliente').select2({
    ajax: {
        url: '/comprovante/clientes/lista',
        data: function(params) {
            var query = {
                search: params.term,
                type: 'public',
                page: params.page || 1
            }

            // Query parameters will be ?search=[term]&type=public
            return query;
        }
    }
});




$('#seleccionarProducto').select2({
    ajax: {
        url: '/ventas/listar',
        data: function(params) {
            var query = {
                search: params.term,
                type: 'public',
                page: params.page || 1
            }

            // Query parameters will be ?search=[term]&type=public

            return query;
        }
    }
});

function obtenerCategoriasClientes() {

    $('#categoria_cliente_venta_id').select2({
        placeholder: 'Seleccione una categoría',
        allowClear: true,
        ajax: {
            url: '/clientes/categorias-escala',
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    q: params.term || '',
                    page: params.page || 1
                };
            },
            processResults: function (data) {
                return {
                    results: data.categorias.map(function (item) {
                        return {
                            id: item.id,
                            text: item.nombre_categoria
                        };
                    })
                };
            }
        }
    });
}

function prueba() {

    var element = document.getElementById('botonAdd');
    element.classList.remove("d-none");

}

function calcularTotalesInicioPagina() {

let arrayInputs = this.arregloIdInputs;


let valorInputPrecio = 0;
let valorInputCantidad = 0;
let valorSelectUnidad = 0;
let isvProducto = 0;

let subTotal = 0;
let isv = 0;
let total = 0;
let descuento = 0;
let descuentoCalculado = 0

arrayInputs.forEach(id => {
// calcularTotales(idPrecio, idCantidad, isvProducto, idUnidad, id)
valorInputPrecio = document.getElementById('precio' + id).value;
valorInputCantidad = document.getElementById('cantidad' + id).value;
valorSelectUnidad = document.getElementById('unidad' + id).value;
isvProducto = document.getElementById("isv" + id).value;

if (valorInputPrecio && valorInputCantidad) {

descuento = document.getElementById("porDescuento").value;

if (descuento > 0) {
subTotal = valorInputPrecio * (valorInputCantidad * valorSelectUnidad);
descuentoCalculado = subTotal * (descuento / 100);
subTotal = subTotal - descuentoCalculado;
isv = subTotal * (isvProducto / 100);
total = subTotal + (subTotal * (isvProducto / 100));
} else {
descuentoCalculado = 0;
subTotal = valorInputPrecio * (valorInputCantidad * valorSelectUnidad);
isv = subTotal * (isvProducto / 100);
total = subTotal + subTotal * (isvProducto / 100);
}

document.getElementById("acumuladoDescuento" + id).value = descuentoCalculado.toFixed(2);

document.getElementById('total' + id).value = total.toFixed(2);
document.getElementById('totalMostrar' + id).value = new Intl.NumberFormat('es-HN', {
style: 'currency',
currency: 'HNL',
minimumFractionDigits: 2,
}).format(total)

document.getElementById('subTotal' + id).value = subTotal.toFixed(2);
document.getElementById('subTotalMostrar' + id).value = new Intl.NumberFormat('es-HN', {
style: 'currency',
currency: 'HNL',
minimumFractionDigits: 2,
}).format(subTotal)


document.getElementById('isvProducto' + id).value = isv.toFixed(2);
document.getElementById('isvProductoMostrar' + id).value = new Intl.NumberFormat(
'es-HN', {
    style: 'currency',
    currency: 'HNL',
    minimumFractionDigits: 2,
}).format(isv)


}

});



this.totalesGenerales();
return 0;


}

function obtenerBodegas(id) {

    document.getElementById('bodega').innerHTML = "<option  selected disabled>--Seleccione una bodega--</option>";
    let idProducto = id;
    $('#bodega').select2({
        ajax: {
            url: '/ventas/listar/bodegas/' + idProducto,
            data: function(params) {
                var query = {
                    search: params.term,
                    type: 'public',
                    page: params.page || 1,
                    idProducto: idProducto
                }

                // Query parameters will be ?search=[term]&type=public
                return query;
            }
        }
    });

}


function obtenerTipoPago() {

    axios.get('/ventas/tipo/pago')
        .then(response => {

            let tipoDePago = response.data.tipos;
            let numeroVenta = response.data.numeroVenta.numero;

            let htmlPagos = '  <option value="" selected disabled >--Seleccione una opcion--</option>';

            tipoDePago.forEach(element => {

                htmlPagos += `
                <option value="${element.id}" >${element.descripcion}</option>
                `
            });

            document.getElementById('tipoPagoVenta').innerHTML = htmlPagos;



        })
        .catch(err => {
            console.log(err);
            Swal.fire({
                icon: 'error',
                title: 'Error...',
                text: "Ha ocurrido un error al obtener los tipos de pago"
            })
        })

}

function obtenerImagenes() {
    let id = document.getElementById('seleccionarProducto').value;

    document.getElementById("bodega").disabled = false;
    let htmlImagenes = '';
    axios.post('/producto/listar/imagenes', {
            id: id,

        })
        .then(response => {

            let imagenes = response.data.imagenes;

            if (imagenes.length == 0) {

                console.log("entro")
                htmlImagenes += `
                <div class="carousel-item active " >
                    <img  class="d-block  img-size" src="${public_path+'/'+'noimage.png'}" alt="noimage.png"  >
                </div>`

                document.getElementById('bloqueImagenes').innerHTML = htmlImagenes;

                var element = document.getElementById('botonAdd');
                element.classList.remove("d-none");

            } else {
                imagenes.forEach(element => {

                    if (element.contador == 1) {
                        htmlImagenes += `
                <div class="carousel-item active " >
                    <img class="d-block  img-size" src="${public_path+'/'+element.url_img}" alt="imagen ${element.contador}"  >
                </div>`
                    } else {

                        htmlImagenes += `
                <div class="carousel-item  " >
                    <img class="d-block  img-size" src="${public_path+'/'+element.url_img}" alt="imagen ${element.contador}"  >
                </div>`

                    }

                });

                document.getElementById('bloqueImagenes').innerHTML = htmlImagenes;


            }

            var element = document.getElementById('botonAdd');
            element.classList.add("d-none");

            let a = document.getElementById("detalleProducto");
            let url = "/producto/detalle/" + id;
            a.href = url;
            a.classList.remove("d-none");

            return;



        })
        .catch(err => {

            console.log(err);

        })

    obtenerBodegas(id);
}

function cargarCategoriasProducto() {
    let productoId = $('#seleccionarProducto').val();
    let clienteId = $('#seleccionarCliente').val();
    let categoriaEscalaId = $('#categoria_cliente_venta_id').data('categoria-cliente-id') || null;

    if (productoId) {
        // Limpiar categoría mientras se carga
        $('#categoria_cliente_venta_id').empty().append('<option value="" selected disabled>Cargando categorías...</option>');

        // Cargar categorías del producto filtradas por la categoría del cliente
        axios.post('/producto/categorias-disponibles', {
            producto_id: productoId,
            cliente_categoria_escala_id: categoriaEscalaId
        })
        .then(response => {
            let categorias = response.data.categorias;

            if (categorias.length > 0) {
                $('#categoria_cliente_venta_id').empty().append('<option value="" selected disabled>--Seleccione una categoría--</option>');

                // Ordenar categorías por precio_a de mayor a menor
                categorias.sort((a, b) => (parseFloat(b.precio_a) || 0) - (parseFloat(a.precio_a) || 0));

                // Usar el tier específico del cliente si existe, si no el de mayor precio
                let categoriaPrecioId = $('#categoria_cliente_venta_id').data('categoria-precio-id') || null;
                let haySeleccionada = false;

                categorias.forEach((categoria, index) => {
                    let precio = parseFloat(categoria.precio_a) || 0;
                    let precioFormateado = new Intl.NumberFormat('es-HN', {
                        style: 'currency',
                        currency: 'HNL',
                        minimumFractionDigits: 2,
                    }).format(precio);
                    let textoOpcion = `${categoria.nombre_categoria} - ${precioFormateado}`;
                    let isSelected = categoriaPrecioId
                        ? (categoria.id == categoriaPrecioId)
                        : (index === 0);
                    if (isSelected) haySeleccionada = true;
                    let option = new Option(textoOpcion, categoria.id, isSelected, isSelected);
                    $('#categoria_cliente_venta_id').append(option);
                });

                // Si el tier del cliente no estaba en la lista, seleccionar el primero
                if (!haySeleccionada && categorias.length > 0) {
                    $('#categoria_cliente_venta_id option:nth-child(2)').prop('selected', true);
                }

                // SIEMPRE mantener habilitado el select
                $('#categoria_cliente_venta_id').prop('disabled', false);
            } else {
                // No hay categorías disponibles para este producto
                $('#categoria_cliente_venta_id').empty().append('<option value="" selected disabled>No hay categorías disponibles para este producto</option>');
                Swal.fire({
                    icon: 'warning',
                    title: 'Advertencia',
                    text: 'Este producto no tiene escalas de precio asignadas en ninguna categoría.'
                });
            }
        })
        .catch(err => {
            console.log(err);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Ha ocurrido un error al cargar las categorías del producto.'
            });
            $('#categoria_cliente_venta_id').empty().append('<option value="" selected disabled>Error al cargar categorías</option>');
        });
    } else {
        $('#categoria_cliente_venta_id').empty().append('<option value="" selected disabled>--Seleccione un producto primero--</option>');
    }
}

function agregarProductoCarrito() {
    let idProducto = document.getElementById('seleccionarProducto').value;
    let categoria_cliente_venta_id = document.getElementById('categoria_cliente_venta_id').value;

    // Validar que se haya seleccionado una categoría
    if (!categoria_cliente_venta_id) {
        Swal.fire({
            icon: 'warning',
            title: 'Advertencia',
            text: 'Por favor seleccione una categoría de precio antes de agregar el producto.'
        });
        return;
    }

    let data = $("#bodega").select2('data')[0];
    let idSeccion = data ? Number(data.id) : NaN;
    let idBodega = data ? Number(data.idBodega) : NaN;
    let bodega = data ? data.bodegaSeccion : '';

    if (!Number.isFinite(idSeccion) || !Number.isFinite(idBodega) || !bodega) {
        Swal.fire({
            icon: 'warning',
            title: 'Advertencia',
            text: 'Debe seleccionar una bodega válida antes de agregar el producto.'
        });
        return;
    }


    axios.post('/ventas/datos/producto', {
            idProducto: idProducto,
            categoria_cliente_venta_id: categoria_cliente_venta_id

        })
        .then(response => {

            let flag = false;
            arregloIdInputs.forEach(idInpunt => {
                let idProductoFila = document.getElementById("idProducto" + idInpunt).value;
                let idSeccionFila = document.getElementById("idSeccion" + idInpunt).value;

                if (idProducto == idProductoFila && idSeccion == idSeccionFila && !flag) {
                    flag = true;
                }

            })

            if (flag) {
                Swal.fire({

                    icon: 'warning',
                    title: 'Advertencia!',
                    html: `
                <p class="text-left">
                    La sección de bodega y producto ha sido agregada anteriormente.<br><br>
                    Por favor verificar la sección de bodega y producto sea distinto a los ya existentes en la lista de venta.<br><br>
                    De ser necesario aumentar la cantidad de producto en la lista de productos seleccionados para la venta.
                </p>`
                })

                return;
            }

            let producto = response.data.producto;

            let arrayUnidades = response.data.unidades;


            numeroInputs += 1;

            //     let arraySecciones  = response.data.secciones;
            // htmlSelectSeccion ="<option selected disabled>--seccion--</option>";

            // arraySecciones.forEach(seccion => {
            //     htmlSelectSeccion += `<option values="${seccion.id}" >${seccion.descripcion}</option>`
            // });

            htmlSelectUnidades = ""
            arrayUnidades.forEach(unidad => {
                if (unidad.valor_defecto == 1) {
                    htmlSelectUnidades +=
                        `<option selected value="${unidad.id}" data-id="${unidad.idUnidadVenta}">${unidad.nombre}</option>`;
                } else {
                    htmlSelectUnidades +=
                        `<option  value="${unidad.id}" data-id="${unidad.idUnidadVenta}">${unidad.nombre}</option>`;
                }

            });


            html = `
            <tr id="${numeroInputs}">
                <td style="vertical-align:middle; text-align:center; padding:4px 6px;">
                    <button class="btn btn-danger btn-sm" type="button" onclick="eliminarInput(${numeroInputs})">
                        <i class="fa fa-times"></i>
                    </button>
                    <input id="idProducto${numeroInputs}" name="idProducto${numeroInputs}" type="hidden" value="${producto.id}">
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <input type="text" id="nombre${numeroInputs}" name="nombre${numeroInputs}"
                        class="form-control form-control-sm" data-parsley-required autocomplete="off"
                        readonly value='${producto.nombre}'>
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <input type="text" id="bodega${numeroInputs}" name="bodega${numeroInputs}"
                        class="form-control form-control-sm" autocomplete="off" readonly value="${bodega}">
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <input type="number" id="precio${numeroInputs}" name="precio${numeroInputs}"
                        class="form-control form-control-sm" data-parsley-required step="any"
                        autocomplete="off" value="${producto.precio1}" min="${producto.precio1}"
                        onchange="calcularTotales(precio${numeroInputs},cantidad${numeroInputs},${producto.isv},unidad${numeroInputs},${numeroInputs},restaInventario${numeroInputs})">
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <input type="number" id="cantidad${numeroInputs}" name="cantidad${numeroInputs}"
                        class="form-control form-control-sm" min="0" data-parsley-required autocomplete="off"
                        onchange="calcularTotales(precio${numeroInputs},cantidad${numeroInputs},${producto.isv},unidad${numeroInputs},${numeroInputs},restaInventario${numeroInputs})">
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <select class="form-control form-control-sm" name="unidad${numeroInputs}" id="unidad${numeroInputs}"
                        data-parsley-required
                        onchange="calcularTotales(precio${numeroInputs},cantidad${numeroInputs},${producto.isv},unidad${numeroInputs},${numeroInputs},restaInventario${numeroInputs})">
                        ${htmlSelectUnidades}
                    </select>
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <input type="text" id="subTotalMostrar${numeroInputs}" name="subTotalMostrar${numeroInputs}"
                        class="form-control form-control-sm" autocomplete="off" readonly required>
                    <input id="subTotal${numeroInputs}" name="subTotal${numeroInputs}" type="hidden" value="" required>
                </td>
                <td style="vertical-align:middle; padding:4px 6px;">
                    <input type="text" id="isvProductoMostrar${numeroInputs}" name="isvProductoMostrar${numeroInputs}"
                        class="form-control form-control-sm" autocomplete="off" readonly>
                    <input id="isvProducto${numeroInputs}" name="isvProducto${numeroInputs}" type="hidden" value="" required>
                    <input type="hidden" id="acumuladoDescuento${numeroInputs}" name="acumuladoDescuento${numeroInputs}">
                </td>
                <td style="vertical-align:middle; padding:4px 6px; background:rgba(230,81,0,.05);">
                    <input type="text" id="totalMostrar${numeroInputs}" name="totalMostrar${numeroInputs}"
                        class="form-control form-control-sm" autocomplete="off" readonly
                        style="font-weight:700; color:#e65100;">
                    <input id="total${numeroInputs}" name="total${numeroInputs}" type="hidden" value="" required>
                    <input id="idBodega${numeroInputs}" name="idBodega${numeroInputs}" type="hidden" value="${idBodega}">
                    <input id="idSeccion${numeroInputs}" name="idSeccion${numeroInputs}" type="hidden" value="${idSeccion}">
                    <input id="restaInventario${numeroInputs}" name="restaInventario${numeroInputs}" type="hidden" value="">
                    <input id="isv${numeroInputs}" name="isv${numeroInputs}" type="hidden" value="${producto.isv}">
                    <input id="precios_producto_carga_id${numeroInputs}" name="precios_producto_carga_id${numeroInputs}" type="hidden" value="${producto.precios_producto_carga_id}">
                </td>
            </tr>
            `;

            arregloIdInputs.splice(numeroInputs, 0, numeroInputs);
            document.getElementById('divProductos').insertAdjacentHTML('beforeend', html);
            if (typeof actualizarCartUI === 'function') actualizarCartUI();

            return;

        })
        .catch(err => {

            console.error(err);

            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: "Ha ocurrido un error al agregar el producto a la compra."
            })
        })
}

function eliminarInput(id) {
    const element = document.getElementById(id);
    element.remove();


    var myIndex = arregloIdInputs.indexOf(id);
    if (myIndex !== -1) {
        arregloIdInputs.splice(myIndex, 1);
        this.totalesGenerales();
    }
    if (typeof actualizarCartUI === 'function') actualizarCartUI();

}

function calcularTotales(idPrecio, idCantidad, isvProducto, idUnidad, id, idRestaInventario) {


    let valorInputPrecio = Number(idPrecio.value).toFixed(2);
    let valorInputCantidad = idCantidad.value;
    let valorSelectUnidad = idUnidad.value;

    if (valorInputPrecio && valorInputCantidad) {

        let descuento = document.getElementById('porDescuento').value;
        let subTotal = 0;
        let isv = 0;
        let total = 0;


        if (descuento > 0) {
            subTotal = valorInputPrecio * (valorInputCantidad * valorSelectUnidad);
            descuentoCalculado = subTotal * (descuento / 100);
            subTotal = subTotal - descuentoCalculado;
            isv = subTotal * (isvProducto / 100);
            total = subTotal + (subTotal * (isvProducto / 100));
        } else {
            descuentoCalculado = 0
            subTotal = valorInputPrecio * (valorInputCantidad * valorSelectUnidad);
            isv = subTotal * (isvProducto / 100);
            total = subTotal + subTotal * (isvProducto / 100);
        }

        document.getElementById('acumuladoDescuento' + id).value = descuentoCalculado.toFixed(2);

        document.getElementById('total' + id).value = total.toFixed(2);
        document.getElementById('totalMostrar' + id).value = new Intl.NumberFormat('es-HN', {
            style: 'currency',
            currency: 'HNL',
            minimumFractionDigits: 2,
        }).format(total)

        document.getElementById('subTotal' + id).value = subTotal.toFixed(2);
        document.getElementById('subTotalMostrar' + id).value = new Intl.NumberFormat('es-HN', {
            style: 'currency',
            currency: 'HNL',
            minimumFractionDigits: 2,
        }).format(subTotal)


        document.getElementById('isvProducto' + id).value = isv.toFixed(2);
        document.getElementById('isvProductoMostrar' + id).value = new Intl.NumberFormat('es-HN', {
            style: 'currency',
            currency: 'HNL',
            minimumFractionDigits: 2,
        }).format(isv)


        idRestaInventario.value = valorInputCantidad * valorSelectUnidad;
        this.totalesGenerales();

    }

    idPrecio.value = valorInputPrecio;
    return 0;


}


function totalesGenerales() {

    //console.log(arregloIdInputs);

    if (numeroInputs == 0) {
        return;
    }



    let totalGeneralValor = new Number(0);
    let totalISV = new Number(0);
    let subTotalGeneralGrabadoValor = new Number(0);
    let subTotalGeneralExcentoValor = new Number(0);
    let subTotalGeneral = new Number(0);
    let subTotalFila = 0;
    let isvFila = 0;
    let acumularDescuento = new Number(0);

    for (let i = 0; i < arregloIdInputs.length; i++) {

        subTotalFila = new Number(document.getElementById('subTotal' + arregloIdInputs[i]).value);
        isvFila = new Number(document.getElementById('isvProducto' + arregloIdInputs[i]).value);



        if (isvFila == 0) {
            subTotalGeneralExcentoValor += new Number(document.getElementById('subTotal' + arregloIdInputs[i])
                .value);
        } else if (subTotalFila > 0) {
            subTotalGeneralGrabadoValor += new Number(document.getElementById('subTotal' + arregloIdInputs[i])
                .value);
        }

        subTotalGeneral += new Number(document.getElementById('subTotal' + arregloIdInputs[i]).value);


        totalISV += new Number(document.getElementById('isvProducto' + arregloIdInputs[i]).value);
        totalGeneralValor += new Number(document.getElementById('total' + arregloIdInputs[i]).value);

        acumularDescuento += new Number(document.getElementById('acumuladoDescuento' + arregloIdInputs[i]).value);
    }

    document.getElementById('porDescuentoCalculado').value = acumularDescuento.toFixed(2);

    document.getElementById('descuentoMostrar').value = new Intl.NumberFormat('es-HN', {
        style: 'currency',
        currency: 'HNL',
        minimumFractionDigits: 2,
    }).format(acumularDescuento)


    document.getElementById('subTotalGeneral').value = subTotalGeneral.toFixed(2);
    document.getElementById('subTotalGeneralMostrar').value = new Intl.NumberFormat('es-HN', {
        style: 'currency',
        currency: 'HNL',
        minimumFractionDigits: 2,
    }).format(subTotalGeneral)

    document.getElementById('subTotalGeneralGrabado').value = subTotalGeneralGrabadoValor.toFixed(2);
    document.getElementById('subTotalGeneralGrabadoMostrar').value = new Intl.NumberFormat('es-HN', {
        style: 'currency',
        currency: 'HNL',
        minimumFractionDigits: 2,
    }).format(subTotalGeneralGrabadoValor)

    document.getElementById('subTotalGeneralExcento').value = subTotalGeneralExcentoValor.toFixed(2);
    document.getElementById('subTotalGeneralExcentoMostrar').value = new Intl.NumberFormat('es-HN', {
        style: 'currency',
        currency: 'HNL',
        minimumFractionDigits: 2,
    }).format(subTotalGeneralExcentoValor)

    document.getElementById('isvGeneral').value = totalISV.toFixed(2);
    document.getElementById('isvGeneralMostrar').value = new Intl.NumberFormat('es-HN', {
        style: 'currency',
        currency: 'HNL',
        minimumFractionDigits: 2,
    }).format(totalISV)

    document.getElementById('totalGeneral').value = totalGeneralValor.toFixed(2);
    document.getElementById('totalGeneralMostrar').value = new Intl.NumberFormat('es-HN', {
        style: 'currency',
        currency: 'HNL',
        minimumFractionDigits: 2,
    }).format(totalGeneralValor)

    return 0;
}



function validarFechaPago() {

    let tipoPago;

    tipoPago = document.getElementById('tipoPagoVenta').value;

    // La fecha de vencimiento siempre es de solo lectura (se calcula automáticamente)
    document.getElementById('fecha_vencimiento').readOnly = true;

    if (tipoPago == 2) {

        // Es crédito: vencimiento = emisión + días de crédito del cliente
        document.getElementById('fecha_vencimiento').setAttribute('data-parsley-required', 'true');
        sumarDiasCredito();

    } else {
        // Es contado: vencimiento = misma fecha de emisión
        document.getElementById('fecha_vencimiento').value = document.getElementById('fecha_emision').value;
        document.getElementById('fecha_vencimiento').removeAttribute('data-parsley-required');

    }

    return 0;

}

function obtenerDatosCliente() {
    let idCliente = document.getElementById("seleccionarCliente").value;
    axios.post("/ventas/datos/cliente", {
            id: idCliente
        })
        .then(
            response => {

                let data = response.data.datos;

                if (data.id == 1) {
                    document.getElementById("nombre_cliente_ventas").readOnly = false;
                    document.getElementById("nombre_cliente_ventas").value = '';

                    document.getElementById("rtn_ventas").readOnly = false;
                    document.getElementById("rtn_ventas").value = '';
                    let selectBox = document.getElementById("tipoPagoVenta");
                    selectBox.remove(2);

                    $('#categoria_cliente_nombre').text(data.nombre_categoria);
                    $('#categoria_cliente_venta_id').data('categoria-cliente-id', data.idcategoriacliente);
                    $('#categoria_cliente_venta_id').data('categoria-precio-id', data.categoria_precios_id || null);

                    // Si ya hay un producto seleccionado, recargar todas sus categorías
                    // con la nueva categoría del cliente pre-seleccionada
                    if ($('#seleccionarProducto').val()) {
                        cargarCategoriasProducto();
                    } else {
                        $('#categoria_cliente_venta_id').empty();
                        $('#categoria_cliente_venta_id').append(new Option(data.nombre_categoria, data.idcategoriacliente, true, true));
                    }

                } else {
                    document.getElementById("nombre_cliente_ventas").readOnly = true;
                    document.getElementById("rtn_ventas").readOnly = true;

                    document.getElementById("nombre_cliente_ventas").value = data.nombre;
                    document.getElementById("rtn_ventas").value = data.rtn;

                    $('#categoria_cliente_nombre').text(data.nombre_categoria);
                    $('#categoria_cliente_venta_id').data('categoria-cliente-id', data.idcategoriacliente);
                    $('#categoria_cliente_venta_id').data('categoria-precio-id', data.categoria_precios_id || null);

                    // Si ya hay un producto seleccionado, recargar todas sus categorías
                    // con la nueva categoría del cliente pre-seleccionada
                    if ($('#seleccionarProducto').val()) {
                        cargarCategoriasProducto();
                    } else {
                        $('#categoria_cliente_venta_id').empty();
                        $('#categoria_cliente_venta_id').append(new Option(data.nombre_categoria, data.idcategoriacliente, true, true));
                    }

                    obtenerTipoPago();
                    diasCredito = data.dias_credito;
                    cargarHistorialPreciosCrearComprobante();
                }



            }
        )
        .catch(err => {

            console.log(err);
            Swal.fire({
                icon: 'error',
                title: 'Error...',
                text: "Ha ocurrido un error al obtener los datos del cliente"
            })


        })

}


$(document).on('submit', '#crear_venta',
    function(event) {
        event.preventDefault();
        guardarVenta();
    });

function guardarVenta() {

    // Validate all required fields before submitting
    var parsleyForm = $('#crear_venta').parsley();
    parsleyForm.validate();
    if (!parsleyForm.isValid()) {
        Swal.fire({
            icon: 'warning',
            title: 'Campos requeridos',
            text: 'Por favor complete todos los campos obligatorios antes de guardar.',
            confirmButtonText: 'Entendido',
            confirmButtonColor: '#19A689',
        });
        return;
    }

    document.getElementById("guardar_cotizacion_btn").disabled = true;

    var data = new FormData($('#crear_venta').get(0));

    let longitudArreglo = arregloIdInputs.length;
    for (var i = 0; i < longitudArreglo; i++) {


        let name = "unidad" + arregloIdInputs[i];
        let nameForm = "idUnidadVenta" + arregloIdInputs[i];

        let e = document.getElementById(name);
        let idUnidadVenta = e.options[e.selectedIndex].getAttribute("data-id");


        data.append(nameForm, idUnidadVenta)

    }

    data.append("numeroInputs", numeroInputs);

    let text = arregloIdInputs.toString();
    data.append("arregloIdInputs", text);

    const formDataObj = {};

    data.forEach((value, key) => (formDataObj[key] = value));


    const options = {
        headers: {
            "content-type": "application/json"
        }
    }

    axios.post('/comprovante/guardar/orden', formDataObj, options)
        .then(response => {
            let data = response.data;



            if (data.idFactura == 0) {
                console.log("entro")

                Swal.fire({
                    icon: data.icon,
                    confirmButtonText: 'Cerrar',
                    confirmButtonColor: '#19A689',
                    title: data.title,
                    html: data.text,
                })
                document.getElementById("guardar_cotizacion_btn").disabled = false;
                return;

            }

            Swal.fire({
                confirmButtonText: 'Cerrar',
                confirmButtonColor: '#19A689',
                icon: data.icon,
                title: data.title,
                html: data.text
            })


            document.getElementById('bloqueImagenes').innerHTML = '';
            document.getElementById('divProductos').innerHTML = '';

            document.getElementById("crear_venta").reset();
            $('#crear_venta').parsley().reset();

            var element = document.getElementById('detalleProducto');
            element.classList.add("d-none");
            element.href = "";

            document.getElementById("seleccionarCliente").innerHTML =
                '<option value="" selected disabled>--Seleccionar un cliente--</option>';

            document.getElementById('seleccionarProducto').innerHTML =
                '<option value="" selected disabled></option>';
            document.getElementById('codigoProductoCrearComprobante').value = '';
            var lbl_p = document.getElementById('productoSeleccionadoCrearComprobante');
            if (lbl_p) { lbl_p.classList.add('d-none'); lbl_p.textContent = ''; }
            document.getElementById('bodega').innerHTML =
                '<option value="" selected disabled>--Seleccione un producto--</option>';
            document.getElementById("bodega").disabled = true;



            let element2 = document.getElementById('detalleProducto');
            element2.classList.add("d-none");


            arregloIdInputs = [];
            numeroInputs = 0;
            retencionEstado = false;


            document.getElementById("guardar_cotizacion_btn").disabled = false;

        })
        .catch(err => {
            document.getElementById("guardar_cotizacion_btn").disabled = false;
            let data = err.response.data;
            console.log(err);
            Swal.fire({
                icon: data.icon,
                title: data.title,
                text: data.text
            })
        })
}

function sumarDiasCredito() {
    let tipoPago = document.getElementById('tipoPagoVenta').value;
    let fechaEmision = document.getElementById("fecha_emision").value;

    if (!fechaEmision) return;

    if (tipoPago == 2) {
        // Crédito: emisión + días de crédito del cliente
        let date = new Date(fechaEmision);
        date.setDate(date.getDate() + diasCredito);
        document.getElementById("fecha_vencimiento").value = date.toISOString().split('T')[0];

    } else if (tipoPago) {
        // Contado: vencimiento = misma fecha de emisión
        document.getElementById("fecha_vencimiento").value = fechaEmision;
    }
}

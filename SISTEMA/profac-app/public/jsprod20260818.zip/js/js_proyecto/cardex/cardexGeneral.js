﻿
var cdxFiltros = {
    desde: '',
    hasta: '',
    desdeOrigen: false,
    producto: '',
    cai: '',
    tipoDocumento: '',
    idDocumento: '',
    usuario: '',
    bodegaOrigen: '',
    bodegaDestino: ''
};
var cdxReabrirFiltrosTrasProducto = false;

function cdxGetDefaultDates() {
    var now = new Date();
    var y = now.getFullYear();
    var m = String(now.getMonth() + 1).padStart(2, '0');
    var lastDay = new Date(y, now.getMonth() + 1, 0).getDate();
    return {
        desde: y + '-' + m + '-01',
        hasta: y + '-' + m + '-' + String(lastDay).padStart(2, '0')
    };
}

function s2opts(url, placeholder) {
    return {
        ajax: {
            url: url,
            dataType: 'json',
            delay: 300,
            data: function(params) {
                return {
                    search: params.term || '',
                    q: params.term || '',
                    type: 'public',
                    page: params.page || 1
                };
            },
            processResults: function(data) {
                return { results: data.results || [] };
            },
            cache: true
        },
        placeholder: placeholder,
        allowClear: true,
        minimumInputLength: 1,
        width: '100%',
        dropdownParent: $('body')
    };
}

function cdxRenderBadges() {
    var bar = document.getElementById('cdxFiltrosBar');
    if (!bar) return;

    var defaults = cdxGetDefaultDates();

    var parts = [];
    var labels = {
        desde: 'Desde',
        hasta: 'Hasta',
        producto: 'Producto',
        cai: 'Factura (CAI)',
        tipoDocumento: 'Documento',
        idDocumento: 'ID Documento',
        usuario: 'Usuario',
        bodegaOrigen: 'Bodega Origen',
        bodegaDestino: 'Bodega Destino'
    };

    Object.keys(labels).forEach(function(key) {
        if (!cdxFiltros[key]) return;

        if ((key === 'desde' && cdxFiltros[key] === defaults.desde) ||
            (key === 'hasta' && cdxFiltros[key] === defaults.hasta)) {
            return;
        }

        var shown = cdxFiltros[key];
        if (key === 'usuario') {
            shown = $('#cdxFiltroUsuario option:selected').text() || shown;
        }
        if (key === 'producto') {
            shown = $('#cdxFiltroProducto option:selected').text() || shown;
        }
        if (key === 'bodegaOrigen') {
            shown = $('#cdxFiltroBodegaOrigen option:selected').text() || shown;
        }
        if (key === 'bodegaDestino') {
            shown = $('#cdxFiltroBodegaDestino option:selected').text() || shown;
        }
        parts.push('<span class="filtro-badge">' + labels[key] + ': <strong>' + shown + '</strong>' +
            '<span class="filtro-remove" onclick="quitarFiltroCardex(\'' + key + '\')">✕</span></span>');
    });

    if (cdxFiltros.desdeOrigen) {
        parts.unshift('<span class="filtro-badge">Desde: <strong>Origen</strong>' +
            '<span class="filtro-remove" onclick="quitarFiltroCardex(\'desdeOrigen\')">✕</span></span>');
    }

    if (parts.length === 0) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    bar.innerHTML = parts.join('');
    bar.style.display = 'flex';
}

function quitarFiltroCardex(key) {
    cdxFiltros[key] = key === 'desdeOrigen' ? false : '';
    if (key === 'desde') document.getElementById('cdxFiltroDesde').value = '';
    if (key === 'hasta') document.getElementById('cdxFiltroHasta').value = '';
    if (key === 'desdeOrigen') {
        $('#cdxDesdeOrigen').prop('checked', false).trigger('change');
        cdxFiltros.desde = document.getElementById('cdxFiltroDesde').value || cdxGetDefaultDates().desde;
    }
    if (key === 'producto') {
        $('#cdxFiltroProducto').empty().append(new Option('', '', true, true));
        $('#cdxProductoBuscar').val('');
        $('#cdxProductoSeleccionado').text('').addClass('d-none');
    }
    if (key === 'cai') document.getElementById('cdxFiltroCai').value = '';
    if (key === 'tipoDocumento') document.getElementById('cdxTipoDocumento').value = '';
    if (key === 'idDocumento') document.getElementById('cdxIdDocumento').value = '';
    if (key === 'usuario') $('#cdxFiltroUsuario').val(null).trigger('change');
    if (key === 'bodegaOrigen') $('#cdxFiltroBodegaOrigen').val(null).trigger('change');
    if (key === 'bodegaDestino') $('#cdxFiltroBodegaDestino').val(null).trigger('change');
    cdxRenderBadges();
    if ($.fn.DataTable.isDataTable('#tbl_cardex')) {
        $('#tbl_cardex').DataTable().ajax.reload();
    }
}

function cdxBuildUrl() {
    var desde = cdxFiltros.desde || document.getElementById('cdxFiltroDesde').value;
    var hasta = cdxFiltros.hasta || document.getElementById('cdxFiltroHasta').value;
    if (!desde || !hasta) {
        var now = new Date();
        var m = String(now.getMonth() + 1).padStart(2, '0');
        var d = String(now.getDate()).padStart(2, '0');
        var y = now.getFullYear();
        if (!hasta) hasta = y + '-' + m + '-' + d;
        if (!desde) desde = y + '-' + m + '-01';
    }
    return '/listado/cardex/general/' + desde + '/' + hasta;
}

function initDataTableCardex() {
    $('#tbl_cardex').DataTable({
        paging: true,
        language: { url: '/js/plugins/dataTables/i18n/Spanish.json' },
        pageLength: 5,
        order: [[0, 'desc']],
        responsive: true,
        dom: '<"html5buttons"B>lTfgitp',
        buttons: [
            { extend: 'copy' },
            { extend: 'csv' },
            { extend: 'excel', title: 'Cardex' },
            { extend: 'pdf', title: 'Cardex' },
            {
                extend: 'print',
                title: '',
                customize: function(win) {
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');
                    $(win.document.body).find('table').addClass('compact').css('font-size', 'inherit');
                }
            }
        ],
        ajax: {
            url: cdxBuildUrl(),
            data: function(d) {
                d.filtroDesde = cdxFiltros.desde;
                d.filtroHasta = cdxFiltros.hasta;
                d.desdeOrigen = cdxFiltros.desdeOrigen ? 1 : 0;
                d.filtroProducto = cdxFiltros.producto;
                d.filtroCai = cdxFiltros.cai;
                d.tipoDocumento = cdxFiltros.tipoDocumento;
                d.idDocumento = cdxFiltros.idDocumento;
                d.filtroUsuario = cdxFiltros.usuario;
                d.filtroBodegaOrigen = cdxFiltros.bodegaOrigen;
                d.filtroBodegaDestino = cdxFiltros.bodegaDestino;
            }
        },
        columns: [
            { data: 'fechaIngreso' },
            { data: 'producto' },
            { data: 'codigoProducto' },
            { data: 'doc_factura' },
            { data: 'doc_ajuste' },
            { data: 'detalleCompra' },
            { data: 'comprobante_entrega' },
            { data: 'vale_tipo_1' },
            { data: 'vale_tipo_2' },
            { data: 'nota_credito' },
            { data: 'descripcion' },
            { data: 'origen' },
            { data: 'destino' },
            { data: 'cantidad' },
            { data: 'usuario' }
        ]
    });
}

function aplicarFiltrosCardex() {
    cdxFiltros.desdeOrigen = document.getElementById('cdxDesdeOrigen').checked;
    cdxFiltros.desde = cdxFiltros.desdeOrigen ? '' : (document.getElementById('cdxFiltroDesde').value || '');
    cdxFiltros.hasta = document.getElementById('cdxFiltroHasta').value || '';
    cdxFiltros.producto = $('#cdxFiltroProducto').val() || '';
    cdxFiltros.cai = document.getElementById('cdxFiltroCai').value.trim();
    cdxFiltros.tipoDocumento = document.getElementById('cdxTipoDocumento').value || '';
    cdxFiltros.idDocumento = document.getElementById('cdxIdDocumento').value.trim();
    cdxFiltros.usuario = $('#cdxFiltroUsuario').val() || '';
    cdxFiltros.bodegaOrigen = $('#cdxFiltroBodegaOrigen').val() || '';
    cdxFiltros.bodegaDestino = $('#cdxFiltroBodegaDestino').val() || '';

    if (document.activeElement && typeof document.activeElement.blur === 'function') {
        document.activeElement.blur();
    }
    $('#modalFiltrosCardex').modal('hide');
    cdxRenderBadges();

    if ($.fn.DataTable.isDataTable('#tbl_cardex')) {
        var dt = $('#tbl_cardex').DataTable();
        dt.ajax.url(cdxBuildUrl()).load();
    } else {
        initDataTableCardex();
    }
}

function limpiarFiltrosCardex() {
    var defaults = cdxGetDefaultDates();
    document.getElementById('cdxFiltroDesde').value = defaults.desde;
    document.getElementById('cdxFiltroHasta').value = defaults.hasta;
    document.getElementById('cdxProductoBuscar').value = '';
    document.getElementById('cdxProductoSeleccionado').textContent = '';
    document.getElementById('cdxProductoSeleccionado').classList.add('d-none');
    $('#cdxFiltroProducto').empty().append(new Option('', '', true, true));
    $('#cdxDesdeOrigen').prop('checked', false).trigger('change');
    document.getElementById('cdxFiltroCai').value = '';
    document.getElementById('cdxTipoDocumento').value = '';
    document.getElementById('cdxIdDocumento').value = '';
    $('#cdxFiltroUsuario').val(null).trigger('change');
    $('#cdxFiltroBodegaOrigen').val(null).trigger('change');
    $('#cdxFiltroBodegaDestino').val(null).trigger('change');

    cdxFiltros = {
        desde: defaults.desde,
        hasta: defaults.hasta,
        desdeOrigen: false,
        producto: '',
        cai: '',
        tipoDocumento: '',
        idDocumento: '',
        usuario: '',
        bodegaOrigen: '',
        bodegaDestino: ''
    };
    cdxRenderBadges();

    if ($.fn.DataTable.isDataTable('#tbl_cardex')) {
        var dt = $('#tbl_cardex').DataTable();
        dt.ajax.url(cdxBuildUrl()).load();
    }
}

function cargaCardex() {
    aplicarFiltrosCardex();
}

function cdxSeleccionarProducto(producto) {
    $('#cdxFiltroProducto').empty().append(new Option(producto.nombre, producto.id, true, true));
    $('#cdxProductoBuscar').val('');
    $('#cdxProductoSeleccionado')
        .text(producto.nombre + ' (ID: ' + producto.id + ')')
        .removeClass('d-none');
}

function cdxAbrirBuscadorProducto() {
    var termino = ($('#cdxProductoBuscar').val() || '').trim();
    cdxReabrirFiltrosTrasProducto = true;
    $('#modalFiltrosCardex').one('hidden.bs.modal', function() {
        window['abrirBuscador_buscadorProductoCardex'](termino);
    }).modal('hide');
}

$(document).ready(function() {
    $('#cdxFiltroUsuario').select2(s2opts('/filtros/facturas/usuarios', 'Buscar usuario...'));
    $('#cdxFiltroBodegaOrigen').select2(s2opts('/cardex/listar/bodega', 'Buscar bodega origen...'));
    $('#cdxFiltroBodegaDestino').select2(s2opts('/cardex/listar/bodega', 'Buscar bodega destino...'));

    $('#cdxDesdeOrigen').on('change', function() {
        $('#cdxFiltroDesde').prop('disabled', this.checked);
    });
    $('#btnCdxBuscarProducto').on('click', cdxAbrirBuscadorProducto);
    $('#cdxProductoBuscar').on('keydown', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            cdxAbrirBuscadorProducto();
        }
    });
    $('#buscadorProductoCardex').on('hidden.bs.modal', function() {
        if (cdxReabrirFiltrosTrasProducto) {
            cdxReabrirFiltrosTrasProducto = false;
            $('#modalFiltrosCardex').modal('show');
        }
    });

    $(document).on('select2:open', function() {
        $(document).off('focusin.modal');
        var campo = document.querySelector('.select2-container--open .select2-search__field');
        if (campo) campo.focus();
    });

    cdxFiltros.desde = document.getElementById('cdxFiltroDesde').value || '';
    cdxFiltros.hasta = document.getElementById('cdxFiltroHasta').value || '';

    $('#modalFiltrosCardex').on('hide.bs.modal', function() {
        if (document.activeElement && typeof document.activeElement.blur === 'function') {
            document.activeElement.blur();
        }
    });

    initDataTableCardex();
    cdxRenderBadges();
});

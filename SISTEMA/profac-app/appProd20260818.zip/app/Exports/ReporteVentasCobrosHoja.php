<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithDrawings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStrictNullComparison;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

/**
 * Hoja del reporte Ventas & Cobros (v6).
 *
 * 32 columnas (A..AF):
 *  A(0)   #               B(1)   MES             C(2)   FECHA
 *  D(3)   ASESOR COM.     E(4)   TELEASESOR      F(5)   CLIENTE
 *  G(6)   DOCUMENTO       H(7)   TIPO DOCUMENTO  I(8)   NRO DOCUMENTO
 *  J(9)   OBSERVACION     K(10)  ORDEN COMPRA    L(11)  MODO PAGO
 *  M(12)  ESTADO F01      N(13)  EXONERADO       O(14)  GRAVADO
 *  P(15)  EXENTO          Q(16)  SUBTOTAL        R(17)  ISV
 *  S(18)  TOTAL           T(19)  DISMINUCION     U(20)  AUMENTO
 *  V(21)  MONTO PAGADO    W(22)  SALDO PENDIENTE X(23)  FALTA RETENCION
 *  Y(24)  ESTADO COBRO    Z(25)  FECHA VENTA     AA(26) FECHA VCTO.
 *  AB(27) DIAS VCTOS.     AC(28) FECHA PAGO      AD(29) FORMA DE PAGO
 *  AE(30) BANCO           AF(31) CUENTA
 *
 * Reglas:
 *  - DEBITOS  (T): monto de movimientos que DISMINUYEN el saldo
 *                  (ABONO, PAGO, NOTA_CREDITO, VALE, RETENCION)
 *  - CREDITOS (U): monto de movimientos que AUMENTAN el saldo
 *                  (NOTA_DEBITO)
 *  - SALDO PENDIENTE: siempre numerico, muestra 0.00 cuando esta saldado
 *  - MONTO PAGADO (factura): suma de todos los abonos ($r->abonos)
 *  - DIAS VCTOS. (factura): celda verde si <= 0, roja si > 0
 *  - Sub-filas: sin fondo; celda DEBITOS en rojo claro, celda CREDITOS en verde claro
 */
class ReporteVentasCobrosHoja implements FromArray, WithTitle, WithStyles, WithDrawings, WithEvents, WithStrictNullComparison
{
    protected $rows;
    protected $usuario;
    protected $movimientos;
    protected $fastMode;
    protected $superFastMode;
    protected $rowMeta = [];

    const LAST_COL  = 'AF';
    const COL_COUNT = 32;

    const T_FACTURA   = 'FACTURA';
    const T_ENTREGA   = 'ENTREGA';
    const T_ABONO     = 'ABONO';
    const T_PAGO      = 'PAGO';
    const T_NOTA_C    = 'NOTA_CREDITO';
    const T_NOTA_D    = 'NOTA_DEBITO';
    const T_VALE      = 'VALE';
    const T_RETENCION = 'RETENCION';

    // DEBITO  = ajuste que disminuye el saldo (Nota Credito, Vale, Retencion) → col T
    // PAGO    = cobro que disminuye el saldo (Abono, Pago Contado) → col V (MONTO PAGADO)
    // CREDITO = ajuste que aumenta el saldo (Nota Debito) → col U
    private static $TIPOS_DEBITO  = ['NOTA_CREDITO', 'NOTA_CREDITO_EMISION', 'VALE', 'RETENCION'];
    private static $TIPOS_CREDITO = ['NOTA_DEBITO', 'NOTA_CREDITO_APLICACION', 'NOTA_CREDITO_REEMBOLSO'];
    private static $TIPOS_PAGO    = ['ABONO', 'PAGO'];

    private static $TIPO_LABEL = [
        'VENTA'        => 'Factura',
        'FACTURA'      => 'Factura',
        'ENTREGA'      => 'Entrega',
        'ABONO'        => 'Abono',
        'PAGO'         => 'Pago Contado',
        'NOTA_CREDITO' => 'Nota de Credito',
        'NOTA_CREDITO_EMISION' => 'Nota de Credito Emitida',
        'NOTA_CREDITO_APLICACION' => 'Aplicacion de Nota de Credito',
        'NOTA_CREDITO_REEMBOLSO' => 'Reembolso de Nota de Credito',
        'NOTA_DEBITO'  => 'Nota de Debito',
        'VALE'         => 'Vale',
        'RETENCION'    => 'Retencion ISV',
    ];

    private static $MESES = [
        1 => 'Enero',    2 => 'Febrero',  3 => 'Marzo',     4 => 'Abril',
        5 => 'Mayo',     6 => 'Junio',    7 => 'Julio',     8 => 'Agosto',
        9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre',
    ];

    public function __construct($rows, $usuario = 'Sistema', $movimientos = [], $fastMode = false, $superFastMode = false)
    {
        $this->rows          = $rows;
        $this->usuario       = $usuario;
        $this->movimientos   = $movimientos;
        $this->fastMode      = (bool) $fastMode;
        $this->superFastMode = (bool) $superFastMode;
    }

    public function title(): string { return 'Ventas y Cobros'; }

    private function fmt(?string $d): string
    {
        if (!$d) return '';
        $ts = strtotime($d);
        return $ts ? date('d/m/Y', $ts) : '';
    }

    /**
     * Convierte una fecha a valor serial de Excel para que la celda
     * se reconozca como fecha real (con el formato dd/mm/yyyy aplicado en AfterSheet).
     *
     * @return float|string Valor serial de Excel o '' si no hay fecha valida.
     */
    private function excelDate(?string $d)
    {
        if (!$d) return '';
        $ts = strtotime($d);
        if (!$ts) return '';
        return \PhpOffice\PhpSpreadsheet\Shared\Date::timestampToExcel($ts);
    }

    private function mesNombre(?string $d): string
    {
        if (!$d) return '';
        $ts = strtotime($d);
        if (!$ts) return '';
        return self::$MESES[(int) date('n', $ts)] ?? '';
    }

    private function tipoLabel(string $tipo): string
    {
        return self::$TIPO_LABEL[$tipo] ?? ucfirst(strtolower($tipo));
    }

    private function money($value): float
    {
        $number = (float) ($value ?? 0);
        if (abs($number) < 0.005) {
            return 0.0;
        }

        return round($number, 2);
    }

    /* ─────────────────────────────────────────────────────────────── */

    public function array(): array
    {
        $this->rowMeta = [];
        $out  = [];
        $item = 0;

        // Acumuladores de totales (solo filas FACTURA)
        $totExon   = 0.0;
        $totGrav   = 0.0;
        $totExen   = 0.0;
        $totSub    = 0.0;
        $totIsv    = 0.0;
        $totTotal  = 0.0;
        $totDeb    = 0.0;
        $totCred   = 0.0;
        $totPagado = 0.0;
        $totSaldo  = 0.0;

        /* Fila 1 */
        $r1 = array_fill(0, self::COL_COUNT, '');
        $r1[0] = 'DISTRIBUCIONES VALENCIA   |   RTN: 08011986138652';
        $out[] = $r1;

        /* Fila 2 */
        $r2 = array_fill(0, self::COL_COUNT, '');
        $r2[0] = 'REPORTE DE VENTAS Y COBROS';
        $out[] = $r2;

        /* Fila 3 */
        $r3 = array_fill(0, self::COL_COUNT, '');
        $r3[0] = 'Generado: ' . now()->format('d/m/Y H:i') . '   |   Descargado por: ' . $this->usuario;
        $out[] = $r3;

        /* Fila 4 – cabeceras */
        $out[] = [
            '#','MES','FECHA','ASESOR COMERCIAL','TELEASESOR','CLIENTE',
            'DOCUMENTO','TIPO DOCUMENTO','NRO DOCUMENTO','OBSERVACION','ORDEN COMPRA',
            'CONDICION DE VENTA','ESTADO F01','EXONERADO','GRAVADO','EXENTO',
            'SUBTOTAL','ISV','TOTAL','DISMINUCION EN FACT.','AUMENTO EN FACT.',
            'MONTO PAGADO','SALDO PENDIENTE','FATAL RETENCION','ESTADO COBRO',
            'FECHA VENTA','FECHA VCTO.','DIAS VCTOS.','FECHA PAGO','FORMA DE PAGO',
            'BANCO','CUENTA',
        ];

        foreach ($this->rows as $r) {
            $factId      = (int)($r->factura_id ?? 0);
            $facturaNum  = $r->numero_secuencia_cai ?? '';
            $movs         = $this->movimientos[$factId] ?? [];
            $saldoFactura = (float)($r->total ?? 0); // progresivo: se mantiene lineal para cuadrar totales
            $pagosAcum    = (float)($r->pagos_directos ?? 0);
            $dias         = (int)($r->dias_vencidos ?? 0);
            $estadoCobro = $r->estado_cobro_v2 ?? ($r->creditos_vencidos ?? '');
            $estadoF01 = strtoupper(trim((string)($r->estado_f01 ?? '')));
            $esAnulada = str_starts_with($estadoF01, 'ANULAD');

            /* ── PRE-CALCULAR TOTALES DEBITOS / CREDITOS ───── */
            $totalDebitos  = 0.0;
            $totalCreditos = 0.0;
            $totalPagos    = (float)($r->pagos_directos ?? 0);
            $_sfCalc       = (float)($r->total ?? 0);
            foreach ($movs as $_mov) {
                if ($_mov->tipo === 'VENTA') continue;
                $_monto = (float)($_mov->monto ?? 0);
                if (in_array($_mov->tipo, self::$TIPOS_DEBITO)) {
                    $totalDebitos += $_monto;
                    $_sfCalc      -= $_monto; // saldo factura baja
                }
                if (in_array($_mov->tipo, self::$TIPOS_CREDITO)) {
                    $totalCreditos += $_monto;
                    $_sfCalc      += $_monto;                   // saldo factura sube
                }
                if (in_array($_mov->tipo, self::$TIPOS_PAGO)) {
                    $totalPagos += $_monto;  // pagos NO afectan saldo de factura
                }
            }
            // Sumar retencion ISV al total de debitos
            $_montoRet = (float)($r->monto_retencion ?? 0);
            if ($_montoRet > 0) { $totalDebitos += $_montoRet; $_sfCalc -= $_montoRet; }
            $finalSaldoFactura   = $this->money($_sfCalc);
            $finalSaldoPendiente = $this->money($finalSaldoFactura - $totalPagos);

            /* ── FILA FACTURA ──────────────────────────────── */
            $item++;
            $excelRow = count($out) + 1;
            $this->rowMeta[$excelRow] = [
                'type'          => self::T_FACTURA,
                'estado_cobro'  => $estadoCobro,
                'estado_f01'    => $r->estado_f01 ?? '',
                'dias_vencidos' => $dias,
            ];

            $row = array_fill(0, self::COL_COUNT, '');
            $row[0]  = $item;
            $row[1]  = strtoupper($r->mes ?? '');
            $row[2]  = $this->excelDate($r->fecha_venta);
            $row[3]  = $r->asesor_comercial ?? '';
            $row[4]  = $r->teleasesor ?? '';
            $row[5]  = $r->cliente ?? '';
            $row[6]  = $facturaNum;
            $row[7]  = 'Factura';
            $row[8]  = '';
            $row[9]  = $r->observacion ?? '';
            $row[10] = (strtotime($r->fecha_venta ?? '') >= strtotime('2026-05-15'))
                        ? (trim($r->flujo_orden_compra ?? '') ?: ($r->orden_compra ?? ''))
                        : ($r->orden_compra ?? '');
            $row[11] = $r->modo_pago ?? '';
            $row[12] = trim($r->flujo_forma_f01 ?? '') ?: 'N/A';
            $row[13] = $esAnulada ? '' : ($this->money($r->exonerado ?? 0) > 0 ? $this->money($r->exonerado ?? 0) : '');
            $row[14] = $esAnulada ? '' : ($this->money($r->gravado ?? 0) > 0 ? $this->money($r->gravado ?? 0) : '');
            $row[15] = $esAnulada ? '' : ($this->money($r->exento ?? 0) > 0 ? $this->money($r->exento ?? 0) : '');
            $row[16] = $esAnulada ? '' : $this->money($r->sub_total ?? 0);
            $row[17] = $esAnulada ? '' : $this->money($r->isv ?? 0);
            $row[18] = $esAnulada ? '' : $this->money($r->total ?? 0);
            $row[19] = $this->money($totalDebitos) > 0 ? -$this->money($totalDebitos) : '';
            $row[20] = $this->money($totalCreditos) > 0 ? $this->money($totalCreditos) : '';
            // MONTO PAGADO: negativo (es un egreso)
            $_pagosVal = $totalPagos > 0 ? $totalPagos : (
                       (float)($r->abonos ?? 0) > 0 ? (float)$r->abonos : (
                       (float)($r->monto_pagado ?? 0) > 0 ? (float)$r->monto_pagado : 0
                       ));
            $_pagosVal = $this->money($_pagosVal);
            $row[21] = $_pagosVal > 0 ? -$_pagosVal : '';
            $row[22] = $esAnulada ? '' : $finalSaldoPendiente;
            $isvFactura = $this->money($r->isv ?? 0);
            $row[23] = !$esAnulada && $finalSaldoPendiente > 0 && $isvFactura > 0
                && $finalSaldoPendiente === $isvFactura ? 'X' : '';
            $row[24] = $estadoCobro;
            $row[25] = $esAnulada ? '' : $this->excelDate($r->fecha_venta);
            $row[26] = $esAnulada ? '' : $this->excelDate($r->fecha_vencimiento);
            $row[27] = $esAnulada ? '' : $dias;
            $row[28] = '';
            $row[29] = '';
            $row[30] = '';
            $row[31] = '';
            $out[] = $row;

            // Acumular totales de fila factura
            $totExon   += $this->money($r->exonerado ?? 0);
            $totGrav   += $this->money($r->gravado ?? 0);
            $totExen   += $this->money($r->exento ?? 0);
            $totSub    += $this->money($r->sub_total ?? 0);
            $totIsv    += $this->money($r->isv ?? 0);
            $totTotal  += $this->money($r->total ?? 0);
            $totDeb    += $this->money($totalDebitos);
            $totCred   += $this->money($totalCreditos);
            $totPagado += $_pagosVal;
            $totSaldo  += $finalSaldoPendiente;

            /* ── MOVIMIENTOS ───────────────────────────────── */
            foreach ($movs as $mov) {
                if ($mov->tipo === 'VENTA') continue;

                $tipo  = $mov->tipo;
                $monto = (float)($mov->monto ?? 0);

                $esDebito  = in_array($tipo, self::$TIPOS_DEBITO);
                $esCredito = in_array($tipo, self::$TIPOS_CREDITO);
                $esPago    = in_array($tipo, self::$TIPOS_PAGO);

                // Actualizar saldo progresivo
                if ($esDebito)       $saldoFactura -= $monto;
                elseif ($esCredito)  $saldoFactura += $monto;
                elseif ($esPago)     $pagosAcum   += $monto;
                // ENTREGA no cambia saldo
                $saldoPendiente = $this->money($saldoFactura - $pagosAcum);

                // Ocultar subfilas de Pago Contado en el Excel,
                // pero conservar su impacto en los calculos.
                if ($tipo === self::T_PAGO) {
                    continue;
                }

                $item++;
                $excelRow = count($out) + 1;
                $this->rowMeta[$excelRow] = [
                    'type'      => $tipo,
                    'dir'       => $esDebito ? 'debito' : ($esCredito ? 'credito' : ($esPago ? 'pago' : 'neutral')),
                    'saldo_dir' => $esDebito ? 'down' : ($esCredito ? 'up' : 'neutral'),
                    'has_monto' => ($tipo !== 'ENTREGA' && $monto > 0),
                ];

                $movRow = array_fill(0, self::COL_COUNT, '');
                $movRow[0]  = $item;
                $movRow[1]  = $this->mesNombre($mov->fecha);
                $movRow[2]  = $this->excelDate($mov->fecha);
                $movRow[3]  = $r->asesor_comercial ?? '';
                $movRow[4]  = $r->teleasesor ?? '';
                $movRow[5]  = $r->cliente ?? '';
                $movRow[6]  = $facturaNum;
                $movRow[7]  = $this->tipoLabel($tipo);
                $movRow[8]  = trim((string)($mov->documento ?? ''));
                $movRow[9]  = $mov->descripcion ?? '';
                // cols 9-17: datos de factura en blanco (TOTAL solo en factura, no en sub-filas)
                $monto = $this->money($monto);
                $movRow[19] = $esDebito  ? -$monto : '';
                $movRow[20] = $esCredito ? $monto  : '';
                $movRow[21] = $esPago    ? -$monto : '';
                $movRow[22] = $saldoPendiente;
                $movRow[23] = '';
                // Estado y fechas de factura quedan en blanco en sub-filas.
                $movRow[28] = $this->fmt($mov->fecha);
                $movRow[29] = $mov->forma_pago ?? '';
                $movRow[30] = $mov->banco_nombre ?? '';
                $movRow[31] = $mov->banco_cuenta ?? '';
                $out[] = $movRow;
            }

            /* ── RETENCIÓN ISV ─────────────────────────────── */
            $montoRet = (float)($r->monto_retencion ?? 0);
            if ($montoRet > 0) {
                $saldoFactura   -= $montoRet;
                $saldoPendiente = $this->money($saldoFactura - $pagosAcum);
                $item++;
                $excelRow = count($out) + 1;
                $this->rowMeta[$excelRow] = [
                    'type'      => self::T_RETENCION,
                    'dir'       => 'debito',
                    'saldo_dir' => 'down',
                    'has_monto' => true,
                ];

                $retRow = array_fill(0, self::COL_COUNT, '');
                $retRow[0]  = $item;
                $retRow[1]  = $r->fecha_retencion ? $this->mesNombre($r->fecha_retencion) : '';
                $retRow[2]  = $this->excelDate($r->fecha_retencion ?? '');
                $retRow[3]  = $r->asesor_comercial ?? '';
                $retRow[4]  = $r->teleasesor ?? '';
                $retRow[5]  = $r->cliente ?? '';
                $retRow[6]  = $facturaNum;
                $retRow[7]  = 'Retencion ISV';
                $retRow[8]  = trim((string)($r->numero_retencion ?? ''));
                $retRow[9]  = 'Retencion ISV aplicada';
                $retRow[19] = -$this->money($montoRet);
                $retRow[20] = '';
                $retRow[21] = '';
                $retRow[22] = $saldoPendiente;
                $out[] = $retRow;
            }
        }

        /* ── FILA TOTALES ─────────────────────────────────── */
        $totRow = array_fill(0, self::COL_COUNT, '');
        $totRow[0]  = '';
        $totRow[5]  = 'TOTALES';
        $totExon = $this->money($totExon);
        $totGrav = $this->money($totGrav);
        $totExen = $this->money($totExen);
        $totSub = $this->money($totSub);
        $totIsv = $this->money($totIsv);
        $totTotal = $this->money($totTotal);
        $totDeb = $this->money($totDeb);
        $totCred = $this->money($totCred);
        $totPagado = $this->money($totPagado);
        $totRow[13] = $totExon   > 0 ? $totExon   : '';
        $totRow[14] = $totGrav   > 0 ? $totGrav   : '';
        $totRow[15] = $totExen   > 0 ? $totExen   : '';
        $totRow[16] = $totSub;
        $totRow[17] = $totIsv;
        $totRow[18] = $totTotal;
        $totRow[19] = $totDeb    > 0 ? -$totDeb   : '';
        $totRow[20] = $totCred   > 0 ? $totCred   : '';
        $totRow[21] = $totPagado > 0 ? -$totPagado : '';
        $totRow[22] = $this->money($totTotal - $totDeb + $totCred - $totPagado);
        $excelRow = count($out) + 1;
        $this->rowMeta[$excelRow] = ['type' => 'TOTALES'];
        $out[] = $totRow;

        return $out;
    }

    /* ─────────────────────────────────────────────────────────────── */

    public function drawings()
    {
        if ($this->fastMode) {
            return [];
        }

        $d = new Drawing();
        $d->setName('Logo Valencia');
        $d->setPath(public_path('img/membrete/Logo3.png'));
        $d->setHeight(60);
        $d->setCoordinates('A1');
        $d->setOffsetX(4)->setOffsetY(4);
        return $d;
    }

    public function styles(Worksheet $sheet)
    {
        $lc = self::LAST_COL;

        $sheet->mergeCells("A1:{$lc}1");
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(12);
        $sheet->getStyle('A1')->getFont()->getColor()->setRGB('1F3864');
        $sheet->getStyle('A1')->getAlignment()
            ->setHorizontal(Alignment::HORIZONTAL_RIGHT)
            ->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getRowDimension(1)->setRowHeight(65);

        $sheet->mergeCells("A2:{$lc}2");
        $sheet->getStyle('A2')->getFont()->setBold(true)->setSize(11);
        $sheet->getStyle('A2')->getFont()->getColor()->setRGB('e07000');
        $sheet->getStyle('A2')->getAlignment()
            ->setHorizontal(Alignment::HORIZONTAL_CENTER)
            ->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getRowDimension(2)->setRowHeight(20);

        $sheet->mergeCells("A3:{$lc}3");
        $sheet->getStyle('A3')->getFont()->setSize(9)->setItalic(true);
        $sheet->getStyle('A3')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getRowDimension(3)->setRowHeight(16);

        $sheet->getStyle("A4:{$lc}4")->getFont()->setBold(true)->setSize(8);
        $sheet->getStyle("A4:{$lc}4")->getFont()->getColor()->setRGB('FFFFFF');
        $sheet->getStyle("A4:{$lc}4")->getFill()
            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('e07000');
        $sheet->getStyle("A4:{$lc}4")->getAlignment()
            ->setHorizontal(Alignment::HORIZONTAL_CENTER)
            ->setVertical(Alignment::VERTICAL_CENTER)
            ->setWrapText(true);
        $sheet->getRowDimension(4)->setRowHeight(30);

        // Anchos fijos siempre — setAutoSize en 30 columnas es el mayor cuello de botella
        $fixedWidths = [
            'A' => 6,  'B' => 10, 'C' => 12, 'D' => 20, 'E' => 20,
            'F' => 34, 'G' => 18, 'H' => 18, 'I' => 16, 'J' => 28,
            'K' => 16, 'L' => 16, 'M' => 12, 'N' => 12, 'O' => 12,
            'P' => 12, 'Q' => 12, 'R' => 12, 'S' => 12, 'T' => 14,
            'U' => 14, 'V' => 14, 'W' => 14, 'X' => 12, 'Y' => 18,
            'Z' => 12, 'AA' => 12, 'AB' => 10, 'AC' => 12, 'AD' => 18,
            'AE' => 18, 'AF' => 20,
        ];
        foreach ($fixedWidths as $col => $w) {
            $sheet->getColumnDimension($col)->setWidth($w);
        }

        // TOTAL se mantiene visible en el archivo.
        $sheet->getColumnDimension('S')->setVisible(true);

        return [];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet   = $event->sheet->getDelegate();
                $lastRow = $sheet->getHighestRow();
                $lc      = self::LAST_COL;

                if ($lastRow < 5) return;

                $sheet->setAutoFilter("A4:{$lc}4");
                $sheet->freezePane('A5');

                // Alineacion base
                $sheet->getStyle("A5:{$lc}{$lastRow}")->getAlignment()
                    ->setHorizontal(Alignment::HORIZONTAL_CENTER)
                    ->setVertical(Alignment::VERTICAL_CENTER);

                // Texto alineado a la izquierda
                foreach (['D','E','F','G','H','I','J','K','L','AD','AE','AF'] as $c) {
                    $sheet->getStyle("{$c}5:{$c}{$lastRow}")
                        ->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
                }

                // Moneda: N..W (EXONERADO..SALDO PENDIENTE)
                $currency    = '"L" #,##0.00';
                // Mostrar negativos como positivos (solo visual): conserva el valor real para formulas.
                $currencyAbs = '"L" #,##0.00;"L" #,##0.00';
                foreach (['N','O','P','Q','R','S','T','U','V','W'] as $c) {
                    $sheet->getStyle("{$c}5:{$c}{$lastRow}")
                        ->getAlignment()->setHorizontal(Alignment::HORIZONTAL_RIGHT);
                    // T = DISMINUCION, V = MONTO PAGADO: mostrar en positivo sin alterar formulas.
                    $fmt = in_array($c, ['T','V']) ? $currencyAbs : $currency;
                    $sheet->getStyle("{$c}5:{$c}{$lastRow}")
                        ->getNumberFormat()->setFormatCode($fmt);
                }

                // Dias vencidos (col AB): formato numerico simple
                $sheet->getStyle("AB5:AB{$lastRow}")
                    ->getNumberFormat()->setFormatCode('0');

                // Fechas (FECHA, FECHA VENTA, FECHA VCTO.): formato de fecha real dd/mm/yyyy
                foreach (['C', 'Z', 'AA'] as $c) {
                    $sheet->getStyle("{$c}5:{$c}{$lastRow}")
                        ->getNumberFormat()->setFormatCode('dd/mm/yyyy');
                }

                if ($this->superFastMode) {
                    // superFastMode: solo estilos en bloque, cero loops por fila.
                    // Para 27K+ filas el loop individual tarda minutos extra.
                    $sheet->getStyle("A5:{$lc}{$lastRow}")->getFont()->setSize(8);
                    $sheet->getStyle("A4:{$lc}{$lastRow}")->getBorders()->getAllBorders()
                        ->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('E8D5BF');
                    $sheet->getStyle("A4:{$lc}{$lastRow}")->getBorders()->getOutline()
                        ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('e07000');
                    $sheet->getStyle("A4:{$lc}4")->getBorders()->getBottom()
                        ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('b05000');
                    // Fila de totales
                    $sheet->getStyle("A{$lastRow}:{$lc}{$lastRow}")->getFill()
                        ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FFF3E0');
                    $sheet->getStyle("A{$lastRow}:{$lc}{$lastRow}")->getFont()
                        ->setBold(true)->setSize(9)->getColor()->setRGB('7d3f00');
                    return;
                }

                if ($this->fastMode) {
                    // fastMode (<8K filas): colorea solo filas FACTURA, sin sub-filas.
                    for ($row = 5; $row <= $lastRow; $row++) {
                        $meta = $this->rowMeta[$row] ?? ['type' => ''];
                        if (($meta['type'] ?? '') !== self::T_FACTURA) {
                            continue;
                        }

                        $estadoF01 = strtoupper(trim((string)($meta['estado_f01'] ?? '')));
                        $esAnu = str_starts_with($estadoF01, 'ANULAD');
                        $bg    = $esAnu ? 'EBEBEB' : 'FFF3E0';

                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFill()
                            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($bg);
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFont()
                            ->setBold(true)->setSize(8.5);

                        if ($esAnu) {
                            $sheet->getStyle("A{$row}:{$lc}{$row}")->getFont()
                                ->setStrikethrough(true)->getColor()->setRGB('999999');
                        }
                    }

                    $sheet->getStyle("A5:{$lc}{$lastRow}")->getFont()->setSize(8);
                    $sheet->getStyle("A4:{$lc}{$lastRow}")->getBorders()->getAllBorders()
                        ->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('E8D5BF');
                    $sheet->getStyle("A4:{$lc}{$lastRow}")->getBorders()->getOutline()
                        ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('e07000');
                    $sheet->getStyle("A4:{$lc}4")->getBorders()->getBottom()
                        ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('b05000');
                    return;
                }

                // ── Loop por fila ──────────────────────────────
                for ($row = 5; $row <= $lastRow; $row++) {
                    $meta = $this->rowMeta[$row] ?? ['type' => ''];
                    $type = $meta['type'] ?? '';
                    $h    = 13;

                    if ($type === 'TOTALES') {
                        // ── Fila totales ──────────────────────────
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFill()
                            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FFF3E0');
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFont()
                            ->setBold(true)->setSize(9)->getColor()->setRGB('7d3f00');
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getBorders()->getTop()
                            ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('e07000');
                        $h = 16;
                    } elseif ($type === self::T_FACTURA) {                        // ── Fila factura: fondo naranja, negrita ──
                        $estadoF01 = strtoupper(trim((string)($meta['estado_f01'] ?? '')));
                        $esAnu = str_starts_with($estadoF01, 'ANULAD');
                        $bg    = $esAnu ? 'EBEBEB' : 'FFF3E0';

                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFill()
                            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($bg);
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFont()
                            ->setBold(true)->setSize(8.5);
                        if ($esAnu) {
                            $sheet->getStyle("A{$row}:{$lc}{$row}")->getFont()
                                ->setStrikethrough(true)->getColor()->setRGB('999999');
                        }

                        // Dias vencidos (col AB): verde si <= 0, rojo si > 0
                        $dias = (int)($meta['dias_vencidos'] ?? 0);
                        if ($dias > 0) {
                            $sheet->getStyle("AB{$row}")->getFill()
                                ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FADBD8');
                            $sheet->getStyle("AB{$row}")->getFont()
                                ->setBold(true)->getColor()->setRGB('922B21');
                        } else {
                            $sheet->getStyle("AB{$row}")->getFill()
                                ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('D5F5E3');
                            $sheet->getStyle("AB{$row}")->getFont()
                                ->getColor()->setRGB('1E8449');
                        }

                        // Estado cobro (col Y, index 24)
                        $ec   = (string)($meta['estado_cobro'] ?? '');
                        $bgEc = match(true) {
                            $ec === 'Anuladas'                                            => 'EBEBEB',
                            $ec === 'Pagada'                                               => 'D5F5E3',
                            $ec === 'Contado'                                              => 'D6EAF8',
                            $ec === 'Parcialmente Pagada'                                  => 'DBEAFE',
                            str_starts_with($ec, 'Vencida') && str_contains($ec, 'tica')  => 'F5B7B1',
                            $ec === 'Vencida'                                              => 'FADBD8',
                            $ec === 'Pendiente'                                            => 'FDEBD0',
                            default                                                        => 'FDFEFE',
                        };
                        $sheet->getStyle("Y{$row}")->getFill()
                            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($bgEc);
                        $h = 16;

                    } else {
                        // ── Sub-fila (movimiento): sin fondo ──────
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFill()
                            ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FFFFFF');
                        $sheet->getStyle("A{$row}:{$lc}{$row}")->getFont()
                            ->setSize(7.5);

                        $dir = $meta['dir'] ?? 'neutral';

                        // Celda DISMINUCION (col T, idx 19): rojo
                        if ($dir === 'debito') {
                            $sheet->getStyle("T{$row}")->getFill()
                                ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('FADBD8');
                            $sheet->getStyle("T{$row}")->getFont()
                                ->setBold(true)->getColor()->setRGB('922B21');
                        }

                        // Celda AUMENTO (col U, idx 20): verde
                        if ($dir === 'credito') {
                            $sheet->getStyle("U{$row}")->getFill()
                                ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('D5F5E3');
                            $sheet->getStyle("U{$row}")->getFont()
                                ->setBold(true)->getColor()->setRGB('1E8449');
                        }

                        // Celda MONTO PAGADO (col V, idx 21): azul claro para pagos
                        if ($dir === 'pago') {
                            $sheet->getStyle("V{$row}")->getFill()
                                ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('D6EAF8');
                            $sheet->getStyle("V{$row}")->getFont()
                                ->setBold(true)->getColor()->setRGB('1A5276');
                            // Saldo pendiente (col W) tambien en azul tras cada pago
                            $sheet->getStyle("W{$row}")->getFill()
                                ->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('EBF5FB');
                            $sheet->getStyle("W{$row}")->getFont()->getColor()->setRGB('1A5276');
                        }
                    }

                    $sheet->getRowDimension($row)->setRowHeight($h);
                }

                // Bordes globales
                $sheet->getStyle("A4:{$lc}{$lastRow}")->getBorders()->getAllBorders()
                    ->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('E8D5BF');
                $sheet->getStyle("A4:{$lc}{$lastRow}")->getBorders()->getOutline()
                    ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('e07000');
                $sheet->getStyle("A4:{$lc}4")->getBorders()->getBottom()
                    ->setBorderStyle(Border::BORDER_MEDIUM)->getColor()->setRGB('b05000');
            },
        ];
    }
}
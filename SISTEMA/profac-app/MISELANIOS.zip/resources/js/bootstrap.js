window._ = require('lodash');

/**
 * We'll load the axios HTTP library which allows us to easily issue requests
 * to our Laravel back-end. This library automatically handles sending the
 * CSRF token as a header based on the value of the "XSRF" token cookie.
 */

window.axios = require('axios');

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

/**
 * Echo exposes an expressive API for subscribing to channels and listening
 * for events that are broadcast by Laravel. Echo and event broadcasting
 * allows your team to easily build robust real-time web applications.
 */

import Echo from 'laravel-echo';

window.Pusher = require('pusher-js');

// Conexión perezosa: no abrir el WebSocket en cada página, sólo cuando una
// vista que realmente lo necesita (ej. revicioninventario.blade.php) la pida.
window.getProfacEcho = function () {
    if (window.Echo) return window.Echo;

    const reverb = window.PROFAC_REVERB || {};

    window.Echo = new Echo({
        broadcaster: 'reverb',
        key: reverb.key || process.env.MIX_REVERB_APP_KEY,
        wsHost: reverb.host || process.env.MIX_REVERB_HOST,
        wsPort: reverb.port || process.env.MIX_REVERB_PORT || 80,
        wssPort: reverb.port || process.env.MIX_REVERB_PORT || 443,
        forceTLS: (reverb.scheme || process.env.MIX_REVERB_SCHEME || 'https') === 'https',
        enabledTransports: ['ws', 'wss'],
    });

    return window.Echo;
};



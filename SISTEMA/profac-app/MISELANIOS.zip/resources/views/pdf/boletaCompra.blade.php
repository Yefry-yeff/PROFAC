﻿<!DOCTYPE html>
<html>
<head>
        <link rel="stylesheet" href="{{ public_path('css/bootstrap.min.css') }}">
    @include('pdf.partials.legacy-layout')
    <style>
        @page { margin: 28px; }
        p { font-size: 10px; }
        body { margin: 0; padding: 0; width: 100%; }
        .boleta-logo { display:block; width:100%; margin-bottom:8px; }
        .boleta-ancho { width:100% !important; margin-left:0 !important; }

        table {
            border-collapse: collapse;
            border-spacing: 0;
            width: 100%;
            border: 1px solid #ddd;
        }

        th, td {
            text-align: left;
            padding: 3px 5px;
        }

        thead { background-color: #f2f2f2; }

        .letra { font-weight: 800; }
    </style>
    <title>Boleta de Compra</title>
</head>
<body>

@php
    $contadorFilas = 0;
    $altura = 20;
@endphp

<div class="pruebaFondo">
        <img src="{{ public_path('img/membrete/Logo3.png') }}" class="boleta-logo" alt="">

        <b style="display:block; text-align:right; margin-bottom:8px;">*Original*</b>

    {{-- Encabezado CAI --}}
    <div class="border card border-dark boleta-ancho">
        <div class="card-header">
            <b>Boleta de Compra No. {{ $boleta->numero_boleta }}</b>
            <b style="position:absolute; right:10px;">
                Fecha: {{ \Carbon\Carbon::parse($boleta->fecha)->format('d/m/Y') }}
            </b>
        </div>
        <div class="card-body" style="padding:4px 10px;">
            <table style="width:100%; border:none; font-size:10px;">
                <tr><td style="border:none; padding:1px 0;"><b>Registro tributario: 08011986138652</b></td><td style="border:none; padding:1px 0; text-align:right;"><b>CAI: {{ $caiBoleta?->cai ?? 'N/A' }}</b></td></tr>
                <tr><td style="border:none; padding:1px 0;"><b>Fecha límite de emisión: {{ $caiBoleta?->fecha_limite_emision ?? 'N/A' }}</b></td><td style="border:none; padding:1px 0; text-align:right;"><b>Rango autorizado: {{ $caiBoleta ? $caiBoleta->numero_inicial . ' - ' . $caiBoleta->numero_final : 'N/A' }}</b></td></tr>
            </table>
        </div>
    </div>

    {{-- Datos del cliente: Fila 1: Nombre | RTN/DNI | Dirección — Fila 2: Teléfono --}}
    <div class="border card border-dark boleta-ancho" style="margin-top:4px;">
        <div class="card-body" style="padding:8px 12px;">
            <table style="width:100%; font-size:11px; border:none;" cellspacing="0" cellpadding="3">
                <tr>
                    <td style="width:35%; border:none;"><b>Cliente:</b> {{ $boleta->cliente }}</td>
                    <td style="width:25%; border:none;"><b>RTN/DNI:</b> {{ $boleta->rtn_dni ?? '' }}</td>
                    <td style="width:40%; border:none;"><b>Dirección:</b> {{ $boleta->direccion }}</td>
                </tr>
                @if(!empty($boleta->telefono))
                <tr>
                    <td colspan="3" style="border:none;"><b>Teléfono:</b> {{ $boleta->telefono }}</td>
                </tr>
                @endif
            </table>
        </div>
    </div>

    {{-- Tabla de productos --}}
        <div class="border card border-dark boleta-ancho"
            style="position:relative; margin-top:8px; page-break-inside:auto;">
        <div>
            <table style="font-size:11px;">
                <thead>
                    <tr>
                        <th style="width:50px;">Línea</th>
                        <th>Descripción</th>
                        <th style="width:110px;">Precio</th>
                        <th style="width:90px;">Cantidad</th>
                        <th style="width:110px;">Importe</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($detalles as $detalle)
                    <tr>
                        <td>{{ $detalle->linea }}</td>
                        <td>{{ $detalle->descripcion }}</td>
                        <td>{{ $detalle->precio }}</td>
                        <td>{{ $detalle->cantidad }}</td>
                        <td>{{ $detalle->importe }}</td>
                    </tr>
                    @php $contadorFilas++; @endphp
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    @if($contadorFilas > 4 && $contadorFilas < 24)
        @php $altura = 170; @endphp
        <div style="page-break-after: always"></div>
    @else
        @php $altura = 20; @endphp
    @endif

    {{-- Sección inferior --}}
    <div style="position:relative; margin-left:44px;">

        {{-- Tarjeta izquierda: Comentario + Registrado por --}}
        <div class="border card border-dark"
             style="position:absolute; left:0px; margin-top:{{ $altura }}px; width:26rem; height:auto; min-height:5rem;">
            <div class="card-body" style="padding:8px 10px;">
                @if(!empty($boleta->comentario))
                <p class="card-text" style="font-size:11px; margin:0 0 4px 0;">
                    <b>Comentario:</b> {{ $boleta->comentario }}
                </p>
                @endif
                <p class="card-text" style="font-size:12px; margin:0;">
                    <b>Registrado por: </b>{{ $boleta->registrado_por }}
                </p>
                @if(!empty($boleta->editado_por))
                <p class="card-text" style="font-size:11px; margin:2px 0 0 0; color:#555;">
                    <b>Editado por: </b>{{ $boleta->editado_por }}
                    &nbsp;&mdash;&nbsp;
                    {{ \Carbon\Carbon::parse($boleta->editado_at)->format('d/m/Y H:i') }}
                </p>
                @endif
            </div>
        </div>

        {{-- Tarjeta derecha: Totales --}}
        <div class="border card border-dark"
             style="position:absolute; left:430px; margin-top:{{ $altura }}px; width:18rem; height:auto; min-height:5rem;">
            <div class="card-body" style="padding:6px 10px;">
                <table style="width:100%; font-size:11px; border:none;" cellspacing="0" cellpadding="3">
                    <tr>
                        <td style="border:none;"><b>Sub Total:</b></td>
                        <td style="border:none; text-align:right;"><b>L. {{ number_format($boleta->sub_total, 2) }}</b></td>
                    </tr>
                    <tr style="font-size:12px;">
                        <td style="border:none; padding-top:6px;"><b>Total a Pagar:</b></td>
                        <td style="border:none; text-align:right; padding-top:6px;"><b>L. {{ number_format($boleta->total, 2) }}</b></td>
                    </tr>
                </table>
            </div>
        </div>

        {{-- Valor en letras (debajo de los dos recuadros) --}}
        <div style="position:absolute; left:0px; margin-top:{{ $altura + 90 }}px; width:45rem;">
            <p class="card-text" style="font-size:11px; padding:4px 10px;">
                @if($flagCentavos == false)
                    <b>"{{ $numeroLetras . ' CON CERO CENTAVOS' }}"</b>
                @else
                    <b>"{{ $numeroLetras }}"</b>
                @endif
            </p>
        </div>

    </div>

    {{-- Firmas: fijas en la parte inferior de la página --}}
    <div style="position:fixed; bottom:90px; left:44px; width:45rem;">
        <p class="card-text" style="position:absolute; left:60px; top:10px;">
            _______________________________________
        </p>
        <p class="card-text" style="position:absolute; left:400px; top:10px;">
            _______________________________________
        </p>
        <p class="card-text" style="position:absolute; left:62px; top:28px; font-size:10px;">
            <b>Comprador:</b> {{ strtoupper($boleta->cliente) }}
            @if(!empty($boleta->rtn_dni)) | RTN/DNI: {{ $boleta->rtn_dni }} @endif
            @if(!empty($boleta->telefono)) | Tel: {{ $boleta->telefono }} @endif
        </p>
        <p class="card-text" style="position:absolute; left:420px; top:28px;">DISTRIBUCIONES VALENCIA</p>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>
</body>
</html>

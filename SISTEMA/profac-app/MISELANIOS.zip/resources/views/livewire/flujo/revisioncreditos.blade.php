<div>
    <style>
        body .wrapper.wrapper-content.animated.fadeInRight {
            animation: none !important;
            transform: none !important;
        }
    </style>
    {{-- ══════════════════════════════════════════════════════════════════ --}}
    {{--                    REVISIÓN DE CRÉDITO                           --}}
    {{-- ══════════════════════════════════════════════════════════════════ --}}

    {{-- Page header --}}
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2><i class="mr-2 fa fa-credit-card text-primary"></i>Revisión de Crédito</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{ route('dashboard') }}">Inicio</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>Revisión de Crédito</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class="wrapper wrapper-content">

        {{-- ── Mensajes globales ─────────────────────────────────────── --}}
        @if ($mensajeExito && !$flujoId)
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="mr-1 fa fa-check-circle"></i> {{ $mensajeExito }}
            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
        @endif
        @if ($mensajeError && !$flujoId)
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="mr-1 fa fa-exclamation-triangle"></i> {{ $mensajeError }}
            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
        @endif

        {{-- ══════════════════════════════════════════════════════════════ --}}
        {{-- VISTA DETALLE                                                  --}}
        {{-- ══════════════════════════════════════════════════════════════ --}}
        @if ($flujoId)

        <div class="row">
            <div class="col-lg-12">
                <div class="ibox" style="border-radius:14px; overflow:hidden; box-shadow:0 4px 20px rgba(0,0,0,.09);">

                    {{-- Header detalle --}}
                    @php
                        $esAprobado  = ($estadoCredito === 'aprobado');
                        $esRechazado = ($estadoCredito === 'rechazado');
                        $headerColor = $esAprobado ? '#27ae60,#1e8449' : ($esRechazado ? '#e74c3c,#c0392b' : '#1a7efb,#0d6efd');
                    @endphp
                    <div class="ibox-title d-flex align-items-center justify-content-between"
                         style="background:linear-gradient(135deg,{{ $headerColor }}); border:none; padding:14px 22px;">
                        <div>
                            <h5 style="color:#fff; margin:0; font-weight:700; font-size:15px;">
                                <i class="mr-2 fa fa-credit-card"></i>
                                Revisando Flujo #{{ $flujoId }} · Oferta #{{ $cotizacionId }}
                                @if($esSeccionExpo)
                                <span style="display:inline-block; background:#e0f2f1; color:#00695c;
                                             border:1px solid #80cbc4; border-radius:4px; padding:2px 6px;
                                             font-size:10px; font-weight:800; margin-left:5px; vertical-align:middle;">
                                    EXPO
                                </span>
                                @endif
                                @if($flujoData) — {{ $flujoData['cliente'] ?? '—' }} @endif
                                <span style="background:rgba(255,255,255,.2); border-radius:20px; padding:2px 12px; font-size:12px; margin-left:8px;">
                                    {{ strtoupper($estadoCredito ?? 'pendiente') }}
                                </span>
                            </h5>
                            @if($flujoData && ($flujoData['pedido_id'] ?? null))
                            <small style="color:rgba(255,255,255,.8); font-size:11px;">
                                Pedido #{{ $flujoData['pedido_id'] }}
                                @if($flujoData['pedido_fecha'] ?? null)
                                    · {{ \Carbon\Carbon::parse($flujoData['pedido_fecha'])->format('d/m/Y') }}
                                @endif
                            </small>
                            @endif
                        </div>
                        <button type="button" wire:click="cerrarDetalle"
                                style="background:rgba(255,255,255,.2); color:#fff; border:none;
                                       border-radius:8px; padding:6px 14px; font-size:12px; font-weight:700; cursor:pointer;">
                            <i class="mr-1 fa fa-arrow-left"></i> Volver a bandeja
                        </button>
                    </div>

                    <div class="ibox-content" style="padding:22px 26px;">

                        {{-- Mensajes detalle --}}
                        @if ($mensajeExito)
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <i class="mr-1 fa fa-check-circle"></i> {{ $mensajeExito }}
                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                        </div>
                        @endif
                        @if ($mensajeError && !$modalAjusteCreditoVisible)
                        <div class="alert alert-danger" role="alert">
                            <i class="mr-1 fa fa-exclamation-triangle"></i> {{ $mensajeError }}
                        </div>
                        @endif

                        {{-- Resumen del crédito si ya fue procesado --}}
                        @if ($esAprobado)
                        <div style="background:#e8f5e9; border:1px solid #a5d6a7; border-radius:12px; padding:14px 18px; margin-bottom:18px;">
                            <h6 style="color:#2e7d32; font-weight:700; margin-bottom:8px;">
                                <i class="mr-1 fa fa-check-circle"></i> Crédito Aprobado
                            </h6>
                            <div style="font-size:13px; color:#2c3e50; display:flex; flex-wrap:wrap; gap:18px;">
                                @if ($fechaAprobacionActual)
                                <div>
                                    <div style="font-size:11px; color:#66bb6a; font-weight:700; text-transform:uppercase;">Fecha autorización</div>
                                    <div style="font-weight:700;">{{ \Carbon\Carbon::parse($fechaAprobacionActual)->format('d/m/Y') }}</div>
                                </div>
                                @endif
                                @if (!is_null($diasCreditoAprobadosActual))
                                <div>
                                    <div style="font-size:11px; color:#66bb6a; font-weight:700; text-transform:uppercase;">Días aprobados</div>
                                    <div style="font-weight:700;">{{ $diasCreditoAprobadosActual }} días</div>
                                </div>
                                @endif
                                @if ($usuarioAprobadorActual)
                                <div>
                                    <div style="font-size:11px; color:#66bb6a; font-weight:700; text-transform:uppercase;">Aprobado por</div>
                                    <div style="font-weight:700;">{{ $usuarioAprobadorActual }}</div>
                                </div>
                                @endif
                                @if ($obsAprobacionActual)
                                <div>
                                    <div style="font-size:11px; color:#66bb6a; font-weight:700; text-transform:uppercase;">Comentario</div>
                                    <div>{{ $obsAprobacionActual }}</div>
                                </div>
                                @endif
                            </div>
                        </div>
                        @elseif ($esRechazado)
                        <div style="background:#fce4e4; border:1px solid #ef9a9a; border-radius:12px; padding:14px 18px; margin-bottom:18px;">
                            <h6 style="color:#c62828; font-weight:700; margin-bottom:6px;">
                                <i class="mr-1 fa fa-times-circle"></i> Crédito Rechazado
                            </h6>
                            <div style="font-size:13px; color:#2c3e50;">
                                <strong>Motivo:</strong> {{ $motivoRechazoActual }}
                            </div>
                        </div>
                        @endif

                        {{-- Acciones financieras + resumen de solicitud --}}
                        <div style="display:flex; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
                            @if($clienteId)
                            <a href="/estadoCuenta/imprimir/aplicpagos/{{ $clienteId }}"
                               target="_blank"
                               class="btn btn-primary"
                               style="border-radius:8px; font-weight:700;">
                                <i class="mr-1 fa fa-file-text-o"></i> Estado de cuenta
                            </a>
                            @endif

                            @if($cotizacionId)
                            <a href="/cotizacion/imprimir/{{ $cotizacionId }}"
                               target="_blank"
                               class="btn btn-default"
                               style="border-radius:8px; font-weight:700; border:1px solid #d7dde5;">
                                <i class="mr-1 fa fa-print"></i> Imprimir oferta ganadora
                            </a>
                            @endif
                        </div>

                        <div style="border-radius:12px; overflow:hidden; border:1px solid #e8eaf0; margin-bottom:20px;">
                            <div style="background:linear-gradient(135deg,#546e7a,#37474f); padding:10px 16px;">
                                <span style="color:#fff; font-size:13px; font-weight:700;">
                                    <i class="mr-1 fa fa-line-chart"></i>
                                    Validación financiera de la oferta
                                </span>
                            </div>
                            <div style="padding:14px 16px; background:#fff;">
                                <div class="row">
                                    <div class="col-md-4 mb-2">
                                        <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Tipo de pago</div>
                                        <div style="font-size:14px; font-weight:700; color:#2c3e50; text-transform:capitalize;">{{ $tipoPagoSolicitud }}</div>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Fecha emisión</div>
                                        <div style="font-size:14px; font-weight:700; color:#2c3e50;">
                                            {{ $fechaEmisionOferta ? \Carbon\Carbon::parse($fechaEmisionOferta)->format('d/m/Y') : '—' }}
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Fecha vencimiento</div>
                                        <div style="font-size:14px; font-weight:700; color:#2c3e50;">
                                            {{ $fechaVencimientoOferta ? \Carbon\Carbon::parse($fechaVencimientoOferta)->format('d/m/Y') : '—' }}
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Días solicitados del crédito</div>
                                        <div style="font-size:15px; font-weight:800; color:#1565c0;">{{ $diasSolicitadosCredito }}</div>
                                    </div>
                                    @if($comentarioOferta || $comentarioCreditoOferta)
                                    <div class="col-md-4 mb-2">
                                        <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Comentario de la oferta</div>
                                        <div style="font-size:13px; color:#2c3e50; white-space:pre-wrap;">{{ $comentarioOferta ?: '—' }}</div>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Comentario para Créditos</div>
                                        <div style="font-size:13px; color:#2c3e50; white-space:pre-wrap;">{{ $comentarioCreditoOferta ?: '—' }}</div>
                                    </div>
                                    @endif
                                </div>
                                <div style="margin-top:10px; padding-top:10px; border-top:1px solid #eef1f5;">
                                    <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">Monto total de la oferta</div>
                                    <div style="font-size:20px; font-weight:800; color:#e65100;">L {{ number_format($montoTotalOferta, 2, '.', ',') }}</div>
                                </div>
                                {{-- Documentos de la oferta --}}
                                @if($numeroOrdenCompra || $archivoOrdenCompra || $numeroFormaF01 || $archivoFormaF01)
                                <div style="margin-top:12px; padding-top:12px; border-top:1px solid #eef1f5;">
                                    <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700; margin-bottom:8px;">
                                        <i class="mr-1 fa fa-paperclip"></i> Documentos de la oferta
                                    </div>
                                    <div class="row">
                                        @if($numeroOrdenCompra || $archivoOrdenCompra)
                                        <div class="col-md-6 mb-2">
                                            <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">N° Orden de Compra</div>
                                            <div style="font-size:14px; font-weight:700; color:#2c3e50;">{{ $numeroOrdenCompra ?: '—' }}</div>
                                            @if($archivoOrdenCompra)
                                            <a href="/{{ $archivoOrdenCompra }}" target="_blank"
                                               style="font-size:12px; color:#1565c0;">
                                                <i class="fa fa-file mr-1"></i> Ver adjunto
                                            </a>
                                            @endif
                                        </div>
                                        @endif
                                        @if($numeroFormaF01 || $archivoFormaF01)
                                        <div class="col-md-6 mb-2">
                                            <div style="font-size:11px; color:#78909c; text-transform:uppercase; font-weight:700;">N° Forma F01</div>
                                            <div style="font-size:14px; font-weight:700; color:#2c3e50;">{{ $numeroFormaF01 ?: '—' }}</div>
                                            @if($archivoFormaF01)
                                            <a href="/{{ $archivoFormaF01 }}" target="_blank"
                                               style="font-size:12px; color:#1565c0;">
                                                <i class="fa fa-file mr-1"></i> Ver adjunto
                                            </a>
                                            @endif
                                        </div>
                                        @endif
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>

                        {{-- ── Acciones (solo disponibles en estado Pendiente) ── --}}
                        @if ($estadoCredito === 'pendiente')
                        @if (!$confirmAccion)
                        <div class="d-flex gap-2" style="gap:10px;">
                            <button type="button"
                                    wire:click="confirmarAccion('aprobar')"
                                    class="btn btn-success"
                                    style="border-radius:8px; font-weight:700; padding:8px 22px;">
                                <i class="mr-1 fa fa-check-circle"></i> Aprobar Crédito
                            </button>
                            <button type="button"
                                    wire:click="confirmarAccion('rechazar')"
                                    class="btn btn-danger"
                                    style="border-radius:8px; font-weight:700; padding:8px 22px; margin-left:8px;">
                                <i class="mr-1 fa fa-times-circle"></i> Rechazar Crédito
                            </button>
                        </div>
                        @endif

                        {{-- Formulario Aprobar --}}
                        @if ($confirmAccion === 'aprobar')
                        <div style="background:#e8f5e9; border:1px solid #a5d6a7; border-radius:12px; padding:20px 24px; margin-top:16px;">
                            <h6 style="color:#2e7d32; font-weight:700; margin-bottom:14px;">
                                <i class="mr-1 fa fa-check-circle"></i> Confirmar Aprobación de Crédito
                            </h6>
                            <div style="border:1px solid #c8e6c9; border-radius:10px; background:#fff; padding:12px 14px; margin-bottom:14px;">
                                <div style="font-size:12px; font-weight:700; color:#2e7d32; margin-bottom:10px; text-transform:uppercase;">
                                    Datos crediticios del cliente
                                </div>
                                <div style="padding:10px 12px; margin-bottom:12px; background:#f7faf8; border-left:3px solid #1ab394;">
                                    <strong>{{ $flujoData['cliente'] ?? 'Cliente no identificado' }}</strong>
                                    <span class="text-muted" style="margin-left:10px; font-size:12px;">
                                        RTN: {{ $flujoData['rtn'] ?? 'No registrado' }}
                                    </span>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label style="font-size:12px; font-weight:700; color:#2e7d32;">Crédito aprobado</label>
                                        <button type="button" wire:click="abrirAjusteCredito"
                                                class="form-control text-left"
                                                title="Modificar crédito aprobado del cliente"
                                                style="border-radius:8px; font-size:13px; background:#f8f9fa; cursor:pointer; color:#1565c0; font-weight:700;">
                                            <i class="fa fa-pencil mr-1"></i>
                                            L {{ number_format($montoCreditoActual, 2, '.', ',') }}
                                        </button>
                                        <small class="text-muted">Clic para modificar el límite del cliente</small>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label style="font-size:12px; font-weight:700; color:#2e7d32;">Disponible para Crédito</label>
                                        <button type="button" wire:click="abrirMovimientosCredito"
                                                class="form-control text-left"
                                            title="Ver detalle del disponible para crédito"
                                                style="border-radius:8px; font-size:13px; background:#f8f9fa; cursor:pointer; color:#1565c0; font-weight:700;">
                                            <i class="fa fa-list-alt mr-1"></i>
                                            L {{ number_format($montoDisponibleActual, 2, '.', ',') }}
                                        </button>
                                        <small class="text-muted">Clic para ver el cálculo</small>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label style="font-size:12px; font-weight:700; color:#2e7d32;">Monto de crédito</label>
                                        <input type="text" class="form-control" readonly
                                               value="L {{ number_format($montoTotalOferta, 2, '.', ',') }}"
                                               style="border-radius:8px; font-size:13px; background:#f8f9fa;">
                                        <small class="text-muted">Monto total de la oferta</small>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label style="font-size:12px; font-weight:700; color:{{ $montoDisponibleProyectado < 0 ? '#c62828' : '#2e7d32' }};">Monto disponible después de aprobar</label>
                                        <input type="text" class="form-control" readonly
                                             value="L {{ number_format($montoDisponibleProyectado, 2, '.', ',') }}"
                                               style="border-radius:8px; font-size:13px; font-weight:700; background:{{ $montoDisponibleProyectado < 0 ? '#fff3e0' : '#f8f9fa' }}; color:{{ $montoDisponibleProyectado < 0 ? '#c62828' : '#2c3e50' }};">
                                        <small class="text-muted">Disponible para crédito menos oferta</small>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label style="font-size:12px; font-weight:700; color:#2e7d32;">Días de crédito</label>
                                        <input type="number" min="0"
                                               wire:model.live.debounce.300ms="diasCreditoEditable"
                                               class="form-control" style="border-radius:8px; font-size:13px;">
                                        <small class="text-muted">Editable solo para este flujo</small>
                                    </div>
                                </div>

                                @if ($montoDisponibleProyectado < 0)
                                <div class="alert alert-warning" style="margin-bottom:10px; border-radius:8px; font-size:12px;">
                                    <i class="mr-1 fa fa-exclamation-triangle"></i>
                                    Puede aprobar la oferta, pero el disponible para crédito del cliente quedará negativo en
                                    <strong>L {{ number_format(abs($montoDisponibleProyectado), 2, '.', ',') }}</strong>.
                                    La aprobación quedará registrada en la auditoría del cliente.
                                </div>
                                @endif

                                @if (!empty($bloqueosAutorizacion))
                                <div class="alert alert-danger" style="margin-bottom:0; border-radius:8px; font-size:12px;">
                                    @foreach($bloqueosAutorizacion as $bloqueo)
                                        <div><i class="mr-1 fa fa-ban"></i> {{ $bloqueo }}</div>
                                    @endforeach
                                </div>
                                @endif
                            </div>
                                    <div class="col-md-12 mb-3">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label style="font-size:12px; font-weight:700; color:#2e7d32;">
                                        Observaciones <small style="font-weight:400;">(opcional)</small>
                                    </label>
                                    <input type="text"
                                           wire:model.live="observaciones"
                                           class="form-control"
                                           placeholder="Notas adicionales..."
                                           style="border-radius:8px; font-size:13px;">
                                </div>
                            </div>
                            <div class="d-flex" style="gap:8px;">
                                <button type="button"
                                        wire:click="aprobarCredito"
                                        wire:loading.attr="disabled"
                                        @if(!$puedeAutorizar) disabled @endif
                                        class="btn btn-success"
                                    style="border-radius:8px; font-weight:700; {{ !$puedeAutorizar ? 'opacity:.6; cursor:not-allowed;' : '' }}">
                                    <span wire:loading.remove wire:target="aprobarCredito">
                                        <i class="mr-1 fa fa-check"></i> Confirmar Aprobación
                                    </span>
                                    <span wire:loading wire:target="aprobarCredito">
                                        <i class="fa fa-spinner fa-spin mr-1"></i> Guardando...
                                    </span>
                                </button>
                                <button type="button"
                                        wire:click="cancelarAccion"
                                        class="btn btn-default"
                                        style="border-radius:8px; font-weight:700; margin-left:8px;">
                                    <i class="mr-1 fa fa-times"></i> Cancelar
                                </button>
                            </div>
                        </div>
                        @endif

                        {{-- Formulario Rechazar --}}
                        @if ($confirmAccion === 'rechazar')
                        <div style="background:#fce4e4; border:1px solid #ef9a9a; border-radius:12px; padding:20px 24px; margin-top:16px;">
                            <h6 style="color:#c62828; font-weight:700; margin-bottom:14px;">
                                <i class="mr-1 fa fa-times-circle"></i> Confirmar Rechazo de Crédito
                            </h6>
                            <div class="alert alert-warning" style="border-radius:8px; font-size:13px;">
                                <i class="mr-1 fa fa-exclamation-triangle"></i>
                                <strong>Atención:</strong> Al rechazar el crédito, el flujo quedará <strong>cancelado</strong>
                                y no podrá continuar a Revisión de Inventario ni Prefactura.
                            </div>
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label style="font-size:12px; font-weight:700; color:#c62828;">
                                        Motivo de Rechazo <span style="color:#e74c3c;">*</span>
                                    </label>
                                    <textarea wire:model.live="motivoRechazo"
                                              class="form-control"
                                              rows="3"
                                              placeholder="Ingrese el motivo del rechazo de crédito..."
                                              style="border-radius:8px; font-size:13px;"></textarea>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label style="font-size:12px; font-weight:700; color:#c62828;">
                                        Observaciones <small style="font-weight:400;">(opcional)</small>
                                    </label>
                                    <textarea wire:model.live="observaciones"
                                              class="form-control"
                                              rows="3"
                                              placeholder="Notas adicionales..."
                                              style="border-radius:8px; font-size:13px;"></textarea>
                                </div>
                            </div>
                            <div class="d-flex" style="gap:8px;">
                                <button type="button"
                                        wire:click="rechazarCredito"
                                        wire:loading.attr="disabled"
                                        class="btn btn-danger"
                                        style="border-radius:8px; font-weight:700;">
                                    <span wire:loading.remove wire:target="rechazarCredito">
                                        <i class="mr-1 fa fa-ban"></i> Confirmar Rechazo
                                    </span>
                                    <span wire:loading wire:target="rechazarCredito">
                                        <i class="fa fa-spinner fa-spin mr-1"></i> Guardando...
                                    </span>
                                </button>
                                <button type="button"
                                        wire:click="cancelarAccion"
                                        class="btn btn-default"
                                        style="border-radius:8px; font-weight:700; margin-left:8px;">
                                    <i class="mr-1 fa fa-times"></i> Cancelar
                                </button>
                            </div>
                        </div>
                        @endif
                        @endif {{-- end if pendiente --}}

                        {{-- ── Historial de auditoría ── --}}
                        @if (count($historialCredito) > 0)
                        <div style="margin-top:24px;">
                            <h6 style="font-weight:700; color:#546e7a; margin-bottom:12px;">
                                <i class="mr-1 fa fa-history"></i> Historial de Auditoría
                            </h6>
                            <div style="border-radius:10px; overflow:hidden; border:1px solid #e8eaf0;">
                                <table class="table table-sm" style="font-size:12px; margin:0;">
                                    <thead style="background:#f8f9fc;">
                                        <tr>
                                            <th style="padding:8px 12px;">Fecha</th>
                                            @if(!$esSeccionExpo)
                                            <th style="padding:8px 12px;">Oferta</th>
                                            @endif
                                            <th style="padding:8px 12px;">Acción</th>
                                            <th style="padding:8px 12px;">Estado anterior</th>
                                            <th style="padding:8px 12px;">Estado nuevo</th>
                                            <th style="padding:8px 12px;">Usuario</th>
                                            <th style="padding:8px 12px;">Descripción</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($historialCredito as $h)
                                        <tr style="border-bottom:1px solid #f0f0f0;">
                                            <td style="padding:7px 12px; white-space:nowrap; color:#78909c;">
                                                {{ \Carbon\Carbon::parse($h['fecha_evento'])->format('d/m/Y H:i') }}
                                            </td>
                                            @if(!$esSeccionExpo)
                                            <td style="padding:7px 12px; white-space:nowrap; font-weight:700; color:#1565c0;">
                                                #{{ $h['cotizacion_id'] ?? '—' }}
                                            </td>
                                            @endif
                                            <td style="padding:7px 12px;">
                                                @php
                                                    $accionColor = match($h['accion']) {
                                                        'aprobado'  => '#27ae60',
                                                        'rechazado' => '#e74c3c',
                                                        'devuelto_inventario' => '#e67e22',
                                                        'cancelado' => '#95a5a6',
                                                        'creado'    => '#3498db',
                                                        default     => '#546e7a',
                                                    };
                                                    $accionTexto = $h['accion'] === 'devuelto_inventario'
                                                        ? 'Devuelto por Inventario'
                                                        : $h['accion'];
                                                @endphp
                                                <span style="font-weight:700; color:{{ $accionColor }}; text-transform:uppercase; font-size:11px;">
                                                    {{ $accionTexto }}
                                                </span>
                                            </td>
                                            <td style="padding:7px 12px; color:#78909c;">{{ $h['estado_anterior'] ?? '—' }}</td>
                                            <td style="padding:7px 12px; font-weight:700; color:#2c3e50;">{{ $h['estado_nuevo'] ?? '—' }}</td>
                                            <td style="padding:7px 12px; color:#546e7a;">{{ $h['usuario_nombre'] ?? '—' }}</td>
                                            <td style="padding:7px 12px; color:#546e7a; font-size:11px;">{{ $h['descripcion'] ?? '' }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>

        {{-- ══════════════════════════════════════════════════════════════ --}}
        {{-- BANDEJA (cuando NO hay flujo seleccionado)                    --}}
        {{-- ══════════════════════════════════════════════════════════════ --}}
        @else

        <div class="row">
            <div class="col-lg-12">
                <div class="ibox" style="border-radius:14px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.07);">
                    <div class="ibox-title d-flex align-items-center justify-content-between"
                         style="background:linear-gradient(135deg,#1a5276,#154360); border:none; padding:12px 20px;">
                        <h5 style="color:#fff; margin:0; font-weight:700; font-size:14px;">
                            <i class="mr-2 fa fa-credit-card"></i>Bandeja de Revisión de Crédito
                        </h5>
                        <div style="display:flex; align-items:center; gap:10px;">
                            <span style="background:rgba(255,255,255,.15); color:#ecf0f1; border-radius:20px;
                                         padding:3px 14px; font-size:12px; font-weight:600;">
                                {{ $countLlegando }} pendiente(s)
                            </span>
                        </div>
                    </div>

                    <div class="ibox-content" style="padding:0;">

                        {{-- Buscador --}}
                        <div style="padding:16px 20px; border-bottom:1px solid #f0f2f5; display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
                            <div class="input-group" style="max-width:420px;">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="background:#1a5276; border-color:#1a5276; color:#fff;">
                                        <i class="fa fa-search"></i>
                                    </span>
                                </div>
                                <input type="text"
                                       wire:model.live.debounce.400ms="busqueda"
                                       class="form-control"
                                       placeholder="Buscar por cliente, RTN o número de flujo..."
                                       style="font-size:13px;">
                                @if ($busqueda)
                                <div class="input-group-append">
                                    <button type="button"
                                            wire:click="$set('busqueda','')"
                                            class="btn btn-default"
                                            style="border-radius:0 8px 8px 0;">
                                        <i class="fa fa-times"></i>
                                    </button>
                                </div>
                                @endif
                            </div>
                            <div class="d-flex align-items-center" style="gap:6px;">
                                <label style="font-size:12px; color:#78909c; font-weight:600; margin:0; white-space:nowrap;">
                                    Filas por p&aacute;gina:
                                </label>
                                <select wire:model.live="perPage"
                                        class="form-control form-control-sm"
                                        style="width:70px; font-size:13px; border-radius:8px;">
                                    <option value="8">8</option>
                                    <option value="15">15</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                </select>
                            </div>
                        </div>

                        {{-- Pestañas --}}
                        <div style="padding:0 20px; border-bottom:2px solid #e8eaf0;">
                            <ul class="nav" style="gap:0; border:none;">
                                @foreach ([
                                    ['llegando',   'fa-inbox',         'Llegando',  $countLlegando,   '#1a5276'],
                                    ['aprobadas',  'fa-check-circle',  'Aprobadas', $countAprobadas,  '#27ae60'],
                                    ['rechazadas', 'fa-times-circle',  'Rechazadas',$countRechazadas, '#e74c3c'],
                                ] as [$tab, $icon, $label, $count, $color])
                                <li class="nav-item">
                                    <button type="button"
                                            wire:click="cambiarTab('{{ $tab }}')"
                                            style="background:none; border:none; padding:12px 20px;
                                                   font-size:13px; font-weight:700; cursor:pointer;
                                                   color:{{ $tabActiva === $tab ? $color : '#90a4ae' }};
                                                   border-bottom:3px solid {{ $tabActiva === $tab ? $color : 'transparent' }};
                                                   transition:all .2s;">
                                        <i class="mr-1 fa {{ $icon }}"></i>
                                        {{ $label }}
                                        <span style="background:{{ $tabActiva === $tab ? $color : '#e0e3ee' }};
                                                     color:{{ $tabActiva === $tab ? '#fff' : '#78909c' }};
                                                     border-radius:20px; padding:1px 8px; font-size:11px; margin-left:4px;">
                                            {{ $count }}
                                        </span>
                                    </button>
                                </li>
                                @endforeach
                            </ul>
                        </div>

                        {{-- Contenido de la pestaña activa --}}
                        @php
                            $esSoloLectura = in_array($tabActiva, ['aprobadas', 'rechazadas']);
                        @endphp

                        <div style="padding:16px 20px 20px;">
                            @if ($totalRegistros === 0)
                            <div style="text-align:center; padding:40px; color:#aab;">
                                <i class="fa fa-inbox fa-3x d-block mb-3" style="opacity:.3;"></i>
                                <p style="font-size:14px; margin:0;">
                                    @if ($tabActiva === 'llegando')
                                        No hay flujos pendientes de revisión de crédito.
                                    @elseif ($tabActiva === 'aprobadas')
                                        No hay créditos aprobados registrados.
                                    @else
                                        No hay créditos rechazados registrados.
                                    @endif
                                </p>
                            </div>
                            @else
                            <div style="overflow-x:auto;">
                                <table class="table table-hover" style="font-size:13px; min-width:600px;">
                                    <thead style="background:#f8f9fc;">
                                        <tr>
                                            <th style="padding:10px 14px; color:#546e7a;">Flujo</th>
                                            <th style="padding:10px 14px; color:#546e7a;">Cliente</th>
                                            <th style="padding:10px 14px; color:#546e7a;">Oferta</th>
                                            <th style="padding:10px 14px; color:#546e7a;">Estado</th>
                                            <th style="padding:10px 14px; color:#546e7a;">Días solicitados</th>
                                            <th style="padding:10px 14px; color:#546e7a;">Monto oferta</th>
                                            <th style="padding:10px 14px; color:#546e7a;">
                                                @if ($tabActiva === 'llegando') Fecha ingreso
                                                @elseif ($tabActiva === 'aprobadas') Fecha aprobación
                                                @else Motivo rechazo
                                                @endif
                                            </th>
                                            @if ($tabActiva === 'aprobadas')
                                            <th style="padding:10px 14px; color:#546e7a;">Aprobado por</th>
                                            <th style="padding:10px 14px; color:#546e7a;">Comentario</th>
                                            @endif
                                            <th style="padding:10px 14px; color:#546e7a; text-align:center;">Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($registrosPagina as $reg)
                                        @php $r = (array) $reg; @endphp
                                        <tr style="border-bottom:1px solid #f0f2f5; transition:background .15s;"
                                            onmouseover="this.style.background='#f8f9fc'"
                                            onmouseout="this.style.background=''">
                                            <td style="padding:10px 14px;">
                                                <span style="background:#e3f2fd; color:#1565c0; border-radius:20px;
                                                             padding:3px 10px; font-size:12px; font-weight:700;">
                                                    #{{ $r['flujo_id'] }}
                                                </span>
                                                @if($r['identificacion'])
                                                <small class="d-block text-muted" style="font-size:11px; margin-top:2px;">
                                                    ID: {{ $r['identificacion'] }}
                                                </small>
                                                @endif
                                            </td>
                                            <td style="padding:10px 14px;">
                                                <div style="font-weight:600; color:#2c3e50;">{{ $r['cliente'] }}</div>
                                                @if($r['rtn'])
                                                <small style="color:#78909c; font-size:11px;">RTN: {{ $r['rtn'] }}</small>
                                                @endif
                                            </td>
                                            <td style="padding:10px 14px;">
                                                @if($r['cotizacion_id'])
                                                <span style="background:#f3e5f5; color:#6a1b9a; border-radius:20px;
                                                             padding:2px 10px; font-size:12px; font-weight:700;">
                                                    #{{ $r['cotizacion_id'] }}
                                                </span>
                                                @if(!empty($r['es_expo']))
                                                <span style="display:inline-block; margin-left:5px; background:#e0f2f1; color:#00695c;
                                                             border:1px solid #80cbc4; border-radius:4px; padding:2px 6px;
                                                             font-size:10px; font-weight:800; vertical-align:middle;">
                                                    EXPO
                                                </span>
                                                @endif
                                                @else
                                                <span class="text-muted">—</span>
                                                @endif
                                            </td>
                                            <td style="padding:10px 14px;">
                                                <span class="badge {{ ($r['estado_credito'] ?? '') === 'aprobado' ? 'badge-success' : ((($r['estado_credito'] ?? '') === 'pendiente') ? 'badge-warning' : 'badge-danger') }}">
                                                    {{ strtoupper($r['estado_credito'] ?? 'pendiente') }}
                                                </span>
                                                @if($r['seccion_nombre'] ?? null)
                                                    <small class="d-block text-muted mt-1">{{ $r['seccion_nombre'] }}</small>
                                                @endif
                                            </td>
                                            <td style="padding:10px 14px; text-align:center;">
                                                <span style="background:#e8eaf0; border-radius:20px;
                                                             padding:2px 10px; font-size:12px; color:#546e7a;">
                                                    {{ (int)($r['dias_solicitados_credito'] ?? 0) }}
                                                </span>
                                            </td>
                                            <td style="padding:10px 14px; font-weight:700; color:#e65100;">
                                                L {{ number_format((float)($r['monto_total_oferta'] ?? 0), 2, '.', ',') }}
                                            </td>
                                            <td style="padding:10px 14px; font-size:12px; color:#78909c;">
                                                @if ($tabActiva === 'llegando')
                                                    {{ \Carbon\Carbon::parse($r['fecha_revision'])->format('d/m/Y H:i') }}
                                                @elseif ($tabActiva === 'aprobadas')
                                                    {{ $r['fecha_aprobacion']
                                                        ? \Carbon\Carbon::parse($r['fecha_aprobacion'])->format('d/m/Y')
                                                        : \Carbon\Carbon::parse($r['fecha_accion'])->format('d/m/Y H:i') }}
                                                @else
                                                    <span style="color:#c62828; font-size:12px;">
                                                        {{ \Illuminate\Support\Str::limit($r['motivo_rechazo'] ?? '—', 40) }}
                                                    </span>
                                                @endif
                                            </td>
                                            @if ($tabActiva === 'aprobadas')
                                            <td style="padding:10px 14px; font-size:12px; color:#2c3e50;">
                                                {{ $r['usuario_aprobador'] ?? '—' }}
                                            </td>
                                            <td style="padding:10px 14px; font-size:12px; color:#546e7a;">
                                                {{ $r['obs_credito'] ? \Illuminate\Support\Str::limit($r['obs_credito'], 50) : '—' }}
                                            </td>
                                            @endif
                                            <td style="padding:10px 14px; text-align:center;">
                                                <button type="button"
                                                        wire:click="seleccionarFlujo({{ $r['flujo_id'] }}{{ ($r['seccion_numero'] ?? null) ? ', ' . $r['cotizacion_id'] : '' }})"
                                                        class="btn btn-sm"
                                                        style="background:#1a5276; color:#fff; border-radius:20px;
                                                               font-size:12px; padding:4px 14px; font-weight:600;">
                                                    <i class="fa fa-eye mr-1"></i>
                                                    {{ $esSoloLectura ? 'Ver' : 'Revisar' }}
                                                </button>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @endif

                            {{-- Paginación --}}
                            @if ($totalRegistros > 0)
                            @php
                                $rangoInicio = max(1, $paginaActual - 2);
                                $rangoFin    = min($totalPaginas, $paginaActual + 2);
                            @endphp
                            <div class="d-flex align-items-center justify-content-between mt-3" style="font-size:13px; flex-wrap:wrap; gap:8px;">
                                <div style="color:#78909c;">
                                    Mostrando
                                    <strong>{{ ($paginaActual - 1) * $perPage + 1 }}</strong>
                                    –
                                    <strong>{{ min($paginaActual * $perPage, $totalRegistros) }}</strong>
                                    de <strong>{{ $totalRegistros }}</strong> registros
                                </div>
                                @if ($totalPaginas > 1)
                                <ul class="pagination pagination-sm mb-0" style="flex-wrap:wrap;">
                                    <li class="page-item {{ $paginaActual <= 1 ? 'disabled' : '' }}">
                                        <button type="button"
                                                wire:click="irPagina('{{ $tabActiva }}', {{ $paginaActual - 1 }})"
                                                class="page-link">
                                            <i class="fa fa-chevron-left"></i>
                                        </button>
                                    </li>
                                    @if ($rangoInicio > 1)
                                    <li class="page-item">
                                        <button type="button" wire:click="irPagina('{{ $tabActiva }}', 1)" class="page-link">1</button>
                                    </li>
                                    @if ($rangoInicio > 2)
                                    <li class="page-item disabled"><span class="page-link">&hellip;</span></li>
                                    @endif
                                    @endif
                                    @for ($i = $rangoInicio; $i <= $rangoFin; $i++)
                                    <li class="page-item {{ $paginaActual === $i ? 'active' : '' }}">
                                        <button type="button"
                                                wire:click="irPagina('{{ $tabActiva }}', {{ $i }})"
                                                class="page-link">{{ $i }}</button>
                                    </li>
                                    @endfor
                                    @if ($rangoFin < $totalPaginas)
                                    @if ($rangoFin < $totalPaginas - 1)
                                    <li class="page-item disabled"><span class="page-link">&hellip;</span></li>
                                    @endif
                                    <li class="page-item">
                                        <button type="button" wire:click="irPagina('{{ $tabActiva }}', {{ $totalPaginas }})" class="page-link">{{ $totalPaginas }}</button>
                                    </li>
                                    @endif
                                    <li class="page-item {{ $paginaActual >= $totalPaginas ? 'disabled' : '' }}">
                                        <button type="button"
                                                wire:click="irPagina('{{ $tabActiva }}', {{ $paginaActual + 1 }})"
                                                class="page-link">
                                            <i class="fa fa-chevron-right"></i>
                                        </button>
                                    </li>
                                </ul>
                                @endif
                            </div>
                            @endif

                        </div>

                    </div>
                </div>
            </div>
        </div>

        @endif {{-- end if flujoId --}}

        @if($modalMovimientosCreditoVisible)
        <div class="modal fade show" style="display:flex; align-items:center; justify-content:center; padding:20px; background:rgba(0,0,0,.45);" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document"
                 style="width:100%; max-width:1100px; max-height:calc(100vh - 40px); margin:0;">
                <div class="modal-content" style="border-radius:10px; overflow:hidden; max-height:calc(100vh - 40px);">
                    <div class="modal-header" style="background:#37474f; color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-list-alt mr-2"></i>Movimientos del crédito</h5>
                        <button type="button" wire:click="cerrarMovimientosCredito" class="close" style="color:#fff;"><span>&times;</span></button>
                    </div>
                    <div class="modal-body" style="overflow-y:auto;">
                        @php $detalleCredito = $detalleMovimientosCredito; @endphp
                        <div class="row mb-4">
                            <div class="col-md-3"><strong>Crédito aprobado:</strong><br>L {{ number_format($detalleCredito['credito_aprobado'] ?? 0, 2, '.', ',') }}</div>
                            <div class="col-md-3"><strong>Monto en facturaciones:</strong><br>L {{ number_format($detalleCredito['monto_facturaciones'] ?? 0, 2, '.', ',') }}</div>
                            <div class="col-md-3"><strong>Pendientes de facturar:</strong><br>L {{ number_format($detalleCredito['pendiente_facturar'] ?? 0, 2, '.', ',') }}</div>
                            <div class="col-md-3"><strong>Disponible para Crédito:</strong><br>L {{ number_format($detalleCredito['saldo_pendiente'] ?? 0, 2, '.', ',') }}</div>
                        </div>
                        <h6 style="font-weight:700;">Monto en facturaciones</h6>
                        <div class="table-responsive mb-4">
                            <table class="table table-sm table-striped">
                                <thead><tr><th>Factura</th><th>Fecha</th><th class="text-right">Total</th><th class="text-right">Saldo pendiente</th></tr></thead>
                                <tbody>
                                    @forelse(($detalleCredito['cuentas'] ?? []) as $cuenta)
                                    <tr>
                                        <td>#{{ $cuenta['numero_factura'] ?: $cuenta['factura_id'] }}</td>
                                        <td>{{ $cuenta['fecha_emision'] ? \Carbon\Carbon::parse($cuenta['fecha_emision'])->format('d/m/Y') : '—' }}</td>
                                        <td class="text-right">L {{ number_format($cuenta['total_factura_cargo'] ?? 0, 2, '.', ',') }}</td>
                                        <td class="text-right font-weight-bold">L {{ number_format($cuenta['saldo'] ?? 0, 2, '.', ',') }}</td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="4" class="text-center text-muted">No hay cuentas pendientes.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        <h6 style="font-weight:700;">Pendientes de facturar</h6>
                        <div class="table-responsive mb-4">
                            <table class="table table-sm table-striped">
                                <thead><tr><th>Fecha aprobación</th><th>Oferta / flujo</th><th>Usuario</th><th class="text-right">Monto</th></tr></thead>
                                <tbody>
                                    @forelse(($detalleCredito['pendientes_facturar'] ?? []) as $pendiente)
                                    <tr>
                                        <td>{{ $pendiente['fecha_aprobacion'] ? \Carbon\Carbon::parse($pendiente['fecha_aprobacion'])->format('d/m/Y') : '—' }}</td>
                                        <td>Oferta #{{ $pendiente['cotizacion_id'] }} / Flujo #{{ $pendiente['flujo_id'] }}</td>
                                        <td>{{ $pendiente['usuario'] ?? '—' }}</td>
                                        <td class="text-right font-weight-bold">L {{ number_format($pendiente['monto'], 2, '.', ',') }}</td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="4" class="text-center text-muted">No hay ofertas aprobadas pendientes de facturar.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        <h6 style="font-weight:700;">Auditoría de crédito</h6>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped">
                                <thead><tr><th>Fecha</th><th>Oferta / flujo</th><th>Usuario</th><th>Detalle</th><th class="text-right">Monto</th><th class="text-right">Saldo anterior</th><th class="text-right">Saldo resultante</th></tr></thead>
                                <tbody>
                                    @forelse(($detalleCredito['aprobaciones'] ?? []) as $movimiento)
                                    <tr>
                                        <td>{{ \Carbon\Carbon::parse($movimiento['created_at'])->format('d/m/Y H:i') }}</td>
                                        <td>Oferta #{{ $movimiento['cotizacion_id'] }} / Flujo #{{ $movimiento['flujo_id'] }}</td>
                                        <td>{{ $movimiento['usuario'] ?? '—' }}</td>
                                        <td>{{ $movimiento['descripcion'] ?? '—' }}</td>
                                        <td class="text-right">L {{ number_format($movimiento['monto'], 2, '.', ',') }}</td>
                                        <td class="text-right">L {{ number_format($movimiento['saldo_anterior'], 2, '.', ',') }}</td>
                                        <td class="text-right font-weight-bold {{ $movimiento['saldo_resultante'] < 0 ? 'text-danger' : '' }}">L {{ number_format($movimiento['saldo_resultante'], 2, '.', ',') }}</td>
                                    </tr>
                                    @empty
                                    <tr><td colspan="7" class="text-center text-muted">No hay movimientos auditados con este detalle.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cerrarMovimientosCredito" class="btn btn-default">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        @endif

        @if($modalAjusteCreditoVisible)
        <div class="modal fade show" style="display:flex; align-items:center; justify-content:center; padding:20px; background:rgba(0,0,0,.45);" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document" style="width:100%; max-width:620px; margin:0;">
                <div class="modal-content" style="border-radius:10px; overflow:hidden;">
                    <div class="modal-header" style="background:#1565c0; color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-pencil-square-o mr-2"></i>Modificar crédito aprobado</h5>
                        <button type="button" wire:click="cerrarAjusteCredito" class="close" style="color:#fff;"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <div style="padding:10px 12px; margin-bottom:14px; background:#f5f8fb; border-left:3px solid #1565c0;">
                            <strong>{{ $flujoData['cliente'] ?? 'Cliente' }}</strong>
                            <div class="text-muted" style="font-size:12px;">
                                Crédito actual: L {{ number_format($montoCreditoActual, 2, '.', ',') }} · {{ $diasCreditoActual }} días
                            </div>
                        </div>
                        <div class="alert alert-info" style="font-size:12px;">
                            Este cambio actualizará el crédito global del cliente y recalculará automáticamente su disponible para crédito.
                        </div>
                        @if($montoDisponibleActual < 0)
                        <div class="alert alert-warning" style="font-size:13px;">
                            <i class="fa fa-exclamation-triangle mr-1"></i>
                            Al cliente le hacen falta <strong>L {{ number_format(abs($montoDisponibleActual), 2, '.', ',') }}</strong>
                            para que su disponible para crédito quede en L 0.00 y no en negativo.
                        </div>
                        @endif
                        <div class="form-group">
                            <label style="font-weight:700;">Nuevo crédito aprobado</label>
                            <div class="input-group">
                                <div class="input-group-prepend"><span class="input-group-text">L</span></div>
                                <input type="text" wire:model.live="nuevoCreditoClienteTexto"
                                       class="form-control" inputmode="decimal" placeholder="0.00">
                            </div>
                        </div>
                        <div class="form-group">
                            <label style="font-weight:700;">Días de crédito</label>
                            <input type="number" wire:model.live="nuevosDiasCreditoCliente"
                                   class="form-control" min="0" max="365" step="1">
                            <small class="text-muted">Se actualizarán también en la ficha del cliente.</small>
                        </div>
                        <div class="form-group mb-0">
                            <label style="font-weight:700;">Motivo del cambio <span class="text-danger">*</span></label>
                            <textarea wire:model.live="motivoAjusteCredito" class="form-control" rows="3"
                                      maxlength="500" placeholder="Explique por qué se modifica el crédito del cliente..."></textarea>
                            <small class="text-muted">El monto anterior, nuevo monto, usuario, flujo, oferta y motivo quedarán auditados.</small>
                        </div>
                        @if($mensajeError)
                        <div class="alert alert-danger mt-3 mb-0" style="font-size:12px;">
                            <i class="fa fa-exclamation-triangle mr-1"></i>{{ $mensajeError }}
                        </div>
                        @endif
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cerrarAjusteCredito" class="btn btn-default">Cancelar</button>
                        <button type="button" wire:click="guardarAjusteCredito" wire:loading.attr="disabled"
                                class="btn btn-primary">
                            <span wire:loading.remove wire:target="guardarAjusteCredito"><i class="fa fa-save mr-1"></i>Guardar cambio</span>
                            <span wire:loading wire:target="guardarAjusteCredito"><i class="fa fa-spinner fa-spin mr-1"></i>Guardando...</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        @endif

    </div>
</div>


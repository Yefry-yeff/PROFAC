<?php

namespace Tests\Feature;

use App\Livewire\Reportes\CarteraDeCobros;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Livewire\Livewire;
use Tests\TestCase;
use App\Mail\FacturaCobro;
use App\Livewire\Ventas\FacturacionCorporativa;
use Illuminate\Support\Facades\Mail;
use Mockery\MockInterface;
use Symfony\Component\Mailer\Exception\TransportException;
use App\Livewire\CuentasPorCobrar\CorreoCobro;
use App\Livewire\CuentasPorCobrar\EstadoCuentaVendedor;
use App\Services\SaldoCobro;

class CarteraDeCobrosTest extends TestCase
{
    public function createApplication()
    {
        $app = require __DIR__ . '\..\..\bootstrap\app.php';
        $app->make(Kernel::class)->bootstrap();
        $app['config']->set('database.connections.cartera_testing', [
            'driver' => 'sqlite', 'database' => ':memory:', 'prefix' => '', 'foreign_key_constraints' => true,
        ]);
        $app['config']->set('database.default', 'cartera_testing');
        $app['config']->set('session.driver', 'array');
        $app['config']->set('cache.default', 'array');

        return $app;
    }

    protected function setUp(): void
    {
        parent::setUp();
        CarbonImmutable::setTestNow(CarbonImmutable::parse('2026-11-02 12:00:00'));
        Schema::create('users', function (Blueprint $t) { $t->id(); $t->string('name'); $t->integer('rol_id')->default(1); });
        Schema::create('rol', fn (Blueprint $t) => $t->id());
        Schema::create('usuario_rol', function (Blueprint $t) { $t->integer('usuario_id'); $t->integer('rol_id'); });
        Schema::create('usuario_submenu', function (Blueprint $t) { $t->integer('usuario_id'); $t->integer('sub_menu_id'); $t->boolean('permitido'); });
        Schema::create('sub_menu', function (Blueprint $t) { $t->id(); $t->string('url'); $t->integer('estado_id')->default(1); $t->integer('orden')->default(1); });
        Schema::create('rol_submenu', function (Blueprint $t) { $t->integer('rol_id'); $t->integer('sub_menu_id'); });
        Schema::create('cliente', function (Blueprint $t) { $t->id(); $t->string('nombre'); $t->string('correo')->nullable(); });
        Schema::create('banco', function (Blueprint $t) { $t->id(); $t->string('nombre'); $t->string('cuenta')->nullable(); });
        Schema::create('cliente_usuario', function (Blueprint $t) { $t->integer('cliente_id'); $t->integer('usuario_id'); $t->integer('rol_id'); });
        Schema::create('pago_venta', function (Blueprint $t) { $t->id(); $t->integer('factura_id'); $t->integer('estado_venta_id'); $t->decimal('monto', 12, 2); });
        Schema::create('factura', function (Blueprint $t) {
            $t->id(); $t->integer('cliente_id'); $t->string('cai'); $t->integer('numero_secuencia_cai');
            $t->date('fecha_emision')->nullable(); $t->date('fecha_vencimiento')->nullable();
            $t->integer('vendedor')->nullable(); $t->integer('users_id')->nullable(); $t->integer('gestor_entrega')->nullable();
            $t->integer('estado_venta_id')->default(1); $t->integer('tipo_venta_id')->default(1);
            $t->decimal('total', 12, 2)->default(100); $t->decimal('sub_total', 12, 2)->default(100);
            $t->string('nombre_cliente')->nullable(); $t->string('rtn')->nullable(); $t->decimal('isv', 12, 2)->default(0);
        });
        Schema::create('producto', function (Blueprint $t) { $t->id(); $t->string('nombre'); });
        Schema::create('unidad_medida', function (Blueprint $t) { $t->id(); $t->string('nombre'); });
        Schema::create('unidad_medida_venta', function (Blueprint $t) { $t->id(); $t->integer('unidad_medida_id'); });
        Schema::create('venta_has_producto', function (Blueprint $t) {
            $t->id(); $t->integer('factura_id'); $t->integer('producto_id'); $t->integer('unidad_medida_venta_id')->nullable(); $t->integer('indice');
            $t->decimal('precio_unidad', 12, 2); $t->decimal('cantidad_s', 12, 2); $t->decimal('sub_total_s', 12, 2);
            $t->decimal('isv_s', 12, 2); $t->decimal('total_s', 12, 2);
        });
        Schema::create('aplicacion_pagos', function (Blueprint $t) {
            $t->id(); $t->integer('factura_id'); $t->integer('estado')->default(1);
            $t->integer('estado_cerrado')->nullable(); $t->decimal('saldo', 12, 2);
            $t->decimal('total_factura_cargo', 12, 2)->nullable();
        });
        Schema::create('abonos_creditos', function (Blueprint $t) {
            $t->id(); $t->integer('factura_id'); $t->integer('estado_abono')->default(1);
            $t->decimal('monto_abonado', 12, 2); $t->dateTime('fecha_pago');
            $t->integer('usr_registro')->nullable();
        });
        DB::table('users')->insert([['id' => 1, 'name' => 'Ana', 'rol_id' => 2], ['id' => 2, 'name' => 'Luis', 'rol_id' => 2], ['id' => 3, 'name' => 'Maria', 'rol_id' => 2]]);
        DB::table('cliente')->insert([['id' => 1, 'nombre' => 'Cliente A'], ['id' => 2, 'nombre' => 'Cliente B']]);
        DB::table('usuario_submenu')->insert(['usuario_id' => 1, 'sub_menu_id' => 1, 'permitido' => true]);
        DB::table('sub_menu')->insert(['id' => 1, 'url' => 'reportes/cartera_de_cobros']);
        $this->actingAs(User::findOrFail(1));
    }

    protected function tearDown(): void
    {
        CarbonImmutable::setTestNow();
        parent::tearDown();
    }

    private function factura(int $id, array $valores = [], ?string $saldo = '100.00', array $cuenta = []): void
    {
        DB::table('factura')->insert(array_merge([
            'id' => $id, 'cliente_id' => 1, 'cai' => 'F-' . $id, 'numero_secuencia_cai' => $id,
            'fecha_emision' => '2026-01-01', 'fecha_vencimiento' => '2026-10-01',
            'vendedor' => 1, 'users_id' => 2, 'gestor_entrega' => 3,
        ], $valores));
        if ($saldo !== null) {
            DB::table('aplicacion_pagos')->insert(array_merge([
                'factura_id' => $id, 'saldo' => $saldo, 'total_factura_cargo' => '100.00',
            ], $cuenta));
        }
    }

    public function test_issue_date_range_is_inclusive_optional_on_each_side_and_validated(): void
    {
        $this->factura(1, ['fecha_emision' => '2026-01-31']);
        $this->factura(2, ['fecha_emision' => '2026-02-01']);
        $this->factura(3, ['fecha_emision' => '2026-02-28 15:30:00']);
        $this->factura(4, ['fecha_emision' => '2026-03-01']);
        $this->factura(5, ['fecha_emision' => null]);
        $ids = fn (array $esperados) => fn ($detalle) => collect($detalle)->pluck('id')->sort()->values()->all() === $esperados;

        $componente = Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('detalleCompleto', $ids([1, 2, 3, 4, 5]))
            ->set('emisionDesde', '2026-02-01')->set('emisionHasta', '2026-02-28')
            ->assertHasNoErrors()
            ->assertViewHas('metricas', fn ($m) => $m['facturas'] === 2)
            ->assertViewHas('detalleCompleto', $ids([2, 3]))
            ->set('emisionHasta', '')->assertViewHas('detalleCompleto', $ids([2, 3, 4]))
            ->set('emisionDesde', '')->set('emisionHasta', '2026-01-31')->assertViewHas('detalleCompleto', $ids([1]))
            ->set('emisionDesde', '2026-03-01')
            ->assertHasErrors(['emisionHasta'])->assertViewHas('detalleCompleto', $ids([]));

        $componente->set('emisionDesde', 'no-fecha')->set('emisionHasta', '')
            ->assertHasErrors(['emisionDesde'])
            ->call('limpiar')->assertSet('emisionDesde', '')->assertSet('emisionHasta', '')
            ->assertHasNoErrors()->assertViewHas('detalleCompleto', $ids([1, 2, 3, 4, 5]));
    }

    public function test_current_balance_rules_include_unsynchronized_invoices_without_writes(): void
    {
        $this->factura(1, ['total' => 150], '60.00');
        $this->factura(2, [], null);
        $this->factura(3, ['estado_venta_id' => 0]);
        $this->factura(4, [], '100', ['estado_cerrado' => 2]);
        $this->factura(5, [], '0');
        $this->factura(6, [], '-10');
        $this->factura(7, ['tipo_venta_id' => 3, 'sub_total' => 80, 'total' => 92], '50');

        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 24000 && $m['facturas'] === 3)
            ->assertSee('L 240.00');
        $this->assertSame(6, DB::table('aplicacion_pagos')->count());
        $this->assertEquals(60, DB::table('aplicacion_pagos')->where('factura_id', 1)->value('saldo'));
    }

    public function test_invoice_modal_groups_warehouse_lots_and_preserves_original_totals_and_current_balance(): void
    {
        $this->factura(1, ['nombre_cliente' => 'Cliente al facturar', 'rtn' => '000123', 'sub_total' => 100, 'isv' => 15, 'total' => 115], '60');
        DB::table('producto')->insert(['id' => 1, 'nombre' => 'Producto de factura']);
        DB::table('unidad_medida')->insert(['id' => 1, 'nombre' => 'Unidad']);
        DB::table('unidad_medida_venta')->insert(['id' => 1, 'unidad_medida_id' => 1]);
        foreach ([1, 3] as $cantidad) {
            DB::table('venta_has_producto')->insert([
                'factura_id' => 1, 'producto_id' => 1, 'unidad_medida_venta_id' => 1, 'indice' => 1,
                'precio_unidad' => 25, 'cantidad_s' => $cantidad, 'sub_total_s' => 25 * $cantidad,
                'isv_s' => 3.75 * $cantidad, 'total_s' => 28.75 * $cantidad,
            ]);
        }
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('detalleFactura', null)
            ->call('abrirFactura', 1)->assertSet('facturaDetalleId', 1)
            ->assertSee('Cliente al facturar')->assertSee('000123')->assertSee('Producto de factura')
            ->assertSee('Imprimir copia')->assertSee('L 75.00')
            ->assertViewHas('detalleFactura', fn ($d) => $d['productos']->count() === 1
                && (float) $d['productos']->first()->cantidad === 4.0
                && (float) $d['productos']->first()->total === 115.0
                && (float) $d['factura']->total === 115.0 && (float) $d['saldo']->saldo === 75.0
                && $d['copia'] === url('factura/cooporativoCopia/1'))
            ->call('cerrarFactura')->assertSet('facturaDetalleId', null)->assertViewHas('detalleFactura', null);
        $this->assertSame(1, DB::table('aplicacion_pagos')->count());
        $this->assertEquals(60, DB::table('aplicacion_pagos')->value('saldo'));
    }

    public function test_exempt_invoice_modal_uses_exempt_copy_and_handles_no_products(): void
    {
        $this->factura(1, ['tipo_venta_id' => 3, 'sub_total' => 80, 'total' => 92], '50');
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)
            ->assertSee('Esta factura no tiene productos registrados.')
            ->assertViewHas('detalleFactura', fn ($d) => $d['copia'] === url('exonerado/facturaCopia/1')
                && (float) $d['saldo']->saldo === 30.0);
    }

    public function test_invoice_modal_rejects_unavailable_or_filtered_out_invoices(): void
    {
        $this->factura(1, ['estado_venta_id' => 0]);
        $this->factura(2, [], '0');
        $this->factura(3, [], '100', ['estado_cerrado' => 2]);
        $this->factura(4, ['cliente_id' => 2]);
        foreach ([1, 2, 3, 999] as $id) {
            Livewire::test(CarteraDeCobros::class)->call('abrirFactura', $id)->assertNotFound();
        }
        Livewire::test(CarteraDeCobros::class)->set('cliente', '1')->call('abrirFactura', 4)->assertNotFound();
        $componente = Livewire::test(CarteraDeCobros::class);
        DB::table('usuario_submenu')->where('usuario_id', 1)->update(['permitido' => false]);
        $componente->call('abrirFactura', 4)->assertForbidden();
    }

    private function prepararPruebaCorreo(): void
    {
        $this->factura(1, ['nombre_cliente' => 'Cliente de factura', 'total' => 150], '60');
        DB::table('cliente')->where('id', 1)->update(['correo' => 'cliente@example.test']);
        DB::table('banco')->insert([
            ['nombre' => 'Banco autorizado', 'cuenta' => '000123'],
            ['nombre' => 'PROmerica - Cuenta depósitos', 'cuenta' => '999999'],
        ]);
        config(['mail.default' => 'smtp']);
        Mail::fake();
        $this->mock(FacturacionCorporativa::class, function (MockInterface $mock) {
            $mock->shouldReceive('imprimirFacturaCoorporativaCopia')->with(1)->andReturn(response('%PDF-1.7 copia de prueba'));
        });
    }

    public function test_invoice_email_confirms_address_and_attaches_pdf_with_current_balance_and_company_payment_details(): void
    {
        $this->prepararPruebaCorreo();
        $componente = Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)
            ->call('prepararCorreoFactura')->assertSet('correoFactura', 'cliente@example.test')
            ->call('solicitarEnvioFactura')->assertHasErrors('correoCorrecto');
        Mail::assertNothingSent();
        $componente->set('correoCorrecto', true)->call('solicitarEnvioFactura')
            ->assertSet('correoEnviado', true)->assertSee('Factura enviada a cliente@example.test.');
        Mail::assertSent(FacturaCobro::class, function ($mail) {
            $html = $mail->render();
            $this->assertTrue($mail->hasTo('cliente@example.test'));
            $this->assertTrue($mail->hasFrom(FacturaCobro::REMITENTE));
            $this->assertTrue($mail->hasReplyTo(FacturaCobro::REMITENTE));
            $this->assertSame(11000, $mail->saldoCentavos);
            $this->assertSame('F-1', $mail->numeroFactura);
            $this->assertCount(1, $mail->rawAttachments);
            $this->assertStringStartsWith('%PDF-', $mail->rawAttachments[0]['data']);
            $this->assertSame('application/pdf', $mail->rawAttachments[0]['options']['mime']);
            foreach (['Cliente de factura', 'L 110.00', '000123', '2234-9877', 'Col. Godoy'] as $texto) {
                $this->assertStringContainsString($texto, $html);
            }
            $this->assertStringNotContainsString('999999', $html);
            return true;
        });
        Mail::assertSentCount(1);
        $this->assertSame('cliente@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
        $componente->call('enviarCorreoFactura', false)->assertStatus(422);
        Mail::assertSentCount(1);
    }

    public function test_changed_invoice_email_is_not_sent_until_optional_customer_update_is_decided(): void
    {
        $this->prepararPruebaCorreo();
        $componente = Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->set('correoFactura', 'nuevo@example.test')->set('correoCorrecto', true)
            ->call('solicitarEnvioFactura')->assertSet('etapaCorreo', 'actualizar')
            ->assertSee('¿Desea actualizar el correo del cliente con esta dirección?');
        Mail::assertNothingSent();
        $componente->call('enviarCorreoFactura', false)->assertSet('correoEnviado', true);
        $this->assertSame('cliente@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
        Mail::assertSent(FacturaCobro::class, fn ($mail) => $mail->hasTo('nuevo@example.test'));
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->set('correoFactura', 'actualizado@example.test')->set('correoCorrecto', true)
            ->call('solicitarEnvioFactura')->call('enviarCorreoFactura', true)
            ->assertSet('correoEnviado', true)->assertSee('El correo del cliente fue actualizado.');
        $this->assertSame('actualizado@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
        $this->assertEquals(60, DB::table('aplicacion_pagos')->value('saldo'));
    }

    public function test_invoice_email_missing_or_invalid_address_requires_confirmation_and_does_not_send(): void
    {
        $this->prepararPruebaCorreo();
        DB::table('cliente')->where('id', 1)->update(['correo' => null]);
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->assertSet('correoFactura', '')
            ->set('correoCorrecto', true)->call('solicitarEnvioFactura')->assertHasErrors('correoFactura')
            ->set('correoFactura', 'incorrecto')->set('correoCorrecto', true)
            ->call('solicitarEnvioFactura')->assertHasErrors('correoFactura');
        Mail::assertNothingSent();
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('enviarCorreoFactura', true)->assertStatus(422);
    }

    public function test_invoice_email_failure_is_visible_and_does_not_update_customer_address(): void
    {
        $this->prepararPruebaCorreo();
        Mail::shouldReceive('to')->with('nuevo@example.test')->andReturnSelf();
        Mail::shouldReceive('send')->once()->andThrow(new TransportException('SMTP de prueba no disponible.'));
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->set('correoFactura', 'nuevo@example.test')->set('correoCorrecto', true)
            ->call('solicitarEnvioFactura')->call('enviarCorreoFactura', true)
            ->assertHasErrors('envioCorreo')->assertSet('correoEnviado', false)
            ->assertSee('No se pudo completar el envío.');
        $this->assertSame('cliente@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
    }

    public function test_invoice_email_blocks_non_delivery_mailers_and_empty_payment_catalog(): void
    {
        $this->prepararPruebaCorreo();
        config(['mail.default' => 'log']);
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->set('correoCorrecto', true)->call('solicitarEnvioFactura')->assertHasErrors('envioCorreo')
            ->assertSee('El envío requiere un servicio SMTP configurado.');
        config(['mail.default' => 'smtp']);
        DB::table('banco')->where('nombre', 'Banco autorizado')->delete();
        Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->set('correoCorrecto', true)->call('solicitarEnvioFactura')->assertHasErrors('envioCorreo')
            ->assertSee('No hay cuentas de pago disponibles');
        Mail::assertNothingSent();
    }

    public function test_invoice_email_does_not_overwrite_a_customer_address_changed_during_confirmation(): void
    {
        $this->prepararPruebaCorreo();
        $componente = Livewire::test(CarteraDeCobros::class)->call('abrirFactura', 1)->call('prepararCorreoFactura')
            ->set('correoFactura', 'nuevo@example.test')->set('correoCorrecto', true)->call('solicitarEnvioFactura');
        DB::table('cliente')->where('id', 1)->update(['correo' => 'otro@example.test']);
        $componente->call('enviarCorreoFactura', true)->assertSet('correoEnviado', true)
            ->assertHasErrors('envioCorreo')->assertSee('No es necesario reenviar.');
        $this->assertSame('otro@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
        Mail::assertSentCount(1);
    }

    private function autorizarNuevosCorreos(): void
    {
        foreach (['facturas/todos', 'estado_cuenta/vendedor'] as $i => $ruta) {
            DB::table('sub_menu')->insert(['id' => $i + 2, 'url' => $ruta]);
            DB::table('usuario_submenu')->insert(['usuario_id' => 1, 'sub_menu_id' => $i + 2, 'permitido' => true]);
        }
        DB::table('cliente_usuario')->insert(['cliente_id' => 1, 'usuario_id' => 1, 'rol_id' => 2]);
    }

    public function test_invoice_list_mail_reuses_confirmation_and_rechecks_pending_balance_before_sending(): void
    {
        $this->prepararPruebaCorreo();
        $this->autorizarNuevosCorreos();
        $componente = Livewire::test(CorreoFacturaTesting::class)->call('abrir', 'factura', 1)
            ->assertSee('Enviar factura por correo')->assertSet('correoFactura', 'cliente@example.test')
            ->set('correoFactura', 'nuevo@example.test')->set('correoCorrecto', true)->call('solicitarEnvioFactura')
            ->assertSet('etapaCorreo', 'actualizar')->call('enviarCorreoFactura', false)->assertSet('correoEnviado', true);
        Mail::assertSent(FacturaCobro::class, fn ($mail) => !$mail->estadoCuenta && $mail->saldoCentavos === 11000);
        $componente->call('cerrar')->assertSet('facturaDetalleId', null);
        DB::table('aplicacion_pagos')->update(['estado_cerrado' => 2]);
        Livewire::test(CorreoFacturaTesting::class)->call('abrir', 'factura', 1)->assertStatus(422);
        Mail::assertSentCount(1);
    }

    public function test_statement_mail_attaches_existing_complete_pdf_and_uses_customer_total(): void
    {
        $this->prepararPruebaCorreo();
        $this->autorizarNuevosCorreos();
        $this->factura(2, [], '40');
        $this->mock(EstadoCuentaVendedor::class, function (MockInterface $mock) {
            $mock->shouldReceive('imprimirEstadoCuenta')->with(1)->once()->andReturn(response('%PDF-1.7 estado completo'));
        });
        Livewire::test(CorreoEstadoTesting::class)->call('abrir', 'estado', 1)
            ->assertSee('Enviar estado de cuenta por correo')
            ->set('correoFactura', 'estado@example.test')->set('correoCorrecto', true)->call('solicitarEnvioFactura')
            ->call('enviarCorreoFactura', true)->assertSet('correoEnviado', true)
            ->assertSee('Estado de cuenta enviado a estado@example.test.');
        Mail::assertSent(FacturaCobro::class, function ($mail) {
            $html = $mail->render();
            $this->assertSame('%PDF-1.7 estado completo', $mail->rawAttachments[0]['data']);
            $this->assertStringContainsString('estado de cuenta completo', $html);
            $this->assertStringContainsString('L 150.00', $html);
            return $mail->estadoCuenta && $mail->hasTo('estado@example.test') && $mail->saldoCentavos === 15000;
        });
        $this->assertSame('estado@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
    }

    public function test_new_document_email_respects_page_permission_and_salesperson_customer_scope(): void
    {
        $this->prepararPruebaCorreo();
        $this->autorizarNuevosCorreos();
        $this->factura(2, ['cliente_id' => 2, 'vendedor' => 2, 'users_id' => 2, 'gestor_entrega' => 2]);
        Livewire::test(CorreoFacturaTesting::class)->call('abrir', 'factura', 2)->assertForbidden();
        Livewire::test(CorreoEstadoTesting::class)->call('abrir', 'estado', 2)->assertForbidden();
        $componente = Livewire::test(CorreoEstadoTesting::class)->call('abrir', 'estado', 1)->set('correoCorrecto', true);
        DB::table('usuario_submenu')->where('usuario_id', 1)->where('sub_menu_id', 3)->update(['permitido' => false]);
        $componente->call('solicitarEnvioFactura')->assertForbidden();
        Mail::assertNothingSent();
    }

    public function test_pending_email_option_uses_latest_balance_excludes_paid_closed_and_inactive_invoices(): void
    {
        $this->factura(1, [], null);
        $this->factura(2, [], null);
        DB::table('pago_venta')->insert(['factura_id' => 2, 'estado_venta_id' => 1, 'monto' => 100]);
        $this->factura(3, [], '80');
        DB::table('aplicacion_pagos')->insert(['factura_id' => 3, 'saldo' => 0, 'total_factura_cargo' => 100, 'estado' => 1]);
        $this->factura(4, [], '30', ['estado_cerrado' => 2]);
        $this->factura(5, ['estado_venta_id' => 2]);
        $this->factura(6, ['tipo_venta_id' => 3, 'sub_total' => 80, 'total' => 92], null);
        $servicio = app(SaldoCobro::class);
        $saldos = $servicio->pendientes()->pluck('saldo', 'f.id');
        $this->assertSame([1, 6], $saldos->keys()->all());
        $this->assertEquals(80, $saldos[6]);
        $this->assertStringContainsString('Enviar factura por correo', $servicio->opcionFactura(1, true));
        $this->assertSame('', $servicio->opcionFactura(2, false));
    }

    public function test_all_invoice_page_alias_preserves_catalog_permissions_and_pending_invoice_is_rechecked(): void
    {
        $this->prepararPruebaCorreo();
        DB::table('sub_menu')->insert(['id' => 2, 'url' => 'facturas/estatal']);
        DB::table('usuario_submenu')->insert(['usuario_id' => 1, 'sub_menu_id' => 2, 'permitido' => true]);
        $componente = Livewire::test(CorreoFacturaTesting::class)->call('abrir', 'factura', 1)
            ->set('correoFactura', 'nuevo@example.test')->set('correoCorrecto', true)
            ->call('solicitarEnvioFactura');
        DB::table('aplicacion_pagos')->update(['estado_cerrado' => 2]);
        $componente->call('enviarCorreoFactura', true)->assertNotFound();
        Mail::assertNothingSent();
        $this->assertSame('cliente@example.test', DB::table('cliente')->where('id', 1)->value('correo'));
        DB::table('aplicacion_pagos')->update(['estado_cerrado' => null]);
        DB::table('usuario_submenu')->where('sub_menu_id', 2)->update(['permitido' => false]);
        Livewire::test(CorreoFacturaTesting::class)->call('abrir', 'factura', 1)->assertForbidden();
    }

    public function test_aging_boundaries_missing_dates_and_weighted_mora_are_exact(): void
    {
        foreach ([0, 1, 30, 31, 60, 61, 90, 91, 180, 181] as $i => $dias) {
            $this->factura($i + 1, ['fecha_vencimiento' => CarbonImmutable::today()->subDays($dias)->toDateString()]);
        }

        $this->factura(11, ['fecha_vencimiento' => null, 'vendedor' => null]);
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 110000 && $m['vencido'] === 90000
                && $m['corriente'] === 10000 && $m['sinFecha'] === 10000 && $m['critica'] === 30000 && $m['mora'] === 80.6)
            ->call('seleccionar', 'tramo', '1-30')
            ->assertViewHas('metricas', fn ($m) => $m['facturas'] === 2)
            ->call('seleccionar', 'tramo', '1-30')
            ->assertViewHas('metricas', fn ($m) => $m['facturas'] === 11)
            ->call('seleccionar', 'estado', 'sin-fecha')
            ->assertSee('Sin asignar')
            ->assertViewHas('metricas', fn ($m) => $m['facturas'] === 1);
    }

    public function test_balance_and_mora_colors_follow_exact_aging_boundaries(): void
    {
        $casos = [0 => 'current', 1 => 'warning', 30 => 'warning', 31 => 'overdue', 90 => 'overdue', 91 => 'critical'];
        foreach (array_keys($casos) as $dias) {
            $this->factura($dias + 1, ['fecha_vencimiento' => CarbonImmutable::today()->subDays($dias)->toDateString()]);
        }
        $this->factura(200, ['fecha_vencimiento' => null]);
        $componente = Livewire::test(CarteraDeCobros::class);
        foreach ($casos + [199 => 'unknown'] as $dias => $color) {
            $componente->assertViewHas('detalleCompleto', fn ($filas) => collect($filas)->firstWhere('id', $dias + 1)['riesgo'] === $color);
        }
        $componente->call('seleccionar', 'tramo', '1-30')
            ->assertViewHas('metricas', fn ($m) => $m['facturas'] === 2);
    }

    public function test_clicks_cross_filter_all_panels_and_reset_restores_portfolio(): void
    {
        $this->factura(1, [], '300');
        $this->factura(2, ['cliente_id' => 2, 'vendedor' => 2, 'gestor_entrega' => 1], '200');
        $this->factura(3, ['cliente_id' => 2, 'vendedor' => 1, 'fecha_vencimiento' => '2026-12-01'], '50');
        Livewire::test(CarteraDeCobros::class)
            ->call('seleccionar', 'cliente', '2')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 25000 && $m['clientes'] === 1)
            ->assertViewHas('responsables', fn ($r) => $r['asesor']['filas']->sum('saldo') === 25000)
            ->call('seleccionar', 'asesor', '1')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 5000 && $m['vencido'] === 0)
            ->assertViewHas('meses', fn ($m) => $m->keys()->all() === ['2026-12'])
            ->call('limpiar')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 55000)
            ->set('buscar', 'F-2')
            ->assertViewHas('detalleCompleto', fn ($d) => count($d) === 1)
            ->set('buscar', 'No existe')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 0 && $m['mora'] === 0)
            ->assertSee('No hay deuda pendiente');
    }

    public function test_filter_options_only_include_clients_and_responsibles_in_current_selection(): void
    {
        $this->factura(1, ['fecha_vencimiento' => '2026-01-01']);
        $this->factura(2, ['cliente_id' => 2, 'vendedor' => 2, 'users_id' => 3, 'gestor_entrega' => 1,
            'fecha_vencimiento' => '2026-12-01']);
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->count() === 2)
            ->call('seleccionar', 'tramo', '181+')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [1]
                && $c['asesor']->keys()->all() === [1] && $c['teleasesor']->keys()->all() === [2]
                && $c['gestor']->keys()->all() === [3])
            ->call('seleccionar', 'cliente', '2')
            ->assertViewHas('catalogos', fn ($c) => collect($c)->every(fn ($opciones) => $opciones->isEmpty()))
            ->assertViewHas('etiquetas', fn ($e) => $e['cliente'][2] === 'Cliente B')
            ->call('seleccionar', 'cliente', '')
            ->call('seleccionar', 'tramo', '')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->count() === 2)
            ->set('buscar', 'F-2')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [2]
                && $c['asesor']->keys()->all() === [2])
            ->call('limpiar')->call('seleccionar', 'gestor', '3')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [1])
            ->call('limpiar')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->count() === 2);
    }

    public function test_recovery_filter_options_preserve_paid_invoices_only_with_payments_in_selected_periods(): void
    {
        $this->factura(1);
        $this->factura(2, ['cliente_id' => 2, 'vendedor' => 2], '0', ['estado_cerrado' => 2]);
        DB::table('abonos_creditos')->insert([
            'factura_id' => 2, 'monto_abonado' => 100, 'fecha_pago' => '2026-10-10', 'usr_registro' => 2,
        ]);
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [1])
            ->set('pestana', 'recuperacion')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->count() === 2 && $c['asesor']->count() === 2)
            ->call('seleccionar', 'usuario', '2')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [2])
            ->call('limpiar')->set('mesB', '2026-09')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [1])
            ->set('mesB', '2026-10')->set('pestana', 'cartera')
            ->assertViewHas('catalogos', fn ($c) => $c['cliente']->keys()->all() === [1]);
    }

    public function test_debt_leader_kpis_aggregate_filtered_balances_and_handle_empty_or_unassigned_portfolios(): void
    {
        $this->factura(1, [], '150');
        $this->factura(2, ['cliente_id' => 2], '200');
        $this->factura(3, ['cliente_id' => 2, 'vendedor' => 2], '300');
        $this->factura(4, ['vendedor' => null], '900');
        Livewire::test(CarteraDeCobros::class)
            ->assertSee('Asesor con mayor deuda')->assertSee('Cliente con mayor deuda')
            ->assertDontSee('Mora ponderada por saldo')->assertDontSee('Sin fecha de vencimiento')
            ->assertViewHas('destacados', fn ($d) => $d['asesor']['id'] === '1' && $d['asesor']['saldo'] === 35000
                && $d['cliente']['id'] === '1' && $d['cliente']['saldo'] === 105000)
            ->call('seleccionar', 'cliente', '2')
            ->assertViewHas('destacados', fn ($d) => $d['asesor']['id'] === '2' && $d['cliente']['saldo'] === 50000)
            ->call('seleccionar', 'asesor', '2')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 30000)
            ->call('limpiar')->call('seleccionar', 'asesor', '0')
            ->assertViewHas('destacados', fn ($d) => $d['asesor'] === null && $d['cliente']['saldo'] === 90000)
            ->assertSee('Sin asesores asignados')
            ->set('buscar', 'inexistente')
            ->assertViewHas('destacados', fn ($d) => $d['asesor'] === null && $d['cliente'] === null)
            ->assertSee('Sin clientes con deuda');
    }

    public function test_oldest_debt_and_pagination_use_all_filtered_invoices(): void
    {
        for ($id = 1; $id <= 25; $id++) {
            $this->factura($id, ['fecha_emision' => $id === 25 ? '2020-01-01' : '2026-01-01']);
        }
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('antigua', fn ($f) => $f->id === 25)
            ->assertViewHas('detalleCompleto', fn ($d) => count($d) === 25)
            ->assertDontSeeHtml('scrollIntoView()')
            ->assertDontSeeHtml('wire:click="gotoPage')
            ->set('orden', 'antiguedad')
            ->assertViewHas('detalleCompleto', fn ($d) => $d[0]['id'] === 25);
    }

    public function test_responsible_and_month_selections_update_every_aggregate(): void
    {
        $this->factura(1, [], '250');
        $this->factura(2, ['users_id' => 3, 'gestor_entrega' => 2], '150');
        $this->factura(3, ['fecha_vencimiento' => '2026-09-01'], '75');

        Livewire::test(CarteraDeCobros::class)
            ->call('seleccionar', 'teleasesor', '2')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 32500)
            ->call('seleccionar', 'gestor', '3')
            ->call('seleccionar', 'mes', '2026-09')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 7500 && $m['facturas'] === 1)
            ->assertViewHas('clientes', fn ($c) => $c->sum('saldo') === 7500)
            ->assertViewHas('tramos', fn ($t) => $t->sum('saldo') === 7500)
            ->assertViewHas('detalleCompleto', fn ($d) => $d[0]['id'] === 3)
            ->call('seleccionar', 'mes', '2026-09')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 32500);
    }

    public function test_multiple_payment_accounts_do_not_duplicate_invoice_debt(): void
    {
        $this->factura(1);
        DB::table('aplicacion_pagos')->insert([
            'factura_id' => 1, 'saldo' => 40, 'total_factura_cargo' => 100,
        ]);
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 4000 && $m['facturas'] === 1);
    }

    public function test_filter_action_rejects_unknown_dimensions(): void
    {
        Livewire::test(CarteraDeCobros::class)
            ->call('seleccionar', 'titulo', 'Otro')->assertStatus(422);
    }

    public function test_revoked_permission_blocks_component(): void
    {
        DB::table('usuario_submenu')->update(['permitido' => false]);
        Livewire::test(CarteraDeCobros::class)->assertForbidden();
    }

    public function test_administrator_can_load_and_refresh_portfolio_without_individual_permission(): void
    {
        DB::table('users')->where('id', 1)->update(['rol_id' => 1]);
        $this->actingAs(User::findOrFail(1));
        DB::table('usuario_submenu')->update(['permitido' => false]);
        $this->factura(1);
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 10000)
            ->call('seleccionar', 'cliente', '1')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 10000);
    }

    public function test_recovery_includes_paid_invoices_and_uses_independent_ranges_and_net_abonos(): void
    {
        $this->factura(1, [], '60');
        $this->factura(2, ['cliente_id' => 2], '0', ['estado_cerrado' => 2]);
        $this->factura(3, ['estado_venta_id' => 0]);
        DB::table('abonos_creditos')->insert([
            ['factura_id' => 1, 'monto_abonado' => 40, 'fecha_pago' => '2026-11-02 23:59:59', 'usr_registro' => 1, 'estado_abono' => 1],
            ['factura_id' => 2, 'monto_abonado' => 100, 'fecha_pago' => '2026-11-01 00:00:00', 'usr_registro' => 2, 'estado_abono' => 1],
            ['factura_id' => 1, 'monto_abonado' => 20, 'fecha_pago' => '2026-10-10 12:00:00', 'usr_registro' => 1, 'estado_abono' => 1],
            ['factura_id' => 1, 'monto_abonado' => 900, 'fecha_pago' => '2026-11-01 12:00:00', 'usr_registro' => 1, 'estado_abono' => 0],
            ['factura_id' => 3, 'monto_abonado' => 900, 'fecha_pago' => '2026-11-01 12:00:00', 'usr_registro' => 1, 'estado_abono' => 1],
        ]);
        Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 14000
                && $r['comparacion'][0]['porcentaje'] === 70.0
                && $r['comparacion'][1]['cobrado'] === 2000
                && $r['comparacion'][1]['porcentaje'] === 25.0)
            ->assertViewHas('recuperacion', fn ($r) => $r['grupos']['asesor']->sum('actual') === 14000
                && $r['grupos']['teleasesor']->sum('actual') === 14000 && $r['grupos']['gestor']->sum('actual') === 14000)
            ->call('seleccionar', 'usuario', '2')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 0)
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['porcentaje'] === 100.0)
            ->call('limpiar')
            ->set('modoPeriodo', 'detalle')
            ->set('fin', '2026-10-01')
            ->assertHasErrors('fin')
            ->assertSee('Corrige los rangos');
    }

    public function test_complete_rankings_and_excel_export_are_not_limited_to_ten_or_current_page(): void
    {
        for ($id = 3; $id <= 30; $id++) {
            DB::table('cliente')->insert(['id' => $id, 'nombre' => 'Cliente ' . $id]);
            $this->factura($id, ['cliente_id' => $id]);
        }
        $componente = Livewire::test(CarteraDeCobros::class)
            ->assertViewHas('clientes', fn ($c) => $c->count() === 28)
            ->assertViewHas('recuperacion', fn ($r) => $r['grupos']['cliente']->count() === 28)
            ->call('descargar', 'detalle')->assertFileDownloaded('Cartera vencida-detalle-2026-11-02.xlsx');

        $export = new \App\Exports\CarteraCobrosExport([
            ['Detalle', ['Cliente', 'Factura', 'Saldo'], [['=NO_ES_FORMULA', '000-001', 12.34]]],
        ]);
        $bytes = \Maatwebsite\Excel\Facades\Excel::raw($export, \Maatwebsite\Excel\Excel::XLSX);
        $archivo = tempnam(sys_get_temp_dir(), 'cartera-test-');
        try {
            file_put_contents($archivo, base64_decode($componente->effects['download']['content']));
            $completo = \PhpOffice\PhpSpreadsheet\IOFactory::load($archivo);
            $detalle = $completo->getSheetByName('Detalle cartera');
            $this->assertSame(30, $detalle->getHighestRow());
            $this->assertEquals(['TOTAL', '28 facturas', 2800], [$detalle->getCell('A30')->getValue(), $detalle->getCell('B30')->getValue(), $detalle->getCell('F30')->getValue()]);
            $this->assertTrue($detalle->getStyle('A30')->getFont()->getBold());
            $this->assertNotNull($completo->getSheetByName('Criterios'));
            $componente->call('descargar')->assertFileDownloaded('Cartera vencida-todas-2026-11-02.xlsx');
            $componente->call('seleccionar', 'estado', 'corriente')->call('descargar', 'detalle')->assertFileDownloaded('Cartera por vencer-detalle-2026-11-02.xlsx')
                ->call('seleccionar', 'estado', '')->call('seleccionar', 'tramo', 'corriente')->call('descargar')->assertFileDownloaded('Cartera por vencer-todas-2026-11-02.xlsx')
                ->call('limpiar')->call('descargar');
            file_put_contents($archivo, base64_decode($componente->effects['download']['content']));
            $completo = \PhpOffice\PhpSpreadsheet\IOFactory::load($archivo);
            $this->assertSame(16, $completo->getSheetCount());
            $this->assertSame(30, $completo->getSheetByName('Recuperacion cliente')->getHighestRow());
            foreach (['Clientes' => 'B', 'Antiguedad' => 'B', 'Vencimientos' => 'B', 'Recuperacion cliente' => 'E'] as $hoja => $columna) {
                $h = $completo->getSheetByName($hoja);
                $this->assertSame('TOTAL', $h->getCell('A' . $h->getHighestRow())->getValue());
                $this->assertEquals(2800, $h->getCell($columna . $h->getHighestRow())->getValue());
            }
            file_put_contents($archivo, $bytes);
            $libro = \PhpOffice\PhpSpreadsheet\IOFactory::load($archivo);
            $hoja = $libro->getActiveSheet();
            $this->assertSame('=NO_ES_FORMULA', $hoja->getCell('A2')->getValue());
            $this->assertSame('s', $hoja->getCell('A2')->getDataType());
            $this->assertSame('000-001', $hoja->getCell('B2')->getValue());
            $this->assertSame(12.34, $hoja->getCell('C2')->getValue());
        } finally {
            unlink($archivo);
        }
    }

    public function test_date_only_payments_null_registrars_and_overlapping_periods(): void
    {
        $this->factura(1, [], '60');
        DB::table('abonos_creditos')->insert([
            ['factura_id' => 1, 'monto_abonado' => 40, 'fecha_pago' => '2026-11-01', 'usr_registro' => null],
            ['factura_id' => 1, 'monto_abonado' => 10, 'fecha_pago' => '2026-11-03 00:00:00', 'usr_registro' => null],
        ]);
        Livewire::test(CarteraDeCobros::class)
            ->set('modoPeriodo', 'detalle')
            ->set('compararFin', '2026-11-02')
            ->set('compararInicio', '2026-11-01')
            ->call('seleccionar', 'usuario', '0')
            ->assertViewHas('metricas', fn ($m) => $m['total'] === 6000)
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 4000
                && $r['comparacion'][1]['cobrado'] === 4000
                && $r['grupos']['usuario']->first()['porcentaje'] === 40.0)
            ->set('fin', '2026-11-03')->assertHasErrors('fin')
            ->call('descargar')->assertNoFileDownloaded();
    }

    public function test_monthly_comparison_defaults_and_switching_to_detailed_ranges(): void
    {
        $this->factura(1, [], '60');
        DB::table('abonos_creditos')->insert([
            ['factura_id' => 1, 'monto_abonado' => 10, 'fecha_pago' => '2024-02-01', 'usr_registro' => 1],
            ['factura_id' => 1, 'monto_abonado' => 20, 'fecha_pago' => '2024-02-29 23:59:59', 'usr_registro' => 1],
            ['factura_id' => 1, 'monto_abonado' => 40, 'fecha_pago' => '2024-03-01', 'usr_registro' => 1],
        ]);
        $componente = Livewire::test(CarteraDeCobros::class)
            ->assertSet('modoPeriodo', 'mensual')->assertSet('mesA', '2026-11')->assertSet('mesB', '2026-10')
            ->assertSet('fin', '2026-11-02')
            ->assertSee('Cartera pendiente')->assertSee('Recuperación y recaudación')
            ->set('mesA', '2024-02')->set('mesB', '2024-03')
            ->assertSet('inicio', '2024-02-01')->assertSet('fin', '2024-02-29')
            ->assertSet('compararInicio', '2024-03-01')->assertSet('compararFin', '2024-03-31')
            ->assertSee('Recaudación · Febrero 2024')->assertSee('Comparación · Marzo 2024')->assertSee('Diferencia Febrero 2024 − Marzo 2024')->assertDontSee('Mes A')
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 3000
                && $r['comparacion'][1]['cobrado'] === 4000)
            ->set('modoPeriodo', 'detalle')->set('fin', '2024-02-10')->assertSee('1 al 10 de febrero 2024')
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 1000)
            ->set('modoPeriodo', 'mensual')
            ->assertSet('fin', '2024-02-29')
            ->call('seleccionar', 'asesor', '1')->call('limpiar')
            ->assertSet('mesA', '2024-02')->assertSet('mesB', '2024-03')
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 3000)
            ->call('descargar', 'comparacion')->assertFileDownloaded('Cartera vencida-comparacion-2026-11-02.xlsx');
        $archivo = tempnam(sys_get_temp_dir(), 'cartera-meses-');
        try {
            file_put_contents($archivo, base64_decode($componente->effects['download']['content']));
            $libro = \PhpOffice\PhpSpreadsheet\IOFactory::load($archivo);
            $hoja = $libro->getSheetByName('Comparacion');
            $this->assertSame('2024-02-01', $hoja->getCell('B2')->getValue());
            $this->assertSame('2024-02-29', $hoja->getCell('C2')->getValue());
            $this->assertEquals(30, $hoja->getCell('D2')->getValue());
            $this->assertEquals(40, $hoja->getCell('D3')->getValue());
            $this->assertSame('Mensual (mes actual hasta hoy)', $libro->getSheetByName('Criterios')->getCell('B3')->getValue());
        } finally {
            unlink($archivo);
        }
    }

    public function test_responsible_comparison_charts_show_both_periods_and_cross_filter(): void
    {
        $this->factura(1, [], '60');
        $this->factura(2, ['cliente_id' => 2, 'users_id' => 1, 'gestor_entrega' => 2], '80');
        DB::table('abonos_creditos')->insert([
            ['factura_id' => 1, 'monto_abonado' => 40, 'fecha_pago' => '2026-11-01', 'usr_registro' => 1],
            ['factura_id' => 2, 'monto_abonado' => 20, 'fecha_pago' => '2026-11-01', 'usr_registro' => 2],
            ['factura_id' => 1, 'monto_abonado' => 10, 'fecha_pago' => '2026-10-01', 'usr_registro' => 1],
        ]);
        Livewire::test(CarteraDeCobros::class)
            ->assertSeeHtml('id="cb-grafico-gestor"')
            ->assertSeeHtml('id="cb-grafico-teleasesor"')
            ->assertSeeHtml('id="cb-grafico-usuario"')
            ->assertSee('66.67%')->assertSee('33.33%')->assertSee('100.00%')
            ->call('seleccionar', 'gestor', '3')
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 4000
                && $r['grupos']['usuario']->count() === 1 && $r['grupos']['teleasesor']->count() === 1)
            ->call('seleccionar', 'gestor', '3')
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 6000)
            ->call('seleccionar', 'usuario', '2')
            ->assertViewHas('recuperacion', fn ($r) => $r['comparacion'][0]['cobrado'] === 2000
                && $r['comparacion'][1]['cobrado'] === 0)
            ->assertSee('Sin base');
    }

    public function test_invalid_or_future_months_block_recovery_and_exports(): void
    {
        Livewire::test(CarteraDeCobros::class)
            ->set('mesA', '2026-13')->assertHasErrors('mesA')
            ->assertViewHas('recuperacion', fn ($r) => !$r['valida'])
            ->call('descargar')->assertNoFileDownloaded()
            ->set('mesA', '2026-12')->assertHasErrors('mesA')
            ->set('mesA', '')->assertHasErrors('mesA')
            ->set('mesA', '2026-10')->assertHasNoErrors()
            ->set('mesB', '2026-12')->assertHasErrors('mesB')
            ->call('descargar')->assertNoFileDownloaded();
    }
}

class CorreoFacturaTesting extends CorreoCobro
{
    public function mount(): void
    {
        $this->origen = 'facturas/todos';
        $this->tipoDocumento = 'factura';
    }
}

class CorreoEstadoTesting extends CorreoCobro
{
    public function mount(): void
    {
        $this->origen = 'estado_cuenta/vendedor';
        $this->tipoDocumento = 'estado';
    }
}

<?php

namespace Tests\Feature\Comisiones;

use App\Livewire\Comisiones\Escalado\ReportesComisionesGenerales;
use App\Services\Comisiones\AplicadorRetencionesMora;
use App\Services\Comisiones\AjustadorComisionNotaCredito;
use App\Services\Comisiones\GeneradorFacturasComision;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class ComisionesRulesTest extends TestCase
{
    private string $originalDatabase;
    private string $tempDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->originalDatabase = (string) config('database.connections.mysql.database');
        $this->tempDatabase = 'copilot_comisiones_' . bin2hex(random_bytes(4));

        DB::statement("CREATE DATABASE `{$this->tempDatabase}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        config()->set('database.default', 'mysql');
        config()->set('database.connections.mysql.database', $this->tempDatabase);

        DB::purge('mysql');
        DB::reconnect('mysql');
        DB::setDefaultConnection('mysql');

        $this->createSchema();
        $this->seedBaseCatalogs();
    }

    protected function tearDown(): void
    {
        DB::disconnect('mysql');

        config()->set('database.connections.mysql.database', $this->originalDatabase);
        DB::purge('mysql');
        DB::reconnect('mysql');
        DB::statement("DROP DATABASE IF EXISTS `{$this->tempDatabase}`");

        parent::tearDown();
    }

    public function test_generador_uses_scale_for_the_invoice_client_category(): void
    {
        DB::table('users')->insert([
            ['id' => 1, 'rol_id' => 5, 'name' => 'Facturador'],
            ['id' => 2, 'rol_id' => 2, 'name' => 'Vendedor'],
        ]);

        DB::table('cliente')->insert([
            'id' => 1,
            'nombre' => 'Cliente Prueba',
            'cliente_categoria_escala_id' => 10,
        ]);

        DB::table('tipo_factura')->insert([
            'id' => 1,
            'codigo' => 'normal',
            'nombre' => 'Normal',
        ]);

        DB::table('factura')->insert([
            'id' => 1,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 1,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-06-01',
            'fecha_vencimiento' => '2026-06-01',
            'sub_total' => 200,
            'cai' => 'FAC-001',
            'total' => 200,
        ]);

        DB::table('categoria_precios')->insert([
            'id' => 501,
            'cliente_categoria_escala_id' => 10,
            'nombre' => 'Precio F',
            'porc_precio_a' => 0,
            'estado_id' => 1,
        ]);

        DB::table('precios_producto_carga')->insert([
            'id' => 700,
            'categoria_precios_id' => 501,
            'precio_base_venta' => 100,
        ]);

        DB::table('venta_has_producto')->insert([
            [
                'factura_id' => 1,
                'cantidad' => 2,
                'cantidad_s' => 0.5,
                'precio_unidad' => 500,
                'precioSeleccionado' => 100,
                'precios_producto_carga_id' => 700,
                'producto_id' => 1,
                'seccion_id' => 1,
                'unidad_medida_venta_id' => 1,
            ],
            [
                'factura_id' => 1,
                'cantidad' => 2,
                'cantidad_s' => 1.5,
                'precio_unidad' => 500,
                'precioSeleccionado' => 100,
                'precios_producto_carga_id' => 700,
                'producto_id' => 1,
                'seccion_id' => 1,
                'unidad_medida_venta_id' => 1,
            ],
        ]);

        DB::table('comision_escala')->insert([
            [
                'id' => 1,
                'rol_id' => 2,
                'cliente_categoria_escala_id' => 10,
                'categoria_precios_id' => 501,
                'porcentaje_comision' => 1,
                'estado_id' => 1,
            ],
            [
                'id' => 2,
                'rol_id' => 2,
                'cliente_categoria_escala_id' => 20,
                'categoria_precios_id' => 501,
                'porcentaje_comision' => 9,
                'estado_id' => 1,
            ],
        ]);

        $resultado = app(GeneradorFacturasComision::class)->generar(1, 9001, '2026-06-26');

        $this->assertCount(1, $resultado);
        $this->assertSame(2, $resultado[0]['rol_id']);
        $this->assertEquals(2.0, $resultado[0]['monto_rol']);
        $this->assertSame(1, DB::table('producto_comision')->count());
        $this->assertEquals(2.0, (float) DB::table('producto_comision')->value('cantidad'));
        $this->assertEquals(2.0, (float) DB::table('producto_comision')->value('monto_comision'));
    }

    public function test_generador_resolves_foreign_category_by_price_floor(): void
    {
        DB::table('users')->insert([
            ['id' => 1, 'rol_id' => 3, 'name' => 'Facturador'],
            ['id' => 13, 'rol_id' => 2, 'name' => 'Belinda'],
        ]);

        DB::table('cliente')->insert([
            'id' => 642,
            'nombre' => 'Distribuidora Global',
            'cliente_categoria_escala_id' => 36,
        ]);

        DB::table('tipo_factura')->insert([
            'id' => 1,
            'codigo' => 'normal',
            'nombre' => 'Normal',
        ]);

        DB::table('factura')->insert([
            'id' => 29553,
            'users_id' => 1,
            'vendedor' => 13,
            'cliente_id' => 642,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 2,
            'fecha_emision' => '2026-09-01',
            'fecha_vencimiento' => '2026-10-01',
            'sub_total' => 1235.52,
            'cai' => '000-001-01-00044469',
            'total' => 1420.85,
        ]);

        DB::table('categoria_precios')->insert([
            [
                'id' => 7,
                'cliente_categoria_escala_id' => 36,
                'nombre' => 'F',
                'estado_id' => 1,
            ],
            [
                'id' => 26,
                'cliente_categoria_escala_id' => 38,
                'nombre' => 'C',
                'estado_id' => 1,
            ],
        ]);

        DB::table('precios_producto_carga')->insert([
            [
                'id' => 626498,
                'categoria_precios_id' => 26,
                'producto_id' => 1464,
                'precio_base_venta' => 475.20,
                'precio_a' => 617.76,
                'estado_id' => 1,
            ],
            [
                'id' => 626499,
                'categoria_precios_id' => 7,
                'producto_id' => 1464,
                'precio_base_venta' => 475.20,
                'precio_a' => 617.76,
                'estado_id' => 1,
            ],
        ]);

        DB::table('venta_has_producto')->insert([
            'factura_id' => 29553,
            'cantidad' => 2,
            'cantidad_s' => 2,
            'precio_unidad' => 617.76,
            'idPrecioSeleccionado' => 'p1',
            'precioSeleccionado' => 617.76,
            'precios_producto_carga_id' => 626498,
            'producto_id' => 1464,
            'seccion_id' => 122,
            'unidad_medida_venta_id' => 465,
        ]);

        DB::table('comision_escala')->insert([
            'id' => 1,
            'rol_id' => 2,
            'cliente_categoria_escala_id' => 36,
            'categoria_precios_id' => 7,
            'porcentaje_comision' => 2.1,
            'estado_id' => 1,
        ]);

        $resultado = app(GeneradorFacturasComision::class)->generar(29553, 36902, '2026-10-27');

        $this->assertCount(1, $resultado);
        $this->assertSame(2, $resultado[0]['rol_id']);
        $this->assertEquals(25.9459, $resultado[0]['monto_rol']);
        $this->assertDatabaseHas('producto_comision', [
            'factura_id' => 29553,
            'producto_id' => 1464,
            'rol_id' => 2,
        ]);
    }

    public function test_nota_credito_reduces_pending_commission_in_original_period(): void
    {
        $this->seedCreditNoteCommissionScenario();

        $resultado = app(AjustadorComisionNotaCredito::class)->aplicar(1);

        $this->assertCount(1, $resultado);
        $this->assertDatabaseHas('nota_credito_ajustes_comision', [
            'nota_credito_id' => 1,
            'facturas_comision_id' => 1,
            'periodo_aplicado' => '2026-07-01',
            'monto' => 1.10,
            'comision_pagada' => 0,
        ]);
        $this->assertEquals(98.90, (float) DB::table('comision_empleado')->value('comision_acumulada'));
    }

    public function test_nota_credito_reduces_paid_commission_in_next_open_month(): void
    {
        $this->seedCreditNoteCommissionScenario();
        DB::table('comision_periodo')->insert([
            'periodo' => '2026-07-01',
            'estado' => 1,
        ]);

        app(AjustadorComisionNotaCredito::class)->aplicar(1);

        $this->assertDatabaseHas('nota_credito_ajustes_comision', [
            'nota_credito_id' => 1,
            'facturas_comision_id' => 1,
            'periodo_original' => '2026-07-01',
            'periodo_aplicado' => '2026-08-01',
            'monto' => 1.10,
            'comision_pagada' => 1,
        ]);
        $this->assertDatabaseHas('comision_empleado', [
            'users_comision' => 2,
            'rol_id' => 2,
            'mes_comision' => '2026-08-01',
            'comision_acumulada' => -1.10,
        ]);
        $this->assertDatabaseHas('comision_empleado', [
            'mes_comision' => '2026-07-01',
            'comision_acumulada' => 100.00,
        ]);
    }

    public function test_only_configured_invoice_uses_net_payment_date_for_projection(): void
    {
        DB::table('factura')->insert([
            'id' => 29949,
            'users_id' => 64,
            'vendedor' => 86,
            'cliente_id' => 1025,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-09-22',
            'sub_total' => 4239.44,
            'total' => 4609.31,
            'cai' => '000-001-01-00044864',
        ]);
        DB::table('aplicacion_pagos')->insert([
            'id' => 37322,
            'factura_id' => 29949,
            'estado' => 1,
            'saldo' => 0,
        ]);
        DB::table('abonos_creditos')->insert([
            'id' => 29485,
            'aplicacion_pagos_id' => 37322,
            'factura_id' => 29949,
            'estado_abono' => 1,
            'fecha_pago' => '2026-09-24',
        ]);
        DB::table('nota_credito')->insert([
            'id' => 507,
            'fecha' => '2026-10-19',
            'sub_total' => 2151.60,
            'factura_id' => 29949,
            'estado_nota_id' => 1,
            'estado_rebajado' => 1,
        ]);
        DB::table('nota_credito_creditos')->insert([
            'id' => 551,
            'nota_credito_id' => 507,
        ]);
        DB::table('nota_credito_movimientos')->insert([
            'id' => 53,
            'credito_id' => 551,
            'tipo' => 'aplicacion',
            'factura_id' => 29949,
            'aplicacion_pagos_id' => 37322,
        ]);
        DB::table('otros_movimientos')->insert([
            'id' => 256,
            'aplicacion_pagos_id' => 37322,
            'factura_id' => 29949,
            'estado' => 1,
            'tipo_movimiento' => 2,
        ]);

        $method = new \ReflectionMethod(ReportesComisionesGenerales::class, 'cierresPagoNetoNotaCredito');
        $cierresSeptiembre = $method->invoke(
            app(ReportesComisionesGenerales::class),
            '2026-09-01',
            '2026-09-30'
        );
        $cierresOctubre = $method->invoke(
            app(ReportesComisionesGenerales::class),
            '2026-10-01',
            '2026-10-31'
        );

        $this->assertCount(1, $cierresSeptiembre);
        $this->assertSame(29949, (int) $cierresSeptiembre->first()->factura_id);
        $this->assertSame('2026-09-24', $cierresSeptiembre->first()->fecha_pago_cierre);
        $this->assertTrue($cierresSeptiembre->first()->pago_neto_nota_credito);
        $this->assertCount(0, $cierresOctubre);
    }

    public function test_cent_adjustment_invoice_uses_payment_date_only_in_august(): void
    {
        DB::table('factura')->insert([
            'id' => 29372,
            'users_id' => 27,
            'vendedor' => 24,
            'gestor_entrega' => 27,
            'cliente_id' => 81,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-08-21',
            'sub_total' => 63925.55,
            'total' => 63925.55,
            'cai' => '000-001-01-00044288',
        ]);
        DB::table('aplicacion_pagos')->insert([
            'id' => 37004,
            'factura_id' => 29372,
            'estado' => 1,
            'saldo' => 0,
        ]);
        DB::table('abonos_creditos')->insert([
            'id' => 29001,
            'aplicacion_pagos_id' => 37004,
            'factura_id' => 29372,
            'estado_abono' => 1,
            'fecha_pago' => '2026-08-26',
        ]);
        DB::table('otros_movimientos')->insert([
            'id' => 248,
            'aplicacion_pagos_id' => 37004,
            'factura_id' => 29372,
            'estado' => 1,
            'tipo_movimiento' => 2,
        ]);

        $method = new \ReflectionMethod(ReportesComisionesGenerales::class, 'cierresAjusteCentavosFechaPago');
        $cierresAgosto = $method->invoke(
            app(ReportesComisionesGenerales::class),
            '2026-08-01',
            '2026-08-31'
        );
        $cierresSeptiembre = $method->invoke(
            app(ReportesComisionesGenerales::class),
            '2026-09-01',
            '2026-09-30'
        );

        $this->assertCount(1, $cierresAgosto);
        $this->assertSame(29372, (int) $cierresAgosto->first()->factura_id);
        $this->assertSame('2026-08-26', $cierresAgosto->first()->fecha_pago_cierre);
        $this->assertTrue($cierresAgosto->first()->ajuste_centavos_fecha_pago);
        $this->assertCount(0, $cierresSeptiembre);
    }

    public function test_generador_sr_uses_lowest_price_category_for_client_scale(): void
    {
        DB::table('users')->insert([
            ['id' => 1, 'rol_id' => 5, 'name' => 'Facturador'],
            ['id' => 2, 'rol_id' => 2, 'name' => 'Vendedor'],
        ]);

        DB::table('cliente')->insert([
            'id' => 2,
            'nombre' => 'Cliente SR',
            'cliente_categoria_escala_id' => 10,
        ]);

        DB::table('tipo_factura')->insert([
            'id' => 2,
            'codigo' => 'sin_restriccion_precio',
            'nombre' => 'SR Precio',
        ]);

        DB::table('categoria_precios')->insert([
            [
                'id' => 601,
                'cliente_categoria_escala_id' => 10,
                'nombre' => 'Base',
                'porc_precio_a' => 0,
                'estado_id' => 1,
            ],
            [
                'id' => 602,
                'cliente_categoria_escala_id' => 10,
                'nombre' => 'Alta',
                'porc_precio_a' => 25,
                'estado_id' => 1,
            ],
        ]);

        DB::table('factura')->insert([
            'id' => 2,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 2,
            'tipo_factura_id' => 2,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-06-01',
            'fecha_vencimiento' => '2026-06-01',
            'sub_total' => 100,
            'cai' => 'FAC-002',
            'total' => 100,
        ]);

        DB::table('precios_producto_carga')->insert([
            [
                'id' => 701,
                'categoria_precios_id' => 602,
                'producto_id' => 1,
                'precio_base_venta' => 100,
                'precio_a' => 100,
            ],
            [
                'id' => 702,
                'categoria_precios_id' => 601,
                'producto_id' => 1,
                'precio_base_venta' => 150,
                'precio_a' => 150,
            ],
        ]);

        DB::table('venta_has_producto')->insert([
            'factura_id' => 2,
            'cantidad' => 1,
            'precio_unidad' => 100,
            'precios_producto_carga_id' => 701,
            'producto_id' => 1,
        ]);

        DB::table('comision_escala')->insert([
            [
                'rol_id' => 2,
                'cliente_categoria_escala_id' => 10,
                'categoria_precios_id' => 601,
                'porcentaje_comision' => 1,
                'estado_id' => 1,
            ],
            [
                'rol_id' => 2,
                'cliente_categoria_escala_id' => 10,
                'categoria_precios_id' => 602,
                'porcentaje_comision' => 5,
                'estado_id' => 1,
            ],
        ]);

        $resultado = app(GeneradorFacturasComision::class)->generar(2, 9002, '2026-06-26');

        $this->assertCount(1, $resultado);
        $this->assertEquals(1.0, $resultado[0]['monto_rol']);
        $this->assertEquals(1.0, (float) DB::table('producto_comision')->orderByDesc('id')->value('monto_comision'));
    }

    public function test_generador_excludes_roles_disabled_for_calculation(): void
    {
        DB::table('users')->insert([
            ['id' => 1, 'rol_id' => 5, 'name' => 'Facturador'],
            ['id' => 2, 'rol_id' => 2, 'name' => 'Vendedor'],
        ]);

        DB::table('cliente')->insert([
            'id' => 4,
            'nombre' => 'Cliente Rol Off',
            'cliente_categoria_escala_id' => 10,
        ]);

        DB::table('tipo_factura')->insert([
            'id' => 3,
            'codigo' => 'normal',
            'nombre' => 'Normal',
        ]);

        DB::table('factura')->insert([
            'id' => 3,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 4,
            'tipo_factura_id' => 3,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-06-01',
            'fecha_vencimiento' => '2026-06-01',
            'sub_total' => 100,
            'cai' => 'FAC-003',
            'total' => 100,
        ]);

        DB::table('categoria_precios')->insert([
            'id' => 603,
            'cliente_categoria_escala_id' => 10,
            'nombre' => 'Precio G',
            'porc_precio_a' => 0,
            'estado_id' => 1,
        ]);

        DB::table('precios_producto_carga')->insert([
            'id' => 702,
            'categoria_precios_id' => 603,
            'precio_base_venta' => 100,
        ]);

        DB::table('venta_has_producto')->insert([
            'factura_id' => 3,
            'cantidad' => 1,
            'precio_unidad' => 100,
            'precios_producto_carga_id' => 702,
            'producto_id' => 1,
        ]);

        DB::table('comision_escala')->insert([
            'rol_id' => 2,
            'cliente_categoria_escala_id' => 10,
            'categoria_precios_id' => 603,
            'porcentaje_comision' => 2,
            'estado_id' => 1,
        ]);

        DB::table('comision_rol_config')->insert([
            'rol_id' => 2,
            'calcular' => 0,
        ]);

        $resultado = app(GeneradorFacturasComision::class)->generar(3, 9003, '2026-06-26');

        $this->assertSame([], $resultado);
        $this->assertSame(0, DB::table('facturas_comision')->count());
    }

    public function test_aplicador_retenciones_handles_contado_and_is_idempotent(): void
    {
        Auth::partialMock()->shouldReceive('id')->andReturn(777);

        DB::table('factura')->insert([
            'id' => 10,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 1,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-06-01',
            'fecha_vencimiento' => '2026-06-01',
            'sub_total' => 500,
            'cai' => 'FAC-010',
            'total' => 500,
        ]);

        DB::table('facturas_comision')->insert([
            'id' => 100,
            'fecha_cierre_factura' => '2026-06-10',
            'monto_rol' => 100,
            'factura_id' => 10,
            'aplicacion_pagos_id' => 5000,
            'rol_id' => 2,
            'tipo_comision' => 3,
            'estado_id' => 1,
            'cantidad_usuariosxrol' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('dias_gracia_comision')->insert([
            'rol_id' => 2,
            'tipo_factura' => 'contado',
            'dias_gracia' => 5,
            'porcentaje_retencion' => 100,
        ]);

        $payload = [[
            'facturas_comision_id' => 100,
            'monto_rol' => 100,
            'rol_id' => 2,
            'target_user_id' => 2,
        ]];

        $resultado = app(AplicadorRetencionesMora::class)->aplicar($payload, 10, '2026-06-10');
        $resultado2 = app(AplicadorRetencionesMora::class)->aplicar($resultado, 10, '2026-06-10');

        $this->assertEquals(0.0, $resultado[0]['monto_rol']);
        $this->assertEquals(0.0, $resultado2[0]['monto_rol']);
        $this->assertEquals(100.0, (float) DB::table('facturas_comision')->where('id', 100)->value('retencion_mora_monto'));
        $this->assertSame(1, DB::table('retencion_mora_log')->where('facturas_comision_id', 100)->count());
    }

    public function test_aplicador_retenciones_handles_credito_by_grace_periods(): void
    {
        Auth::partialMock()->shouldReceive('id')->andReturn(888);

        DB::table('factura')->insert([
            'id' => 11,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 1,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 2,
            'fecha_emision' => '2026-06-01',
            'fecha_vencimiento' => '2026-06-01',
            'sub_total' => 500,
            'cai' => 'FAC-011',
            'total' => 500,
        ]);

        DB::table('facturas_comision')->insert([
            'id' => 101,
            'fecha_cierre_factura' => '2026-06-12',
            'monto_rol' => 100,
            'factura_id' => 11,
            'aplicacion_pagos_id' => 5001,
            'rol_id' => 2,
            'tipo_comision' => 3,
            'estado_id' => 1,
            'cantidad_usuariosxrol' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('dias_gracia_comision')->insert([
            'rol_id' => 2,
            'tipo_factura' => 'credito',
            'dias_gracia' => 5,
            'porcentaje_retencion' => 10,
        ]);

        $payload = [[
            'facturas_comision_id' => 101,
            'monto_rol' => 100,
            'rol_id' => 2,
            'target_user_id' => 2,
        ]];

        $resultado = app(AplicadorRetencionesMora::class)->aplicar($payload, 11, '2026-06-12');

        $this->assertEquals(80.0, $resultado[0]['monto_rol']);
        $this->assertEquals(20.0, (float) DB::table('facturas_comision')->where('id', 101)->value('retencion_mora_monto'));
        $this->assertSame(2, DB::table('retencion_mora_log')->where('facturas_comision_id', 101)->count());
    }

    public function test_aplicador_retenciones_credito_counts_single_period_on_grace_multiple_boundary(): void
    {
        Auth::partialMock()->shouldReceive('id')->andReturn(889);

        DB::table('factura')->insert([
            'id' => 12,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 1,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 2,
            'fecha_emision' => '2026-06-01',
            'fecha_vencimiento' => '2026-06-01',
            'sub_total' => 500,
            'cai' => 'FAC-012',
            'total' => 500,
        ]);

        DB::table('facturas_comision')->insert([
            'id' => 102,
            'fecha_cierre_factura' => '2026-06-11',
            'monto_rol' => 100,
            'factura_id' => 12,
            'aplicacion_pagos_id' => 5002,
            'rol_id' => 2,
            'tipo_comision' => 3,
            'estado_id' => 1,
            'cantidad_usuariosxrol' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('dias_gracia_comision')->insert([
            'rol_id' => 2,
            'tipo_factura' => 'credito',
            'dias_gracia' => 5,
            'porcentaje_retencion' => 10,
        ]);

        $payload = [[
            'facturas_comision_id' => 102,
            'monto_rol' => 100,
            'rol_id' => 2,
            'target_user_id' => 2,
        ]];

        // 10 días transcurridos con gracia de 5:
        // corresponde 1 período vencido (no 2).
        $resultado = app(AplicadorRetencionesMora::class)->aplicar($payload, 12, '2026-06-11');

        $this->assertEquals(90.0, $resultado[0]['monto_rol']);
        $this->assertEquals(10.0, (float) DB::table('facturas_comision')->where('id', 102)->value('retencion_mora_monto'));
        $this->assertSame(1, DB::table('retencion_mora_log')->where('facturas_comision_id', 102)->count());
    }

    public function test_detalle_nomina_normalizes_legacy_unit_commissions_to_line_totals(): void
    {
        DB::table('users')->insert([
            ['id' => 1, 'rol_id' => 5, 'name' => 'Facturador'],
            ['id' => 2, 'rol_id' => 2, 'name' => 'Vendedor'],
        ]);

        DB::table('cliente')->insert([
            'id' => 3,
            'nombre' => 'Cliente Reporte',
            'cliente_categoria_escala_id' => 10,
        ]);

        DB::table('factura')->insert([
            'id' => 20,
            'users_id' => 1,
            'vendedor' => 2,
            'cliente_id' => 3,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-06-15',
            'fecha_vencimiento' => '2026-06-15',
            'sub_total' => 2462.20,
            'cai' => '000-001-01-00042973',
            'total' => 2462.20,
        ]);

        DB::table('categoria_precios')->insert([
            ['id' => 801, 'cliente_categoria_escala_id' => 10, 'nombre' => 'F', 'porc_precio_a' => 0, 'estado_id' => 1],
            ['id' => 802, 'cliente_categoria_escala_id' => 10, 'nombre' => 'C', 'porc_precio_a' => 10, 'estado_id' => 1],
        ]);

        DB::table('precios_producto_carga')->insert([
            ['id' => 901, 'categoria_precios_id' => 801, 'precio_base_venta' => 28.75],
            ['id' => 902, 'categoria_precios_id' => 801, 'precio_base_venta' => 100.00],
            ['id' => 903, 'categoria_precios_id' => 802, 'precio_base_venta' => 363.69],
        ]);

        DB::table('producto')->insert([
            ['id' => 1, 'nombre' => 'Acuarela 12 Colores'],
            ['id' => 2, 'nombre' => 'Agenda 80 Hojas'],
            ['id' => 3, 'nombre' => 'Dispensador Jabon'],
        ]);

        DB::table('aplicacion_pagos')->insert([
            'id' => 9003,
            'factura_id' => 20,
            'estado' => 1,
            'estado_cerrado' => 2,
            'saldo' => 0,
        ]);

        DB::table('facturas_comision')->insert([
            'id' => 200,
            'fecha_cierre_factura' => '2026-06-15',
            'monto_rol' => 9.8488,
            'factura_id' => 20,
            'aplicacion_pagos_id' => 9003,
            'rol_id' => 2,
            'tipo_comision' => 3,
            'estado_id' => 1,
            'cantidad_usuariosxrol' => 1,
            'retencion_mora_monto' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('producto_comision')->insert([
            [
                'cantidad' => 5,
                'precio_venta' => 28.75,
                'monto_comision' => 0.1150,
                'precios_producto_carga_id' => 901,
                'factura_id' => 20,
                'producto_id' => 1,
                'rol_id' => 2,
                'estado_id' => 1,
                'facturas_comision_id' => 200,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'cantidad' => 5,
                'precio_venta' => 100.00,
                'monto_comision' => 0.4000,
                'precios_producto_carga_id' => 902,
                'factura_id' => 20,
                'producto_id' => 2,
                'rol_id' => 2,
                'estado_id' => 1,
                'facturas_comision_id' => 200,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'cantidad' => 5,
                'precio_venta' => 363.69,
                'monto_comision' => 1.4548,
                'precios_producto_carga_id' => 903,
                'factura_id' => 20,
                'producto_id' => 3,
                'rol_id' => 2,
                'estado_id' => 1,
                'facturas_comision_id' => 200,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        $request = Request::create('/comision/reporte/nomina/detalle', 'GET', [
            'empleado_id' => 2,
            'mes_clave' => '2026-06',
            'fechaInicio' => '2026-06-01',
            'fechaFin' => '2026-06-30',
        ]);

        $response = app(ReportesComisionesGenerales::class)->detalleNomina($request);
        $payload = $response->getData(true);

        $this->assertCount(1, $payload['data']);
        $detalle = $payload['data'][0]['detalle_productos'];

        $this->assertCount(3, $detalle);
        $this->assertEquals(0.58, $detalle[0]['comision']);
        $this->assertEquals(0.40, $detalle[0]['porcentaje_comision']);
        $this->assertEquals(9.85, round(array_sum(array_column($detalle, 'comision')), 2));
    }

    public function test_detalle_nomina_consolidates_identical_duplicate_product_rows(): void
    {
        DB::table('users')->insert([
            ['id' => 11, 'rol_id' => 5, 'name' => 'Facturador Duplicado'],
            ['id' => 12, 'rol_id' => 2, 'name' => 'Vendedor Duplicado'],
        ]);

        DB::table('cliente')->insert([
            'id' => 30,
            'nombre' => 'Cliente Duplicado',
            'cliente_categoria_escala_id' => 10,
        ]);

        DB::table('factura')->insert([
            'id' => 30,
            'users_id' => 11,
            'vendedor' => 12,
            'cliente_id' => 30,
            'tipo_factura_id' => 1,
            'tipo_pago_id' => 1,
            'fecha_emision' => '2026-06-20',
            'fecha_vencimiento' => '2026-06-20',
            'sub_total' => 100,
            'cai' => 'DUP-001',
            'total' => 100,
        ]);

        DB::table('categoria_precios')->insert([
            'id' => 830,
            'cliente_categoria_escala_id' => 10,
            'nombre' => 'F',
            'porc_precio_a' => 0,
            'estado_id' => 1,
        ]);

        DB::table('precios_producto_carga')->insert([
            'id' => 930,
            'categoria_precios_id' => 830,
            'precio_base_venta' => 50.00,
        ]);

        DB::table('producto')->insert([
            'id' => 8300,
            'nombre' => 'Producto Duplicado',
        ]);

        DB::table('aplicacion_pagos')->insert([
            'id' => 9300,
            'factura_id' => 30,
            'estado' => 1,
            'estado_cerrado' => 2,
            'saldo' => 0,
        ]);

        DB::table('facturas_comision')->insert([
            'id' => 300,
            'fecha_cierre_factura' => '2026-06-20',
            'monto_rol' => 3.00,
            'factura_id' => 30,
            'aplicacion_pagos_id' => 9300,
            'rol_id' => 2,
            'tipo_comision' => 3,
            'estado_id' => 1,
            'cantidad_usuariosxrol' => 1,
            'retencion_mora_monto' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('producto_comision')->insert([
            [
                'cantidad' => 1,
                'precio_venta' => 50.00,
                'monto_comision' => 1.00,
                'precios_producto_carga_id' => 930,
                'factura_id' => 30,
                'producto_id' => 8300,
                'rol_id' => 2,
                'estado_id' => 1,
                'facturas_comision_id' => 300,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'cantidad' => 1,
                'precio_venta' => 50.00,
                'monto_comision' => 1.00,
                'precios_producto_carga_id' => 930,
                'factura_id' => 30,
                'producto_id' => 8300,
                'rol_id' => 2,
                'estado_id' => 1,
                'facturas_comision_id' => 300,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'cantidad' => 1,
                'precio_venta' => 50.00,
                'monto_comision' => 1.00,
                'precios_producto_carga_id' => 930,
                'factura_id' => 30,
                'producto_id' => 8300,
                'rol_id' => 2,
                'estado_id' => 1,
                'facturas_comision_id' => 300,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        $request = Request::create('/comision/reporte/nomina/detalle', 'GET', [
            'empleado_id' => 12,
            'mes_clave' => '2026-06',
            'fechaInicio' => '2026-06-01',
            'fechaFin' => '2026-06-30',
        ]);

        $response = app(ReportesComisionesGenerales::class)->detalleNomina($request);
        $payload = $response->getData(true);

        $this->assertCount(1, $payload['data']);
        $detalle = $payload['data'][0]['detalle_productos'];

        $this->assertCount(1, $detalle);
        $this->assertEquals(3.0, $detalle[0]['cantidad']);
        $this->assertEquals(3.0, $detalle[0]['comision']);
    }

    private function createSchema(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('rol_id')->nullable();
            $table->string('name');
        });

        Schema::create('rol', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('nombre');
            $table->integer('estado_id')->default(1);
        });

        Schema::create('cliente_categoria_escala', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('nombre_categoria');
        });

        Schema::create('cliente', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('nombre')->nullable();
            $table->integer('cliente_categoria_escala_id')->nullable();
        });

        Schema::create('tipo_factura', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('codigo')->nullable();
            $table->string('nombre')->nullable();
        });

        Schema::create('factura', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('users_id');
            $table->integer('vendedor');
            $table->integer('gestor_entrega')->nullable();
            $table->integer('tipo_factura_id')->nullable();
            $table->integer('cliente_id')->nullable();
            $table->integer('tipo_pago_id')->default(1);
            $table->date('fecha_emision')->nullable();
            $table->date('fecha_vencimiento')->nullable();
            $table->decimal('sub_total', 12, 4)->default(0);
            $table->decimal('total', 12, 4)->default(0);
            $table->string('cai')->nullable();
        });

        Schema::create('categoria_precios', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('cliente_categoria_escala_id')->nullable();
            $table->string('nombre')->nullable();
            $table->decimal('porc_precio_a', 8, 4)->nullable();
            $table->integer('estado_id')->default(1);
        });

        Schema::create('precios_producto_carga', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('categoria_precios_id');
            $table->integer('producto_id')->nullable();
            $table->decimal('precio_base_venta', 12, 4)->nullable();
            $table->decimal('precio_a', 12, 4)->nullable();
            $table->decimal('precio_b', 12, 4)->nullable();
            $table->decimal('precio_c', 12, 4)->nullable();
            $table->decimal('precio_d', 12, 4)->nullable();
            $table->integer('estado_id')->default(1);
        });

        Schema::create('producto', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('nombre')->nullable();
        });

        Schema::create('venta_has_producto', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('factura_id');
            $table->decimal('cantidad', 12, 4);
            $table->decimal('cantidad_s', 12, 4)->nullable();
            $table->decimal('precio_unidad', 12, 4);
            $table->string('idPrecioSeleccionado')->nullable();
            $table->decimal('precioSeleccionado', 12, 4)->nullable();
            $table->integer('precios_producto_carga_id');
            $table->integer('producto_id');
            $table->integer('seccion_id')->nullable();
            $table->integer('unidad_medida_venta_id')->nullable();
        });

        Schema::create('comision_rol_config', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('rol_id');
            $table->integer('calcular')->default(1);
            $table->integer('updated_by')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::create('comision_escala', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('rol_id');
            $table->integer('cliente_categoria_escala_id')->nullable();
            $table->integer('categoria_precios_id')->nullable();
            $table->decimal('porcentaje_comision', 12, 4);
            $table->integer('estado_id')->default(1);
        });

        Schema::create('facturas_comision', function (Blueprint $table) {
            $table->increments('id');
            $table->date('fecha_cierre_factura');
            $table->decimal('monto_rol', 12, 4);
            $table->integer('factura_id');
            $table->integer('comision_escala_id')->nullable();
            $table->integer('aplicacion_pagos_id')->nullable();
            $table->integer('rol_id');
            $table->integer('tipo_comision')->nullable();
            $table->integer('estado_id')->default(1);
            $table->integer('cantidad_usuariosxrol')->nullable();
            $table->decimal('retencion_mora_monto', 12, 4)->nullable();
            $table->integer('retencion_mora_dias')->nullable();
            $table->timestamps();
        });

        Schema::create('producto_comision', function (Blueprint $table) {
            $table->increments('id');
            $table->decimal('cantidad', 12, 4);
            $table->decimal('precio_venta', 12, 4);
            $table->decimal('monto_comision', 12, 4);
            $table->integer('precios_producto_carga_id')->nullable();
            $table->integer('factura_id')->nullable();
            $table->integer('producto_id')->nullable();
            $table->integer('rol_id')->nullable();
            $table->integer('estado_id')->default(1);
            $table->integer('facturas_comision_id')->nullable();
            $table->timestamps();
        });

        Schema::create('nota_credito', function (Blueprint $table) {
            $table->increments('id');
            $table->date('fecha');
            $table->decimal('sub_total', 12, 4);
            $table->integer('factura_id');
            $table->integer('estado_nota_id')->default(1);
            $table->integer('estado_rebajado')->default(2);
        });

        Schema::create('nota_credito_has_producto', function (Blueprint $table) {
            $table->integer('nota_credito_id');
            $table->integer('producto_id');
            $table->integer('seccion_id');
            $table->decimal('cantidad', 12, 4);
            $table->decimal('precio_unidad', 12, 4);
            $table->integer('unidad_medida_venta_id');
            $table->integer('precios_producto_carga_id')->nullable();
        });

        Schema::create('aplicacion_pagos', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('factura_id');
            $table->integer('estado')->default(1);
            $table->integer('estado_cerrado')->default(0);
            $table->decimal('saldo', 12, 4)->default(0);
        });

        Schema::create('abonos_creditos', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('aplicacion_pagos_id');
            $table->integer('factura_id');
            $table->integer('estado_abono')->default(1);
            $table->date('fecha_pago');
        });

        Schema::create('nota_credito_creditos', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('nota_credito_id');
        });

        Schema::create('nota_credito_movimientos', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('credito_id');
            $table->string('tipo');
            $table->integer('factura_id');
            $table->integer('aplicacion_pagos_id');
        });

        Schema::create('otros_movimientos', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('aplicacion_pagos_id');
            $table->integer('factura_id');
            $table->integer('estado')->default(1);
            $table->integer('tipo_movimiento');
        });

        Schema::create('comision_periodo', function (Blueprint $table) {
            $table->increments('id');
            $table->date('periodo')->unique();
            $table->integer('estado')->default(0);
        });

        Schema::create('comision_empleado', function (Blueprint $table) {
            $table->increments('id');
            $table->decimal('comision_acumulada', 12, 2);
            $table->dateTime('fecha_ult_modificacion')->nullable();
            $table->date('mes_comision');
            $table->string('nombre_empleado');
            $table->integer('users_comision');
            $table->integer('rol_id');
            $table->integer('estado_id')->default(1);
            $table->timestamps();
        });

        Schema::create('nota_credito_ajustes_comision', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('nota_credito_id');
            $table->integer('facturas_comision_id');
            $table->integer('factura_id');
            $table->integer('user_id');
            $table->integer('rol_id');
            $table->date('periodo_original');
            $table->date('periodo_aplicado');
            $table->decimal('monto', 12, 2);
            $table->boolean('comision_pagada');
            $table->json('detalle_calculo')->nullable();
            $table->timestamp('anulado_at')->nullable();
            $table->unsignedBigInteger('anulado_por')->nullable();
            $table->timestamps();
            $table->unique(['nota_credito_id', 'facturas_comision_id'], 'uk_nc_ajuste_comision');
        });

        Schema::create('dias_gracia_comision', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('rol_id');
            $table->string('tipo_factura');
            $table->integer('dias_gracia');
            $table->decimal('porcentaje_retencion', 12, 4)->nullable();
            $table->string('descripcion')->nullable();
        });

        Schema::create('retencion_mora_log', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('factura_id');
            $table->integer('facturas_comision_id');
            $table->integer('rol_id');
            $table->integer('user_id')->nullable();
            $table->string('tipo_factura');
            $table->date('fecha_aplicacion');
            $table->integer('dias_transcurridos');
            $table->integer('dias_gracia_configurados');
            $table->decimal('porcentaje_aplicado', 12, 4);
            $table->integer('periodo_numero')->nullable();
            $table->decimal('comision_original', 12, 4);
            $table->decimal('monto_retenido', 12, 4);
            $table->decimal('subtotal_factura', 12, 4);
            $table->integer('usuario_ejecutor')->nullable();
            $table->timestamps();
        });

        Schema::create('comision_reversiones', function (Blueprint $table) {
            $table->increments('id');
            $table->text('comisiones_revertidas')->nullable();
            $table->string('motivo')->nullable();
            $table->timestamps();
        });
    }

    private function seedBaseCatalogs(): void
    {
        DB::table('rol')->insert([
            ['id' => 2, 'nombre' => 'Asesor Comercial', 'estado_id' => 1],
            ['id' => 3, 'nombre' => 'Televendedor', 'estado_id' => 1],
            ['id' => 5, 'nombre' => 'Administrador', 'estado_id' => 1],
            ['id' => 16, 'nombre' => 'Gestor Entrega', 'estado_id' => 1],
        ]);

        DB::table('cliente_categoria_escala')->insert([
            ['id' => 10, 'nombre_categoria' => 'Co-Distribuidor'],
            ['id' => 20, 'nombre_categoria' => 'Minorista'],
        ]);
    }

    private function seedCreditNoteCommissionScenario(): void
    {
        DB::table('users')->insert([
            ['id' => 1, 'rol_id' => 3, 'name' => 'Facturador'],
            ['id' => 2, 'rol_id' => 2, 'name' => 'Vendedor'],
        ]);
        DB::table('factura')->insert([
            'id' => 1,
            'users_id' => 1,
            'vendedor' => 2,
            'sub_total' => 30000,
            'total' => 34500,
        ]);
        DB::table('facturas_comision')->insert([
            'id' => 1,
            'fecha_cierre_factura' => '2026-07-29',
            'monto_rol' => 100,
            'factura_id' => 1,
            'rol_id' => 2,
            'tipo_comision' => 3,
            'estado_id' => 1,
        ]);
        DB::table('producto_comision')->insert([
            'cantidad' => 500,
            'precio_venta' => 60,
            'monto_comision' => 54.81,
            'precios_producto_carga_id' => 700,
            'factura_id' => 1,
            'producto_id' => 10,
            'rol_id' => 2,
            'estado_id' => 1,
            'facturas_comision_id' => 1,
        ]);
        DB::table('nota_credito')->insert([
            'id' => 1,
            'fecha' => '2026-08-10',
            'sub_total' => 600,
            'factura_id' => 1,
            'estado_nota_id' => 1,
        ]);
        DB::table('nota_credito_has_producto')->insert([
            'nota_credito_id' => 1,
            'producto_id' => 10,
            'seccion_id' => 1,
            'cantidad' => 10,
            'precio_unidad' => 60,
            'unidad_medida_venta_id' => 1,
            'precios_producto_carga_id' => 700,
        ]);
        DB::table('comision_empleado')->insert([
            'comision_acumulada' => 100,
            'mes_comision' => '2026-07-01',
            'nombre_empleado' => 'Vendedor',
            'users_comision' => 2,
            'rol_id' => 2,
            'estado_id' => 1,
        ]);
    }
}